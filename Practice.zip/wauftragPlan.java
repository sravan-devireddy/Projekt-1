package com.apag.p2plus.p2wp;

/**
 * Package: p2plus.p2wp
 * Class: WAuftragPlan.java
 * ---------------------------------------------------------------
 * Copyright by Asseco Germany AG 2006 - 2013
 * ---------------------------------------------------------------
 * 24.07.2006 HS  FEATURE: FP420006 #166769 generated
 * 11.09.2008 MEM #32548 Termin fixieren
 * 26.11.2010 MEM #198590 Filter auf WAuftrag/Projekt
 * 21.06.2011 HSI #201728 Terminierung mit alternativen Maschinengruppen kann
 *                unterbunden werden
 * 26.05.2014 HSI #229732 unbenutzte imports entfernt
 * 08.09.2016 HSI #249292 generics
 * ---------------------------------------------------------------
 */

import java.util.*;

import com.apag.p2plus.p2core.*;
import com.apag.p2plus.p2core.p2exceptions.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Diese Klasse enthält Methoden für die JGantt-Plantafel.
 */
public class WAuftragPlan implements Visible
{
  private int revCounter = 0;

  /**
   * Behandelt die Anfragen des CRUDManager aus der Bryntum-Plantafel
   *
   * @param para JSON-Daten der Plantafel
   * @param op
   * @param paraObj Eingestellte Parameter
   * @return JSON-Daten der benutzten Resourcen und Events
   * @throws P2Exception bei einem Fehler
   */
  public String CRUDRequest(String para, String op, String paraObj) throws P2Exception, JSONException {
    String response = "", jsonData, resData, evtData, tsData;
    JSONObject req;
    StringBuilder sbRet;
    boolean success = false;

    sbRet = new StringBuilder();
    try {
      req = new JSONObject(para); //try-catch-finally
      switch (req.getString("type")) {
        case "load":
          resData = "\"resources\":{\"rows\": [], \"total\": \"0\"}";
          evtData = "\"events\": {\"rows\": [], \"total\": \"0\"}";
          tsData = "\"timeRanges\":{\"rows\": [], \"total\": \"0\"}";
          JSONArray stores = req.getJSONArray("stores");
          for (int i = 0; i < stores.length(); i++) {
            switch (stores.getString(i)) {
              case "resources":
                String raw = getTreeDataAsJson();
                if (!raw.isEmpty()) {
                  JSONArray arr = new JSONArray(raw);
                  resData = "\"resources\":{\"rows\": " + arr.toString() + ",\n\"total\": \"" + arr.length() + "\" \n}";
                }
                if (sbRet.length() > 1) {
                  sbRet.append("\n,");
                }
                sbRet.append(resData);
                break;

              case "events":
                JSONObject obj = new JSONObject(paraObj);
                String[] rawItems = getPlanDataAsJson(!obj.isNull("start") ? obj.get("start").toString() : null,
                                                      !obj.isNull("ende") ? obj.get("ende").toString() : null,
                                                      !obj.isNull("bauftrag") ? obj.get("bauftrag").toString() : null, 
                                                      !obj.isNull("projekt") ? obj.get("projekt").toString() : null,
                                                      !obj.isNull("wauftrag") ? obj.get("wauftrag").toString() : null,
                                                      obj.getBoolean("showSim"),
                                                      obj.getBoolean("showUsed"),
                                                      obj.getBoolean("calcDate"));
                if (!rawItems[3].isEmpty()) {
                  JSONArray arr = new JSONArray(rawItems[3]);
                  evtData = "\"events\":{\"rows\": " + arr.toString() + ",\n\"total\": \"" + arr.length() + "\" \n}";
                }
                
                if (sbRet.length() > 1) {
                  sbRet.append("\n,");
                }
                
                sbRet.append(evtData);
                
                if(!rawItems[1].isEmpty()){
                  evtData = "\"startDate\":\""  + rawItems[1] + "\"";  
                }
                
                if (sbRet.length() > 1) {
                  sbRet.append("\n,");
                }
                
                sbRet.append(evtData);

                if(!rawItems[2].isEmpty()){
                  evtData = "\"endDate\":\""  + rawItems[2] + "\"";  
                }
                
                if (sbRet.length() > 1) {
                  sbRet.append("\n,");
                }
                
                sbRet.append(evtData);
                
                break;

              case "timeRanges":
                if (sbRet.length() > 1) {
                  sbRet.append("\n,");
                }
                sbRet.append(tsData);
                break;
            }//switch store
          }//for
          success = true;

          jsonData = sbRet.toString();
          break;

        case "sync":
//           jsonData = scheduleProductionOrder(String bauftrag,
//                                              short position,
//                                              short ag,
//                                              String start,
//                                              String ende,
//                                              boolean ctrlPressed,
//                                              boolean fixStart,
//                                              boolean fixEnd,
//                                              String kost,
//                                              String magr,
//                                              String[] filter,
//                                              boolean ignoreAlternMagr)

//           success = jsonData != null;
           success = true;
           jsonData = "";
           break;

        default:
          success = false;
          jsonData = String.format("\"message\": \"invalid operation '%s'\"'", op);
          break;
      }
      response = String.format("{\"success\": \"%s\",%n\"requestId\": \"%s\",%n\"revision\": \"%d\",%n%s}", success, req.getString("requestId"), revCounter++, jsonData);
    } catch (P2Exception e) {
      response = String.format("{\"success\": \"false\", \"message\": \"%s\"}", e.getMessage());
    }

    return response;
  }//CRUDRequest

  /**
   * Liefert die Daten, die zum Initalisieren
   * der JGantt-Plantafel benötigt werden.
   * 
   * @param minString Anfangsdatum oder null
   * @param maxString Enddatum oder null
   * @param bauftrag Betriebsauftrag
   * @param projekt Projekt
   * @param wauftrag Filter auf Werkstattauftrag
   * @param showSim Simulations-Arbeitsgänge berücksichtigen?
   * @param showUsed nur Maschinengruppen mit Belegung anzeigen?
   * @param calcDate frühester Start und spätestes Ende ermitteln?
   * @return String-Array:<p>
   *         [0] = JGantt-Schema<p>
   *         [1] = frühester Starttermin<p>
   *         [2] = spätester Endtermin<p>
   *         [3] = serialisierte ArrayList von HashMaps (Base64-encoded)
   * @throws P2Exception bei einem Fehler
   */
  public String[] getPlanData(String minString, String maxString, String bauftrag, String projekt, String wauftrag, boolean showSim, boolean showUsed, boolean calcDate) throws P2Exception {
    P2Time min = null, max = null;
    
    try {
      if(minString != null) {
        min = new P2Time(minString);
      }
      if(maxString != null) {
        max = new P2Time(maxString);
      }
      return(WAuftragPlanUtil.getPlanData(min, max, bauftrag, projekt, wauftrag, showSim, showUsed, calcDate));
    } finally {
      Transaction.complete();
    }
  } // getPlanData

  public String[] getPlanDataAsJson(String minString, String maxString, String bauftrag, String projekt, String wauftrag, boolean showSim, boolean showUsed, boolean calcDate) throws P2Exception {
    P2Time min = null, max = null;
    
    try {
      if(minString != null) {
        min = new P2Time(minString);
      }
      if(maxString != null) {
        max = new P2Time(maxString);
      }
      return(WAuftragPlanUtil.getPlanDataAsJson(min, max, bauftrag, projekt, wauftrag, showSim, showUsed, calcDate));
    } finally {
      Transaction.complete();
    }
  } // getPlanData

  /**
   * Generiert einen ToolTip für Arbeitsgänge in der JGantt-Plantafel.
   *
   * @param key Schlüssel des Arbeitsgangs: BAuftrag|Position|AG
   * @param language  Sprache des Browsers z.B. „de“ oder „en“
   * @return ToolTip in HTML
   * @throws P2Exception bei einem Fehler
   */
  public String getToolTipText(String key, String language) throws P2Exception {
    try {
      return(WAuftragPlanUtil.getToolTipText(key, language));
    } finally {
      Transaction.complete();
    }
  } // getToolTipText


  /**
   * Terminiert einen Werkstattauftrag für die JGantt-Plantafel.
   *
   * @param bauftrag Nummer des Betriebsauftrags
   * @param position Position des Betriebsauftrags
   * @param ag Nummer des Arbeitsgangs
   * @param start Starttermin in Form "tt.mm.jjjj hh:mm:ss"
   * @param ende Endetermin in Form "tt.mm.jjj hh:mm:ss"
   * @param ctrlPressed <tt>true</tt>, falls beim Verschieben die Ctrl-Taste
   *        gedrückt war
   * @param fixStart Starttermin fixieren?
   * @param fixEnd Endetermin fixieren?
   * @param kost Kapazitätsstelle
   * @param magr Maschinengruppe
   * @param filter Filterbedingung oder null
   * @param ignoreAlternMagr <tt>true</tt>, falls alternative Maschinengruppen
   *        bei der Terminierung ignoriert werden sollen
   * @return String-Array:<br>
   *         [0] = XML-String mit den neuen Daten der geänderten Arbeitsgänge<br>
   *         [1] = jobID bei Überlast oder <code>null</code> bei keiner Überlast
   * @exception P2Exception bei einem Fehler
   */
  public String[] scheduleProductionOrder(String bauftrag,
                                          short position,
                                          short ag,
                                          String start,
                                          String ende,
                                          boolean ctrlPressed,
                                          boolean fixStart,
                                          boolean fixEnd,
                                          String kost,
                                          String magr,
                                          String[] filter,
                                          boolean ignoreAlternMagr)
    throws P2Exception
  {
    String[] changedData;
    boolean success = false;
    HashSet<String> filterSet = null;

    try {
      if(filter != null) {
        filterSet = new HashSet<>(Arrays.asList(filter));
      }
      
      changedData = WAuftragPlanUtil.scheduleProductionOrder(bauftrag, position,
                                                             ag, start,
                                                             ende,
                                                             ctrlPressed,
                                                             fixStart,
                                                             fixEnd,
                                                             kost,
                                                             magr,
                                                             filterSet,
                                                             ignoreAlternMagr);
      success = true;
      return changedData;
    } finally {
      if(success) {
        Transaction.complete();
      } else {
        Transaction.abort();
      }
    }
  } // scheduleProductionOrder

  /**
   * Liefert zu einem Arbeitsgang die Liste der alternativen Maschinengruppen.
   * @param bauftrag Betriebsauftrag
   * @param position Position
   * @param ag Arbeitsgang
   * @return Liste der alternativen Maschinengruppen
   * @throws com.apag.p2plus.p2core.p2exceptions.P2Exception
   */
  public String getAlternativeMachineGroups (String bauftrag, short position, short ag) throws P2Exception
  {
    String ret;
    
    try {
      ret = WAuftragPlanUtil.getAlternativeMachineGroups(bauftrag, position, ag);
      return (ret);
    } finally {
      Transaction.complete();
    }
  }

  public String getAlternativeMachineGroupsAsJson (String bauftrag, short position, short ag) throws P2Exception
  {
    String ret;
    
    try {
      ret = WAuftragPlanUtil.getAlternativeMachineGroupsAsJson(bauftrag, position, ag);
      return (ret);
    } finally {
      Transaction.complete();
    }
  }
  
 /**
  * Liefert Daten für die Initalisierung des Filterbaumes.
  * @return Kapazitätsstellen/Maschinengruppen
  * @throws P2Exception 
  */
 public String getTreeData() throws P2Exception {
   try {
     return(WAuftragPlanUtil.getTreeData());
   } finally {
     Transaction.complete();
   }
 }
 public String getTreeDataAsJson() throws P2Exception {
   try {
     return(WAuftragPlanUtil.getTreeDataAsJson());
   } finally {
     Transaction.complete();
   }
 }
 
} // WAuftragPlan
