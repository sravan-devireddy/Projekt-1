package com.apag.p2plus.p2wp;

/**
 * Package: p2plus.p2wp
 * Class: WAuftragPlanUtil.java
 * ---------------------------------------------------------------
 * Copyright by Asseco Germany AG 2006 - 2013
 * ---------------------------------------------------------------
 * 24.07.2006 HS  FEATURE: FP420006 #166769 generated
 * 24.11.2006 HS  FIX: F420063 #168726 JobID als GUID
 * 08.01.2008 HSI FIX: F430032 #176013 Arbeitsgänge anzeigen, die aus
 *            Betrachtungszeitraum hinausragen
 * 14.04.2008 AAS FEATURE: #178537 Sysconf bei Terminierung
 * 11.09.2008 MEM Verschieben auf alternative Maschinengruppen
 * 22.09.2008 RHA #181162 Fortschritt je Balken nach Menge
 * 08.09.2010 HSI #196551 Fertigstellungsgrad wurde nicht richtig berechnet
 * 26.11.2010 MEM #198590 Filter auf WAuftrag/Projekt
 * 04.05.2011 MEM #202740 Erweiterung URL-Filter
 * 21.06.2011 HSI #201728 Terminierung mit alternativen Maschinengruppen kann
 *                unterbunden werden
 * 10.08.2011 HSI #205147 StringBuilder verwenden
 * 27.06.2013 UGA #221523 Erweiterter ToolTip
 * 26.05.2014 HSI #229732 unbenutzte imports entfernt
 * 13.06.2014 HSI #229801 Redundante null-Prüfungen entfernt
 * 23.09.2015 UGA #241056 Fehlende Übersetzung - Plantafel
 * 13.11.2015 HSI #211121 vereinfachte Vorwärtsterminierung
 * 01.09.2016 HSI #249292 generics
 * 22.05.2018 HSI #271513 Arbeitsplatzlager aus der alternativen Maschinengruppe
 * 04.02.2019 ISE #276162 Fehler beim Terminiren mit alternativen
 *                Maschinengruppe
 * 06.03.2020 UGA #293426 Endedatum falsch
 * 10.12.2020 UGA #302323 Fertigungsplantafel lädt keine Daten - ID-Kollision
 * 25.03.2021 UGA #304919 Absprung aus Byntrum Plantafel ID-Überschreiben
 * ---------------------------------------------------------------
 */
import java.io.*;
import java.util.*;

import com.apag.p2plus.p2core.*;
import com.apag.p2plus.p2core.Base64;
import com.apag.p2plus.p2core.p2exceptions.*;
import com.apag.p2plus.p2objects.*;
import com.apag.p2plus.p2xml.*;
import com.apag.p2plus.p2masterdata.*;
import static com.apag.p2plus.p2objects.ObjectConstants.READ_LOCK;
import com.apag.p2plus.p2resource.RessourcePlanUtil;
import com.apag.p2plus.p2system.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Diese Klasse enthält Methoden für die JGantt-Plantafel.
 */
public class WAuftragPlanUtil extends ObjectUtil {

  /**
     * Liefert die Daten, die zum Initalisieren der JGantt-Plantafel benötigt
     * werden.
   *
   * @param min Anfangsdatum oder null
   * @param max Enddatum oder null
   * @param bauftrag Betriebsauftrag
   * @param projekt Projekt
   * @param filterWO Filter auf Werkstattauftrag
   * @param showSim Simulations-Arbeitsgänge berücksichtigen?
   * @param showUsed nur Maschinengruppen mit Belegung anzeigen?
   * @param calcDate frühester Start und spätestes Ende ermitteln?
     * @return String-Array:
     * <p>
   *         [0] = JGantt-Schema<p>
   *         [1] = frühester Starttermin<p>
   *         [2] = spätester Endtermin<p>
   *         [3] = serialisierte ArrayList von HashMaps (Base64-encoded)
   * @throws P2Exception bei einem Fehler
   */
    public static ArrayList<HashMap<String, Object>> getPlanDataInternal(P2Time min, P2Time max, String bauftrag, String projekt, String filterWO, boolean showSim, boolean showUsed, boolean calcDate) throws P2Exception {
    ObjectManager manager;
    ObjectCollection<WAuftragPosObject> collW;
    ObjectCollection<MagrObject> collM;
    P2Time start, ende;
    String where, userID, magrKey, wauftrag, sql;
    HashMap<String, MagrObject> magrObjects;
    MagrObject magrObj;
    ArrayList<HashMap<String, Object>> data;
    HashMap<String, Object> ag;
    double fertig;
    String color;
    String[] filterWo;

    manager = new ObjectManager(); // #202740 v. unten verschoben

    magrObjects = new HashMap<>();
    data = new ArrayList<>();
        where = "STATUS IN (" + WAuftragPosObject.STATUS_TERMINIERT
                + "," + WAuftragPosObject.STATUS_IN_ARBEIT + ")"
                + " AND START IS NOT NULL"
                + " AND ENDE_VLZ IS NOT NULL"
                + " AND START_NLZ IS NOT NULL"
                + " AND ENDE IS NOT NULL"
                + " AND KOST IS NOT NULL"
                + " AND MAGR IS NOT NULL";
    
    if (!showSim) {
      where += " AND (PLANAG is null OR PLANAG = 0) ";  
    }
// F430032 #176013 Start
    where += " AND START <= '" + max.toSQLDateTime() + "'";
    where += " AND ENDE >= '" + min.toSQLDateTime() + "'";
// F430032 #176013 Ende

    if(filterWO != null) {
      filterWo = filterWO.split("\\|");
      if(filterWo.length == 2) {
        where += " AND BAUFTRAG='" + filterWo[0] + "'";
        where += " AND POSITION =" + filterWo[1];
      }
    } else if (bauftrag != null) {
      where += " AND BAUFTRAG in " + bauftrag ;
    }

    try {
      collW = new ObjectCollection<>(manager, WAuftragPosObject.TABLE, where,
                                     READ_LOCK, true);
      
      for(WAuftragPosObject wAuftragPosObj : collW) {
        magrKey = wAuftragPosObj.getKost() + "|" + wAuftragPosObj.getMagr();
        
        if(! magrObjects.containsKey(magrKey)) {
          magrObj = MagrFactory.search(manager, wAuftragPosObj.getKost(), wAuftragPosObj.getMagr(), READ_LOCK, true);
          magrObjects.put(magrKey, magrObj);
          
        } else {
          magrObj = magrObjects.get(magrKey);
        }
        
        if(magrObj.getBoolean(("PLANEN"))) {
                    userID = wAuftragPosObj.getBauftrag() + "|"
                            + wAuftragPosObj.getPosition() + "|"
                            + wAuftragPosObj.getAg();
          start = wAuftragPosObj.getStart();
          ende = wAuftragPosObj.getEnde();

  //        if(min == null || min.isLaterThan(start)) {
  //          min = new P2Time(start);
  //        }
  //
  //        if(max == null || max.isEarlierThan(ende)) {
  //          max = new P2Time(ende);
  //        }
                    wauftrag = wAuftragPosObj.getBauftrag() + Constants.SOR
                            + wAuftragPosObj.getPosition();

          fertig = determineFertig(wAuftragPosObj);

          if (wAuftragPosObj.getPlanag() == (short)1) {
            try {
              color = SysConfUtil.getString("AV", "COLORSIMAG");
            } catch (Exception e) {
              color = "255,204,255";
            }
          } else {
            try {
              color = getColorAG(wAuftragPosObj);
            } catch (Exception e) {
              color = "102,153,255";
            }
          }
  //        agTag = dataTag.addTag("arbeitsgaenge");
  //        agTag.addAttribute("userID", userID);
  //        agTag.addAttribute("op", "insert");
  //        agTag.addTagAndText("ag", String.valueOf(wAuftragPosObj.getAg()));
  //        agTag.addTagAndText("ag_display", wAuftragPosObj.getBauftrag() + " - " + wAuftragPosObj.getPosition());
  //        agTag.addTagAndText("magr", magrKey);
  //        agTag.addTagAndTime("start", start);
  //        agTag.addTagAndTime("ende_vlz", wAuftragPosObj.getEnde_vlz());
  //        agTag.addTagAndTime("start_nlz", wAuftragPosObj.getStart_nlz());
  //        agTag.addTagAndTime("ende", ende);
  //        agTag.addTagAndText("wauftrag", wauftrag);
  //        agTag.addTagAndText("fertig", String.valueOf(fertig));

          ag = new HashMap<>();
          ag.put("userID", userID);
          ag.put("ag", wAuftragPosObj.getAg());
          ag.put("ag_key", userID);
          ag.put("ag_display",  wAuftragPosObj.getBauftrag() + " - " + wAuftragPosObj.getPosition() + " - " + wAuftragPosObj.getAg());
          ag.put("magr", magrKey);
          ag.put("start", start.toXMLDateTime());
          ag.put("ende_vlz", wAuftragPosObj.getEnde_vlz().toXMLDateTime());
          ag.put("start_nlz", wAuftragPosObj.getStart_nlz().toXMLDateTime());
          ag.put("ende", ende.toXMLDateTime());
          ag.put("wauftrag", wauftrag);
          ag.put("color", color);
          ag.put("fertig", String.valueOf(fertig));
          ag.put("fixieren", wAuftragPosObj.getShort("ISFIXED"));
          ag.put("id", wAuftragPosObj.getId());
          ag.put("bauftrag", wAuftragPosObj.getBauftrag()); //#178537 Bauftrag uebergeben fuer Markierung
          ag.put("position", wAuftragPosObj.getPosition());
  //        ag.put("fertig", "50");

  //        agTag.addTagAndText("magr_display", magrDesc.get(magrKey));
          ag.put("magr_display", magrKey.replace("|", "/") + " " + magrObj.getName());
          
          data.add(ag);
        }
      }
      collW.release();
//      System.out.println(count);
      if (!showUsed) {
        collM = new ObjectCollection<>(manager, MagrObject.TABLE, "PLANEN=1",
                                       READ_LOCK, true);
        for(MagrObject _magrObj : collM) {
          magrKey = _magrObj.getKost() + "|" + _magrObj.getMagr();
          if (!magrObjects.containsKey(magrKey)) {
            magrObjects.put(magrKey, _magrObj);
            ag = new HashMap<>();
            ag.put("magr", magrKey);
            ag.put("magr_display", magrKey.replace("|", "/") + " " + _magrObj.getName());
            ag.put("userID", magrKey);
            ag.put("start", min.toXMLDateTime());
            ag.put("ende", min.toXMLDateTime());
            data.add(ag);
          }
        }
        collM.release();
      }
      
        } finally {
            manager.release();
        }

        return data;
    } // getPlanData

    public static String[] getPlanData(P2Time min, P2Time max, String bauftrag, String projekt, String filterWO, boolean showSim, boolean showUsed, boolean calcDate) throws P2Exception {
        ObjectManager manager;
        ByteArrayOutputStream bos;
        ObjectOutputStream oos;
        ArrayList<HashMap<String, Object>> data;
        String minStart = null, maxEnde = null, sql;
        XMLDocument xmlDoc;
        XMLTag dataTag, root;
        File file;

        manager = new ObjectManager();

        if ((bauftrag != null) && (bauftrag.length() == 0)) {
            bauftrag = null;
        }

        if ((filterWO != null) && (filterWO.length() == 0)) {
            filterWO = null;
        }

        if (bauftrag != null) {
            bauftrag = bauftrag.replaceAll("in\\[", "");
            bauftrag = bauftrag.replaceAll("]", "");
            bauftrag = bauftrag.replaceAll(";", "");
            bauftrag = bauftrag.replaceAll(",", "','");
            bauftrag = "('" + bauftrag + "')";
        }

        try {
            if (bauftrag != null && calcDate) { // #202740 Start und Ende-Datum automatisch ermitteln, wenn bauftrag in der url.
                sql = "select min(start) as min, max(ende) as max from wauftrag where bauftrag in " + bauftrag;
                SpecialObject so = SpecialFactory.search(manager, "WAUFTRAG", sql, false);
                if (so != null) {
                    min = so.getTime("min");
                    max = so.getTime("max");
                }
            }
        } finally {
            manager.release();
        }

        if (min == null) {
            min = new P2Time();
            min.setToFirstOfMonth();
            min.addMonths(-(SysConfUtil.getInt("AV", "JGANTT_PAST_MONTHS")));
        }
        
        if (max == null) {
            max = new P2Time();
            max.setToLastOfMonth();
            max.addMonths(SysConfUtil.getInt("AV", "JGANTT_FUTURE_MONTHS"));
        }

        data = getPlanDataInternal(min, max, bauftrag, projekt, filterWO, showSim, showUsed, calcDate);

        file = new File(AppServerConfig.getInstance().getInstallPath() + "XML\\JGanttProductionSchema.xml");
        xmlDoc = new XMLDocument(file);
        root = (XMLTag) xmlDoc.getRoot();
        dataTag = xmlDoc.createTag("Data");
        root.addChild(dataTag);

      min.setMinTime();
      max.setMaxTime();
      minStart = min.toXMLDateTime();
      maxEnde = max.toXMLDateTime();

    bos = new ByteArrayOutputStream();
    try {
      oos = new ObjectOutputStream(bos);
      oos.writeObject(data);
    } catch (IOException ex) {
      throw new P2IOException(ex);
    }

    return(new String[] {xmlDoc.toString(), minStart, maxEnde, new String(Base64.encode(bos.toByteArray()))});
  } // getPlanData

    public static String[] getPlanDataAsJson(P2Time min, P2Time max, String bauftrag, String projekt, String filterWO, boolean showSim, boolean showUsed, boolean calcDate) throws P2Exception {
        ObjectManager manager;
        ArrayList<HashMap<String, Object>> data;
        String minStart = null, maxEnde = null, sql;
        XMLDocument xmlDoc;
        XMLTag dataTag, root;
        File file;

        manager = new ObjectManager();
        
        if ((bauftrag != null) && (bauftrag.length() == 0)) {
            bauftrag = null;
        }

        if ((filterWO != null) && (filterWO.length() == 0)) {
            filterWO = null;
        }

        if (bauftrag != null) {
            bauftrag = bauftrag.replaceAll("in\\[", "");
            bauftrag = bauftrag.replaceAll("]", "");
            bauftrag = bauftrag.replaceAll(";", "");
            bauftrag = bauftrag.replaceAll(",", "','");
            bauftrag = "('" + bauftrag + "')";
        }

        try {
            if (bauftrag != null && calcDate) { // #202740 Start und Ende-Datum automatisch ermitteln, wenn bauftrag in der url.
                sql = "select min(start) as min, max(ende) as max from wauftrag where bauftrag in " + bauftrag;
                SpecialObject so = SpecialFactory.search(manager, "WAUFTRAG", sql, false);
                if (so != null) {
                    min = so.getTime("min");
                    max = so.getTime("max");
                }
            }
        } finally {
            manager.release();
        }


        if (min == null) {
            min = new P2Time();
            min.setToFirstOfMonth();
            min.addMonths(-(SysConfUtil.getInt("AV", "JGANTT_PAST_MONTHS")));
        }

        if (max == null) {
            max = new P2Time();
            max.setToLastOfMonth();
            max.addMonths(SysConfUtil.getInt("AV", "JGANTT_FUTURE_MONTHS"));
        }
        
        if(!calcDate){
          max.addDays(1);
        }
        
        data = getPlanDataInternal(min, max, bauftrag, projekt, filterWO, showSim, showUsed, calcDate);

        if(!calcDate){
          max.addDays(-1);
        }
        
        file = new File(AppServerConfig.getInstance().getInstallPath() + "XML\\JGanttProductionSchema.xml");
        xmlDoc = new XMLDocument(file);
        root = (XMLTag) xmlDoc.getRoot();
        dataTag = xmlDoc.createTag("Data");
        root.addChild(dataTag);

        if (min == null) {
            min = new P2Time();
        }
        
        if (max == null) {
            max = new P2Time();
        }

        min.setMinTime();
        max.setMaxTime();
        minStart = min.toXMLDateTime();
        maxEnde = max.toXMLDateTime();

        return (new String[]{xmlDoc.toString(), minStart, maxEnde, generateJsonforEvent(data)});
    } // getPlanData  

    private static String generateJsonforEvent(ArrayList<HashMap<String, Object>> data) throws P2Exception {
      JSONArray ja = new JSONArray();
      int i = 1;
      final Set<Integer> idsToRemember = new HashSet<>();
            
      try {
            
            for (HashMap<String, Object> f : data) {
                JSONObject jo = new JSONObject();
                for (Map.Entry<String, Object> entry : f.entrySet()) {
                    switch (entry.getKey()) {
                        case "start":
                            jo.put("startDate", (String) entry.getValue());
                            break;
                        case "ende":
                            jo.put("endDate", (String) entry.getValue());
                            break;
                        case "magr":
                            jo.put("resourceId", entry.getValue());
                            break;                
                        case "color":
                            if(entry.getValue() != null) {
                              String c = RessourcePlanUtil.rgbStringToColor(entry.getValue().toString());
                              jo.put("eventColor", c);
                            }
                            break;
                        case "id":
                            // ensure that id is unique otherwise there is a id collision in Scheduler
                            if(!idsToRemember.contains((Integer) entry.getValue())){
                              jo.put("id", entry.getValue());
                              idsToRemember.add((Integer) entry.getValue());
                            } else {                          
                              boolean found = false;  
                              do {
                                if(!idsToRemember.contains(i)){
                                  jo.put("id", i);    
                                  idsToRemember.add(i);
                                  found = true;
                                }
                                i++;
                              } while(!found);   
                            }
                            break;
//                        case "fertig":
//                              jo.put(entry.getKey(), 33);
//                              break;
                        default:
                            jo.put(entry.getKey(), entry.getValue());
                            break;
                    }
                }
                ja.put(jo);
            }
            for (int x = 0 ; x < ja.length(); x++) {
              JSONObject obj = ja.getJSONObject(x);
              // scheduler needs id so add it here if there is not already one
              if(!obj.has("id")){
                // ensure that id is unique otherwise there is a id collision in Scheduler
                boolean found = false;  
                do {
                  if(!idsToRemember.contains(i)){
                    obj.put("id", i);    
                    idsToRemember.add(i);
                    found = true;
                  }
                  i++;
                } while(!found);                
              }
            }
            return ja.toString();

        } catch (JSONException e) {
            throw new P2IOException(e);
        }

    }

    private static ArrayList<HashMap<String, Object>> getTreeDataInternal() throws P2Exception {
    SpecialCollection<SpecialObject> coll;
    String itemSort;
    ArrayList<HashMap<String, Object>> data;
    HashMap<String, Object> item;

    ObjectManager manager = new ObjectManager();
    data = new ArrayList<>();

    coll = new SpecialCollection<>(manager, MagrObject.TABLE, "select t2.kost+'/' + t2.magr as sort, t2.kost,t2.magr,t1.name_kost, t2.name from magr t2 join kost t1 on t1.kost=t2.kost where t2.planen=1 order by sort desc");
    for(SpecialObject spObj : coll) {
      itemSort = spObj.getString("KOST") + "|" + spObj.getString("magr");
      item = new HashMap<>();
      item.put("itemsort", itemSort);
      item.put("kost", spObj.getString("KOST"));
      item.put("kostname", spObj.getString("NAME_KOST"));
      item.put("magr", spObj.getString("MAGR"));
      item.put("magrname", spObj.getString("NAME"));
      data.add(item);
    }
    coll.release();

        return data;
    }

    public static String getTreeData() throws P2Exception {
        ByteArrayOutputStream bos;
        ObjectOutputStream oos;
        ArrayList<HashMap<String, Object>> data;

        data = getTreeDataInternal();

    bos = new ByteArrayOutputStream();
    try {
      oos = new ObjectOutputStream(bos);
      oos.writeObject(data);
    } catch (IOException ex) {
      throw new P2IOException(ex);
    }

    return( new String(Base64.encode(bos.toByteArray())));
   }

    public static String getTreeDataAsJson() throws P2Exception {
        ArrayList<HashMap<String, Object>> data;
        JSONArray ja = new JSONArray();

        data = getTreeDataInternal();

        // Nach itemsort sortieren
        Collections.sort(data, new Comparator<HashMap<String, Object>>() {

            @Override
            public int compare(HashMap<String, Object> a, HashMap<String, Object> b) {
                return a.get("itemsort").toString().compareTo(b.get("itemsort").toString());
            }
        });

        try {
            // In JSON 'umfüllen' itemsort -> id. id zeigt auf resourceId in events
            for (HashMap<String, Object> f : data) {
                JSONObject jo = new JSONObject();
                for (Map.Entry<String, Object> entry : f.entrySet()) {
                    if (entry.getKey().equals("itemsort")) {
                        jo.put("id", entry.getValue());
                    } else {
                        jo.put(entry.getKey(), entry.getValue());
                    }
                }
                ja.put(jo);
            }

            return ja.toString();

        } catch (JSONException e) {
            throw new P2IOException(e);
        }

    }

  /**
   * Generiert einen ToolTip für Arbeitsgänge in der JGantt-Plantafel
   *
   * @param key Schlüssel des Arbeitsgangs: BAuftrag|Position|AG
   * @param language  Sprache des Browsers z.B. „de“ oder „en“
   * @return ToolTip in HTML
   * @throws P2Exception bei einem Fehler
   */
  public static String getToolTipText(String key, String language) throws P2Exception {
    ObjectManager manager;
    WAuftragPosObject wAuftragPosObj;
    WAuftragObject wAuftragObj;
    StringBuilder text;
    String bAuftrag;
    double fertig;
    int pos1, pos2, tSoll;
    short pos, ag, status;
    
    text = new StringBuilder();
    pos2 = key.lastIndexOf('|');
    pos1 = key.lastIndexOf('|', pos2 - 1);
    bAuftrag = key.substring(0, pos1);
    pos = Short.parseShort(key.substring(pos1 + 1, pos2));
    ag = Short.parseShort(key.substring(pos2 + 1));
    manager = new ObjectManager();

    try {
      wAuftragPosObj = WAuftragPosFactory.search(manager, bAuftrag, pos, ag, ObjectConstants.READ_LOCK, true);
      status = wAuftragPosObj.getStatus();

      tSoll = wAuftragPosObj.getT_soll();

      fertig = determineFertig(wAuftragPosObj);
      
      wAuftragObj = WAuftragFactory.search(manager, bAuftrag, pos, ObjectConstants.READ_LOCK, true);
      
      text.append("<html>");
      text.append("<b>" + NlsObjUtil.translateText("BAuftrag", language) + ": " + bAuftrag + "</b><br>");
      text.append(NlsObjUtil.translateText("Position", language) + ": " + pos + "<br>");
      //text.append(NlsObjUtil.translateText("AG", language) + ": " + ag + "<br>");
      //text.append(NlsObjUtil.translateText("Status", language) + ": " + status + "<br>");
      text.append(NlsObjUtil.translateText("Start", language) + ": " + wAuftragPosObj.getStart() + "<br>");
      text.append(NlsObjUtil.translateText("Ende", language) + ": " + wAuftragPosObj.getEnde() + "<br>");
      text.append(NlsObjUtil.translateText("Dauer", language) + ": " + P2Time.secToStr(tSoll) + "<br>");
      text.append(NlsObjUtil.translateText("Fertig", language) + ": " + fertig + "%<br>");
      text.append(NlsObjUtil.translateText("Artikel", language) + ": " + wAuftragObj.getAplan() + "<br>");
      text.append(NlsObjUtil.translateText("Benennung", language) + ": " + wAuftragObj.getName() + "<br>"); 
      text.append(NlsObjUtil.translateText("Menge", language) + ": " + wAuftragPosObj.getMenge() + "<br>");
      text.append(NlsObjUtil.translateText("Restmenge", language) + ": " + wAuftragPosObj.getMenge_rest() + "<br>");
      
      text.append("</html>");

      return(text.toString());
    } finally {
      manager.release();
    }
  } // getToolTipText

  /**
   * Terminiert einen Werkstattauftrag für die JGantt-Plantafel.
   *
   * @param bauftrag Nummer des Betriebsauftrags
   * @param position Position des Betriebsauftrags
   * @param ag Nummer des Arbeitsgangs
   * @param start Starttermin in Form "tt.mm.jjjj hh:mm:ss:ttt"
   * @param ende Endetermin in der Form "tt.mm.jjjj hh:mm:ss:ttt"
   * @param ctrlPressed <tt>true</tt>, falls beim Verschieben die Ctrl-Taste
   *        gedrückt war
   * @param fixStart Starttermin fixieren?
   * @param fixEnd Endetermin fixieren?
   * @param kost Kapazitätsstelle
   * @param magr Maschinengruppe
   * @param filter Filterbedingung oder null
   * @param ignoreAlternMagr <tt>true</tt>, falls alternative Maschinengruppen
   *        bei der Terminierung ignoriert werden sollen
   * @return String-Array:<br>
   *         [0] = XML-String mit den neuen Daten der geänderten Arbeitsgänge<br>
   *         [1] = jobID bei Überlast oder <code>null</code> bei keiner Überlast
   * @exception P2Exception bei einem Fehler
   */
  public static String[] scheduleProductionOrder(String bauftrag,
                                                 short position,
                                                 short ag,
                                                 String start,
                                                 String ende,
                                                 boolean ctrlPressed,
                                                 boolean fixStart,
                                                 boolean fixEnd,
                                                 String kost,
                                                 String magr,
                                                 Set<String> filter,
                                                 boolean ignoreAlternMagr)
            throws P2Exception {
    ObjectManager manager, spawnManager;
    ObjectCollection<WAuftragPosObject> coll;
    WAuftragPosObject wAuftragPosObj;
    WAuftragObject wauftragObj;
    JobObject jobObj;
    XMLDocument xmlDoc;
    XMLTag dataTag, agTag, filterSetTag, root;
    P2Time aTime;
    P2Time agStart;
    String[] resultArray;
    String where, jobID;
    String aufstueli, schedParams, parameter, data;
    short aufstuelipos;
    boolean overload;
    boolean doDispatchSatisfier;  // #178537
    String idList = null;
    String agKost, agMagr;
    boolean success;

    manager = new ObjectManager();

    try {
      if ((start == null) || (start.length() == 0)) {
        aTime = null;
      } else {
        aTime = new P2Time(start);
      }

      jobID = Job.jobsGetJobId(); // #168726
      Transaction.spawn();
      spawnManager = new ObjectManager();

      try {
        jobObj = JobFactory.create(spawnManager, jobID);
        jobObj.setBez("Plantafel Terminierung");
        jobObj.setUrl(null);
        jobObj.setTyp("SOAP");
        jobObj.setPrioritaet((short)0);
        jobObj.setStatus(Job.JOB_TERMINATED);
        jobObj.update();
      } finally {
        spawnManager.release();
        Transaction.complete();
      }

      wAuftragPosObj = WAuftragPosFactory.search(manager, bauftrag, position,
                                                 ag, OPTIMISTIC_LOCK, true);

      if(ctrlPressed || fixStart || fixEnd) {
        agStart = wAuftragPosObj.getStart();

        if((agStart != null && aTime != null) || fixEnd || fixStart) {
          success = false;
          Transaction.spawn();

          try {
            wAuftragPosObj = (WAuftragPosObject)wAuftragPosObj.spawn();
            wAuftragPosObj.setFixdate(WAuftragPosObject.FIX_START);
            wAuftragPosObj.setJobID(jobID);

            if (fixStart) {
              wAuftragPosObj.setStart(wAuftragPosObj.getStart());
            } else if (fixEnd) {
              wAuftragPosObj.setFixdate(WAuftragPosObject.FIX_ENDE);
              wAuftragPosObj.setEnde(wAuftragPosObj.getEnde());
            } else {
              if(agStart.isEarlierThan(aTime)) {
                // AG wird nach rechts geschoben
                wAuftragPosObj.setStart(aTime);
              } else {
                // AG wird nach links geschoben
                wAuftragPosObj.setEnde(new P2Time(ende));
              }
            }
            wAuftragPosObj.update();
            success = true;
          } finally {
            if(success) {
              Transaction.complete();
            } else {
              Transaction.abort();
            }
          }
        }

      } else if(kost != null && magr != null) {
        agKost = wAuftragPosObj.getKost();
        agMagr = wAuftragPosObj.getMagr();

        // falls übergebene Kost/Magr von der im Arbeitsgang abweicht, die
        // übergebene übernehmen
                if (agKost == null || agMagr == null
                        || !kost.equalsIgnoreCase(agKost) || !magr.equalsIgnoreCase(agMagr)) {
          success = false;
          Transaction.spawn();

          try {
            wAuftragPosObj = (WAuftragPosObject)wAuftragPosObj.spawn();
            wAuftragPosObj.setKost(kost);
            wAuftragPosObj.setMagr(magr);
            wAuftragPosObj.setMagr_internal(true); // #271513
            wAuftragPosObj.update();

            success = true;
          } finally {
            if(success) {
              Transaction.complete();
            } else {
              Transaction.abort();
            }
          }
        }
      }

      if(ctrlPressed) {
        overload = wAuftragPosObj.getOverload();
      } else {
        overload = WAuftragUtil.scheduleProductionOrder2(jobID, null,
                                      ScheduleConstants.SCHEDULE_CENTRAL_START,
                                      bauftrag, position, ag, aTime,
                                      ignoreAlternMagr);
      }

      // #178537 
      doDispatchSatisfier = SysConfUtil.getBoolean("AV", "JGANTT_DISPATCH_SATISFIER");

      if(doDispatchSatisfier) {
        // Mittelpunktsterminierung der Aufstüli-Position, falls existiert
        wauftragObj = WAuftragFactory.search(manager, bauftrag, position,
                                             READ_LOCK, true);
        aufstueli = wauftragObj.getAufstueli();
        aufstuelipos = wauftragObj.getAufstuelipos();

        if(AufstueliPosFactory.search(manager, aufstueli, aufstuelipos,
                                      READ_LOCK, false) != null) {
          if(ignoreAlternMagr) {
            schedParams = "<root termErfStueli='false' ignoreAlternMagr='true'/>";
          } else {
            schedParams = "<root termErfStueli='false'/>"; // Parameter für Erfüller einstellen
          }
          aTime = wauftragObj.getEnde();
          overload = ScheduleUtil.scheduleCentralBOM(jobID, "E", aufstueli,
                                                     aufstuelipos, aTime,
                                                     schedParams);
          // Alle relevanten Werkstattauftraege ermitteln
          parameter = "<root position ='" + aufstuelipos + "' art = 'm'/>";
          data = AufstueliUtil.getPORescheduleData(aufstueli, parameter,
                                                   WAuftragPosObject.CAPA_RELEVANT);
        
          xmlDoc = new XMLDocument(data);
          root = (XMLTag) xmlDoc.getRoot();
          idList = root.getAttribute("idList"); // Liste der Id's der WAuftraege
        }
      }

      if(! overload) {
        jobID = null;
      }
      
      xmlDoc = new XMLDocument("<AppData/>");
      dataTag = xmlDoc.createTag("Data");
      xmlDoc.getRoot().addChild(dataTag);

      // #178537 
      if(idList == null) { // Nur die aktuelle Position
                where = "BAUFTRAG ='" + bauftrag + "' AND POSITION = " + position
                        + " AND status IN (" + WAuftragPosObject.STATUS_TERMINIERT + "," + WAuftragPosObject.STATUS_IN_ARBEIT + ")";
      } else { // Falls Auftragstueckliste terminiert werden soll
        idList = WAuftragPlanUtil.getRelatedAGs(idList); // liefert alle Arbeitsgaenge die betroffen sind
        where = "id in (" + idList + ")";
      }
      
      coll = new ObjectCollection<>(manager, WAuftragPosObject.TABLE, where,
                                    READ_LOCK, false);

      while(! coll.endOfObjects()) {
        wAuftragPosObj = coll.getObject();
        agTag = dataTag.addTag("arbeitsgaenge");
        agTag.addAttribute("userID", wAuftragPosObj.getBauftrag() + "|" + wAuftragPosObj.getPosition() + "|" + wAuftragPosObj.getAg());
        agTag.addAttribute("op", "change");
        agTag.addTagAndTime("start", wAuftragPosObj.getStart());
        agTag.addTagAndTime("ende_vlz", wAuftragPosObj.getEnde_vlz());
        agTag.addTagAndTime("start_nlz", wAuftragPosObj.getStart_nlz());
        agTag.addTagAndTime("ende", wAuftragPosObj.getEnde());
        agTag.addTagAndText("magr", wAuftragPosObj.getKost() + "|" + wAuftragPosObj.getMagr());

        if(filter != null && filter.contains(wAuftragPosObj.getKost() + "|" + wAuftragPosObj.getMagr())) {
          filterSetTag = dataTag.addTag("filterset");
          filterSetTag.addAttribute("userID", "F_" + wAuftragPosObj.getBauftrag() + "|" + wAuftragPosObj.getPosition() + "|" + wAuftragPosObj.getAg());
          filterSetTag.addAttribute("op", "change");
          filterSetTag.addTagAndTime("start", wAuftragPosObj.getStart());
          filterSetTag.addTagAndTime("ende_vlz", wAuftragPosObj.getEnde_vlz());
          filterSetTag.addTagAndTime("start_nlz", wAuftragPosObj.getStart_nlz());
          filterSetTag.addTagAndTime("ende", wAuftragPosObj.getEnde());
          filterSetTag.addTagAndText("magr", wAuftragPosObj.getKost() + "|" + wAuftragPosObj.getMagr());
        }
        coll.nextObject();
      }
      coll.release();

      resultArray = new String[2];
      resultArray[0] = xmlDoc.toString();
      resultArray[1] = jobID;

      return resultArray;
    } finally {
      manager.release();
    }
  } // scheduleProductionOrder
  
  /**
     * liefert die Balkenfarbe eines Arbeitsgangs in Abhängigkeit vom Status,
     * aktuellem Datum und Fertigstellungsgrad.
     *
   * @param wAuftragPosObj Werkstattauftragsposition
   * @return Balkenfarbe
   * @throws P2Exception bei einem Fehler
   */
    public static String getColorAG(WAuftragPosObject wAuftragPosObj) throws P2Exception {
    
        String color;
    short status;
    P2Time start, ende, soll;
    double fertig;
    long diff;
    
    status = wAuftragPosObj.getStatus();
    switch (status) {
      case 2:
        color = SysConfUtil.getString("AV", "COLORAG2");
        break;
      case 3:
        start = wAuftragPosObj.getStart();
        ende = wAuftragPosObj.getEnde();
        fertig = determineFertig(wAuftragPosObj);
        diff = start.diffSeconds(ende);
        start.addSeconds((int)Math.ceil(fertig/100*diff));
        soll = new P2Time();
        if (start.isEarlierThan(soll)) {
          color = SysConfUtil.getString("AV", "COLORAG3NOTOK");
        } else {
          color = SysConfUtil.getString("AV", "COLORAG3OK");
        }
        break;
      default:
        color = SysConfUtil.getString("AV", "COLORAG2");
    }
    return (color);
  }
  
  /**
   * Liefert den Fertigstellungsgrad eines Arbeitsgangs
     *
   * @param wAuftragPosObj Werkstattauftragsposition
   * @return Fertigstellungsgrad in Prozent
   * @throws com.apag.p2plus.p2core.p2exceptions.P2Exception
   */
    private static double determineFertig(WAuftragPosObject wAuftragPosObj) throws P2Exception {
     double tSoll, tRest;
     double fertig = 0;

     tRest = wAuftragPosObj.getT_rest();  // #181162 
     tSoll = wAuftragPosObj.getT_soll();

     if(tSoll != 0) {
       fertig = Convert.round((tSoll - tRest) * 100.0 / tSoll, 0.01); // #181162
     }
     
     if(fertig < 0.0) {
        fertig = 0.0;
      } else if(fertig > 100.0) {
        fertig = 100.0;
      }

     return (fertig); 
   }

  /**
   * Ermittelt die zugeordneten Arbeitsgänge.
     *
   * @param idList ID-Liste
   * @return ID-Liste
   * @throws P2Exception bei einem Fehler
   */
  public static String getRelatedAGs(String idList) throws P2Exception {
    StringBuilder myIdList;
        String sqlQuery;
    SpecialCollection<SpecialObject> spColl;
    ObjectManager manager = new ObjectManager();

    try {
      myIdList = new StringBuilder("");

      if (idList != null) {
                sqlQuery = "SELECT t1.id "
                        + "FROM wauftragpos t1 INNER JOIN wauftrag t2 "
                        + "ON t1.bauftrag = t2.bauftrag AND t1.position = t2.position "
                        + "WHERE t2.id IN (" + idList + ")";

        spColl = new SpecialCollection<>(manager, "wauftragpos", sqlQuery);

        for(SpecialObject spObj : spColl) {
          myIdList.append(String.valueOf(spObj.getId())).append(",");
        }

        spColl.release();
      }
    } finally {
      manager.release();
    }

    if (myIdList.length() > 0) {
      return(myIdList.substring(0, myIdList.length() - 1));
    } else {
      return(myIdList.toString());
    }
  } // getRelatedAGs
  
  /**
   * Liefert zu einem Arbeitsgang die Liste der alternativen Maschinengruppen.
     *
   * @param bauftrag Betriebsauftrag
   * @param position Position
   * @param ag Arbeitsgang
   * @return Liste der alternativen Maschinengruppen
   * @throws com.apag.p2plus.p2core.p2exceptions.P2Exception
   */
    public static TreeMap<String, String> getAlternativeMachineGroupsInternal(String bauftrag, short position, short ag) throws P2Exception {
    ObjectManager manager = new ObjectManager();
    List<AlternativeMachineGroup> altMgrList;
    AlternativeMachineGroup altMgr;
    WAuftragPosObject wAuftragPosObj;
    ByteArrayOutputStream bos;
    ObjectOutputStream oos;
        String kost, magr, kostname, magrname;
    KostObject kostObj;
    MagrObject magrObj;
    int i;
    TreeMap <String,String> magrMap;
    
    wAuftragPosObj = WAuftragPosFactory.search(manager, bauftrag, position, ag, READ_LOCK, true);
    altMgrList = AlternativeMachineGroup.getAlternativMagr(wAuftragPosObj);
    
    magrMap = new TreeMap<>();
    for (i = 0; i<altMgrList.size();i++) {
      altMgr = altMgrList.get(i);
      kost = altMgr.getAlternKost();
      kostObj = KostFactory.search(manager, kost, READ_LOCK, true);
      kostname = kostObj.getName_kost();
      magr = altMgr.getAlternMagr();
      magrObj = MagrFactory.search(manager, kost, magr, READ_LOCK, true);
      magrname = magrObj.getName();
      magrMap.put(kost+"/"+magr, kostname + " " + magrname);
    }

        return magrMap;
    }
    
    public static String getAlternativeMachineGroups(String bauftrag, short position, short ag) throws P2Exception {
        ByteArrayOutputStream bos;
        ObjectOutputStream oos;
        TreeMap<String, String> magrMap;
        String ret;
        
        magrMap = getAlternativeMachineGroupsInternal(bauftrag, position, ag);

    bos = new ByteArrayOutputStream();
    try {
      oos = new ObjectOutputStream(bos);
      oos.writeObject(magrMap);
    } catch (IOException ex) {
      throw new P2IOException(ex);
    }

    ret = new String(Base64.encode(bos.toByteArray()));
    return(ret);
  }

    public static String getAlternativeMachineGroupsAsJson(String bauftrag, short position, short ag) throws P2Exception {
        TreeMap<String, String> magrMap;
        
        magrMap = getAlternativeMachineGroupsInternal(bauftrag, position, ag);
        
        try {
            JSONArray ja = new JSONArray();

            for (Iterator<String> it = magrMap.keySet().iterator(); it.hasNext();) {
                String elem = it.next();
                JSONObject jo = new JSONObject();
                jo.put(elem, magrMap.get(elem));
                ja.put(jo);
            }
            
            return ja.toString();
                
        } catch (JSONException e) {
            throw new P2IOException(e);
        }

    }

} // WAuftragPlanUtil
