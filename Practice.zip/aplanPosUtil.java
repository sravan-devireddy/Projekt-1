package com.apag.p2plus.p2wp;

/**
 * Package: p2plus.p2wp
 * Class: APlanPosUtil.java
 * ---------------------------------------------------------------
 * Copyright by Asseco Germany AG 2000 - 2013
 * ---------------------------------------------------------------
 * State: Design
 * 01.11.2000 LN  generated
 * 20.11.2000 AB  changeMPStateofAG()            
 * 10.01.2001 AB  reNum   
 * 09.02.2001 GW  deletePos
 * 16.03.2001 GW  copy
 * 04.04.2001 LN  aplanposAkt added
 * 06.04.2001 AB  aplanposAkt gefixt
 * 02.10.2001 KJ  deletePos() verwendet jetzt manager.delete()
 * 02.10.2001 KJ  deletePos() überladen
 * 08.03.2002 HS  chgAGBedarf()
 * 11.12.2002 HS  chgAGBedarf() gelöscht
 * 09.01.2003 HS  setConfig()
 * 12.02.2003 HS  insertAlternMaGr(), updateAlternMaGr(), deleteAlternMaGr(),
 *                getMaxRang(), getAlternMagrXML()
 * 04.06.2004 HS  copy(): void -> int
 * 31.01.2005 IYA FIX: F400085. #34527. Wenn keine Variante exitiert, wird in 
 *                das DB-Feld eine NULL geschrieben.
 * 19.04.2005 GWI FIX: F400142, #35237 BV für FV
 * 26.09.2005 HS  F410027, #36433, #36810: reNum() erweitert
 * 27.09.2007 MAH FIX: F430010, #169242: FREMDKOST bei Kopie Arbeitsplan/Arbeitsgang über XML-Definition ausschließen / XML-Definition für APlan/APlanPos
 * 11.03.2008 RHA Fixpaket 43F07 #177760 Nummerierung im Arbeitsplan funktioniert nicht. 
 * 04.06.2008 RHA #179546 bringback umgestellt
 * 16.04.2009 PGO #186227 manager.release() fehlt in Funktion takeMasterData()
 * 23.06.2009 HSI #187394 Alternative Maschinengruppen um Zeiten erweitern
 * 19.10.2009 ISE #185445 automatischer Tausch der alternativen MAGR 
 * 20.01.2010 HSI #189507 alternative Maschinengruppen in AG-Katalogposition
 * 19.04.2010 HSI #193279 deprecated-Methode entfernt
 * 06.08.2010 HSI #195792 valueOf() statt Konstruktor verwenden
 * 30.11.2010 HSI #198650 Fehler bei Syntaxprüfung beseitigt
 * 14.09.2015 HSI #241061 APlanPos aktualisieren: Umstellung auf copyCols()
 * 19.02.2016 JBZ #242988 Möglichkeit der Schaffung flexibler Zuordnung der alternativen Maschinengruppe
 * 25.05.2016 JBZ #220857 Exceptions sind nicht immer mehrsprachenfähig
 * 31.08.2016 HSI #249292 generics, StringBuffer -> StringBuilder,
 *                        valueOf() statt Konstruktor verwenden
 * 05.07.2018 HSI #272755 Meldepunkte umnummerieren
 * 27.11.2017 TDD #265671 Hashtable durch ConcurrentHashMap ersetzt
 * 16.12.2019 HSI #290671 aplanposAkt: Umstellung auf Job
 * ---------------------------------------------------------------
 */

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import com.apag.p2plus.p2core.*;
import com.apag.p2plus.p2core.p2exceptions.*;
import com.apag.p2plus.p2objects.*;
import com.apag.p2plus.p2system.*;
import com.apag.p2plus.p2configurator.*;

/**
 * Diese Klasse arbeitet mit Arbeitsplanpositionen.
 */
public class APlanPosUtil extends ObjectUtil
{
  /** 
   * Ordnet einem Arbeitsgang einen Meldepunkt zu.
   * 
   * Status: unvollständig
   * 
   * @param aplan aktuelle Arbeitsplannumme
   * @param ag zu suchender Arbeitsgang
   * @exception P2Exception bei einem Fehler
   */
  public static void changeMPStateofAG(String aplan,
                                       short ag)
    throws P2Exception
  { 
    ObjectCollection<APlanPosObject> items;
    ObjectManager manager;
    String where = Constants.EMPTY_STRING;
    int[][] cache;
    int mpToDelete = 0;
    int modus = -1;
    int i = 0;
    int anzItems = 0;
    
    manager = new ObjectManager();
    
    try {
      where = "aplan = '" + aplan + "'";
      items = new ObjectCollection<>(manager, "p2wp", APlanPosObject.TABLE,
                                     where, OPTIMISTIC_LOCK, false);
      
      // Anzahl der items
      while (!items.endOfObjects()) {
        anzItems++;
        items.nextObject();
      }
      items.reset();
     
      cache = new int[anzItems][2];
      
      // alle gesuchten Datensaetze cachen
      for(APlanPosObject aplanpos : items) {
        cache[i][0] = aplanpos.getPosition();
        cache[i][1] = aplanpos.getMeldepunkt();
        
        if (aplanpos.isNull("MELDEPUNKT")) {
          if (cache[i][0] == ag) {            
            modus = 1;            
          }
        }
        else {
          if (cache[i][0] == ag) {
            // loeschen
            modus = 0;            
          }
        }
        i++;
      }  // for
      items.reset();
      
      // entsprechendnen MP zur uebergebenen AG finden
      for (i = 0; i < cache.length; i++) {
        if (cache[i][0] == ag) {
          mpToDelete = cache[i][1];          
        }
      }// for
      
      // MPs setzen/loeschen
      for(APlanPosObject aplanpos : items) {
        if (! aplanpos.isNull("MELDEPUNKT")) {
          if (modus == 0) {
            // loeschen
            if (aplanpos.getMeldepunkt()== mpToDelete) {
              aplanpos.setNull("MELDEPUNKT");
            }
          }
        } else {
          if ((modus == 1) && (aplanpos.getPosition()<= ag)) {
            // setzen
            aplanpos.setMeldepunkt(ag);
          }
        }
        aplanpos.update();
      } // for

      items.release();
    } finally {
      manager.release();
    }
  } //changeMPStateofAG
  
  /**
   * Nummeriert die Arbeitsgaenge ab konfiguriertem Startwert
   * und in konfigurierter Schrittweite neu.
   * Aktualisiert auch in der Tabelle stuelipos den agbedarf (Nummer des
   * zugörigen Arbeitsgangs).
   *
   * @param aplan Nummer des Arbeitsplanes
   * @exception P2Exception bei anderen Fehlern 
   */

  public static void reNum(String aplan) throws P2Exception
  {
    APlanObject aplanObj;
    ObjectCollection<APlanPosObject> collAplanpos;
    ObjectCollection<StueliPosObject> collStuelipos;
    short start, inc, pos,altPos;
    short anz = 0;    
    ObjectManager manager = new ObjectManager();    
    ConcurrentHashMap<Short, Short> exPos = new ConcurrentHashMap<>();
    HashMap<Short, Short> oldNewPos;
    Short help, newMP;
    String where;
    StringBuilder idList = null;
    short agEntnahme, agZugang;
    boolean updateAPlan = false;

    oldNewPos = new HashMap<>();

    try {  
      aplanObj = APlanFactory.search(manager, aplan, OPTIMISTIC_LOCK, true);
      agEntnahme = aplanObj.getAgentnahme();
      agZugang = aplanObj.getAgzugang();
      
      start = SysConfUtil.getShort("av","aplanStart");
      inc = SysConfUtil.getShort("av","aplanInc");
      where = Build.equalConst("aplan",aplan);
      where = where + " order by POSITION"; //177760 
      
      //Umnummerieren, da sonst vielleicht eine Exception 
      //wegen Doppelten Schlüssel von der Datenbank geworfen wird
      //Abspeichern der aktuellen Positionnummern
      collAplanpos = new ObjectCollection<>(manager, APlanPosObject.TABLE,
                                            where, OPTIMISTIC_LOCK, false);     
      for(APlanPosObject aplanposObj : collAplanpos) {
        pos = aplanposObj.getPosition();
        exPos.put(Short.valueOf(anz), Short.valueOf(pos)); // (key, value)
        anz++;
      }
      collAplanpos.reset();        
      //Umnummerieren der aktuellen Positionen.
      pos = (short)(inc * anz + start); //Hoechste neue Positionsnummer
      
      for(APlanPosObject aplanposObj : collAplanpos) {
        // Nummer nächsten freien Postionsnummer extrahieren
        while (exPos.contains(Short.valueOf(pos))) {
          /* ist key mit value pos in der ConcurrentHashMap enthalten?
           * wenn nein, kann diese Position verwendet werden;
           * ist er enthalten, wird weiter gezaehlt, bis er nicht mehr
           * enthalten ist
           */
          pos += 1;
          if (pos == Short.MAX_VALUE) {
            // Abbruchbedingung, wenn der Datenbereich von short ueberlaeuft
            throw new P2FormatException("A_OUTOFRANGE");
          }
        }
        // setzen der Zwischenpositionsnummer
        aplanposObj.setPositionDirect(pos);
        /* Inkrement ist 1, da ausreichend
         * es können allerding Luecken auftreten, damit keine
         * DuplicateKeyException geworfen wird.
         */
        pos += 1;
        aplanposObj.update();
      }//for
      collAplanpos.reset();
      
      //Neu Nummerieren      
      pos = start;
      anz = 0;
      for(APlanPosObject aplanposObj : collAplanpos) {
        aplanposObj.setPositionDirect(pos);
        //In der Tablle stuelipos muss noch agbedarf geändert werden
        help = exPos.get(Short.valueOf(anz));
        altPos = help.shortValue();
        where = "stueli = '" + aplan + "' AND agbedarf = " + altPos;
        if (idList != null) {
          where += " AND id not in(" + idList.toString() + ")";
        }
        collStuelipos = new ObjectCollection<>(manager, StueliPosObject.TABLE,
                                               where, OPTIMISTIC_LOCK, true);
        for(StueliPosObject stueliposObj : collStuelipos) {
          stueliposObj.setAgbedarfDirect(pos);
          stueliposObj.update();

          // id merken, da dieser Datensatz nicht mehr aktualisiert werden darf
          if (idList == null) {
            idList = new StringBuilder(String.valueOf(stueliposObj.getId()));
          } else {
            idList.append(Constants.COMMA).append(stueliposObj.getId());
          }
        }
        collStuelipos.release();
        
        // AGENTNAHME und AGZUGANG anpassen
        if (agEntnahme > 0 && altPos == agEntnahme) {
          aplanObj.setAgentnahme(pos);
          updateAPlan = true;
        }
        
        if (agZugang > 0 && altPos == agZugang) {
          aplanObj.setAgzugang(pos);
          updateAPlan = true;
        }

        oldNewPos.put(help, Short.valueOf(pos));

        pos += inc;
        anz++;
      }
      collAplanpos.reset();

      for(APlanPosObject aplanposObj : collAplanpos) {
        // Meldepunkt anpassen
        if(!aplanposObj.isNull("meldepunkt")) {
          newMP = oldNewPos.get(Short.valueOf(aplanposObj.getMeldepunkt()));

          if(newMP != null) {
            aplanposObj.setMeldepunkt(newMP.shortValue());
          }
        }

        aplanposObj.update();
      }
      collAplanpos.release();

      if (updateAPlan) {
        aplanObj.update();
      }
    } finally {
      manager.release();
    } //finally
  } // reNum
  
 /** 
  * Loescht Arbeitsgaenge innerhalb eines Arbeitsplanes.
  *
  * @param aplan Aktueller Arbeitsplan
  * @param von Erster Arbeitsgang, ab dem geloescht werden soll
  * @param bis Letzter Arbeitsplan, der geloescht werden soll.
  * @exception P2Exception bei Fehler
  */
  public static void deletePos(String aplan, short von, short bis)
    throws P2Exception
  {
    ObjectManager manager;
    ObjectCollection<APlanPosObject> objColl;
    String where;

    manager = new ObjectManager();
    try {
      where = "aplan = '" + aplan + "' AND position >= " + von +
              " AND position <= " + bis;
      objColl = new ObjectCollection<>(manager, APlanPosObject.TABLE, where,
                                       OPTIMISTIC_LOCK, true);
      for(APlanPosObject aplanposObj : objColl) {
        aplanposObj.delete();
      }
      objColl.release();

      return;
    } finally {
      manager.release();
    } 
  } // deletePos

  /** 
   * Loescht Arbeitsgaenge innerhalb eines Arbeitsplanes.
   *
   * @param aplan  Aktueller Arbeitsplan
   * @param von1   Startwert Bereich 1
   * @param bis1   Endwert Bereich 1
   * @param von2   Startwert Bereich 2
   * @param bis2   Endwert Bereich 2
   * @param von3   Startwert Bereich 3
   * @param bis3   Endwert Bereich 3
   * @exception P2Exception bei Fehler
   */
  public static void deletePos(String aplan,
                               short von1,
                               short bis1,
                               short von2,
                               short bis2,
                               short von3,
                               short bis3)
    throws P2Exception
  {
    ObjectManager manager;
    ObjectCollection<APlanPosObject> objColl;
    StringBuilder where;

    manager = new ObjectManager();
    try {
      if (aplan != null && (von1 > 0 || bis1 > 0 || von2 > 0 || bis2 > 0 ||
                            von3 > 0 || bis3 > 0)) {
        where = new StringBuilder("aplan = '").append(aplan).append("' AND (");
        if (von1 > 0) {
          where.append("position >= ").append(von1);
        }
        if (von1 > 0 && bis1 > 0) {
          where.append(" AND ");
        }
        if (bis1 > 0) {
          where.append("position <= ").append(bis1);
        }
        if ((von1 > 0 || bis1 > 0) && (von2 > 0 || bis2 > 0)) {
          where.append(" OR ");
        }
        if (von2 > 0) {
          where.append("position >= ").append(von2);
        }
        if (von2 > 0 && bis2 > 0) {
          where.append(" AND ");
        }
        if (bis2 > 0) {
          where.append("position <= ").append(bis2);
        }
        if ((von1 > 0 || bis1 > 0 || von2 > 0 || bis2 > 0) &&
            (von3 > 0 || bis3 > 0)) {
          where.append(" OR ");
        }
        if (von3 > 0) {
          where.append("position >= ").append(von3);
        }
        if (von3 > 0 && bis3 > 0) {
          where.append(" AND ");
        }
        if (bis3 > 0) {
          where.append("position <= ").append(bis3);
        }
        where.append(")");

        objColl = new ObjectCollection<>(manager, APlanPosObject.TABLE,
                                         where.toString(), OPTIMISTIC_LOCK,
                                         true);
        for(APlanPosObject aplanposObj : objColl) {
          aplanposObj.delete();
        }
        objColl.release();
      }

      return;
    } finally {
      manager.release();
    } 
  } // deletePos

  /**
   * Kopiert eine Arbeitsplanposition.
   *
   * @param altAplan Nummer des Arbeitplan
   * @param altPos Nummer des Arbeitsganges
   * @param altVariante Variante
   * @param neuAplan Nummer des neuen Arbeitsplanes
   * @param neuPos Nummer des neuen Arbeitsganges
   * @param mitVariante Falls true, Varianten mitkopieren
   * @return id der neuen Arbeitsplanposition
   * @exception P2Exception bei einem Fehler 
   */
  public static int copy(String altAplan,
                         short altPos,
                         String altVariante,
                         String neuAplan,
                         short neuPos,
                         boolean mitVariante)
    throws P2Exception 
  {
    ObjectManager manager;
    APlanPosObject apo, copyObj;

    manager = new ObjectManager();

    try {
      apo = APlanPosFactory.search(manager, altAplan, altPos, altVariante,
                                   READ_LOCK, true);

      // #169242
      copyObj = apo.copy(neuAplan, neuPos, mitVariante);
      copyObj.update();
      return (copyObj.getId());
      
    } finally {
      manager.release();
    }
  } // copy


  /**
   * Aktualisiert die Eintraege in der Tabelle APLANPOS
   * in Abhaengigkeit von der Textgruppe und Nummer.
   * 
   * @param jobID Job-ID
   * @param textgr Bezeichnung der Textgruppe
   * @param nummer Nummer der Textgruppe
   * @exception P2Exception bei einem Fehler
   */
  public static void aplanposAkt(String jobID,
                                 String textgr,
                                 String nummer)
    throws P2Exception
  {
    AgKatalogObject agko;
    ObjectManager manager = new ObjectManager();
    ObjectCollection<APlanPosObject> oc;
    StringBuilder where;
    HashSet<String> exclude;
    int max, step;
    boolean success;
    
    try {
      agko = AgKatalogFactory.search(manager, textgr,
                                     Integer.parseInt(nummer.trim()), READ_LOCK,
                                     true);
      
      exclude = new HashSet<>();
      exclude.add("TEXTGRUPPE");
      exclude.add("NUMMER");

      where = new StringBuilder();
      where.append("textgruppe = '");
      where.append(textgr);
      where.append("' AND nummer = ");
      where.append(nummer);      

      // Arbeitsgänge werden aktualisiert...
      Job.jobSetInfo(jobID, "A_APLANPOS_UPDATE");

      max = (int)manager.count(APlanPosObject.TABLE, where.toString());
      step = 0;

      oc = new ObjectCollection<>(manager, "p2wp", APlanPosObject.TABLE,
                                  where.toString(), OPTIMISTIC_LOCK, true);
      for(APlanPosObject apo : oc) {
        step++;
        Job.jobProgress(jobID, step, max);

        success = false;
        Transaction.spawn();

        try {
          apo = (APlanPosObject)apo.spawn();
          ObjectTools.copyCols(agko, apo, true, exclude, false);

          apo.update();
          success = true;
        } finally {
          if(success) {
            Transaction.complete();
          } else {
            Transaction.abort();
          }
        }
      }
      oc.release();
    } finally {
      manager.release();
    } 
  } // aplanposAkt()


  /** Setzt die Varianten eines Arbeitsgangs anhand eines
   * Konfigurations-XML.
   * @param id ID des Arbeitsgangs
   * @param xml Konfigurations-XML
   * @throws P2NotFoundException falls Datensatz nicht gefunden
   * @exception P2Exception bei einem Fehler
   */
  public static void setConfig(int id, String xml)
    throws P2NotFoundException, P2Exception
  {
    ObjectManager manager;
    APlanPosObject aplanposObj;
    String variante;

    manager = new ObjectManager();

    try {
      aplanposObj = (APlanPosObject)new APlanPosFactory().searchId(manager, id,
                                                                   OPTIMISTIC_LOCK);
      if (aplanposObj == null) {
        throw new P2NotFoundException("A_APLANPOSNOTFOUND||");
      }

      variante = ConfigXMLUtil.getActiveVariants(xml);
      
      if(variante != null && variante.length() == 0){ //#34527
        aplanposObj.setNull("VARIANTE");
      }else {
        aplanposObj.setVariante(variante);
      }
      aplanposObj.update();

      return;
    } finally {
      manager.release();
    }
  } // setConfig

  /**
   * Prüft, ob Maschinengruppe, der der Arbeitsgang zugeordnet
   * ist, als alternative Maschinengruppe gekennzeichnet ist.
   *
   * @param id ID des Arbeitsgangs
   * @param kost Kostenstelle
   * @param magr Maschinengruppe
   * @return true -  wenn die Maschinengruppe als alternative 
   *                 Maschinengruppe gekennzeichnet ist.
   * @exception P2Exception bei einem Fehler
   */
  public static boolean magrChange(int id, String kost, String magr)
    throws P2Exception
  {
    ObjectManager manager;
    APlanPosObject aplanposObj;
    AlternativeMachineGroup aMaGr;
    List<AlternativeMachineGroup> aList;
    boolean change = false;

    manager = new ObjectManager();
    try {
      aplanposObj = APlanPosFactory.search(manager, id, OPTIMISTIC_LOCK, false);
      if (aplanposObj != null) {       
        aList = AlternativeMachineGroup.getAlternativMagr(aplanposObj);
        //alternative Maschinengruppe aus der Liste "alternativmagr"
        aMaGr = AlternativeMachineGroup.getAlternMagr(kost, magr, aList);
        change = (aMaGr != null);
      }
      return change;
    } finally {
      manager.release();
    }  
  } // magrChange

  /**
   * Legt eine neue alternative Maschinengruppe zu einer Arbeitsplanposition
   * an.
   *
   * @param id ID des Arbeitsgangs
   * @param xmlData Daten als XML
   * @exception P2Exception bei einem Fehler
   */
  public static void insertAlternMaGr(int id,
                                      String xmlData)
    throws P2Exception
  {
    ObjectManager manager;
    APlanPosObject aplanposObj;

    manager = new ObjectManager();
    try {
      aplanposObj = APlanPosFactory.search(manager, id, OPTIMISTIC_LOCK, true);
      aplanposObj.insertAlternMaGr(xmlData);
      aplanposObj.update();

      return;
    } finally {
      manager.release();
    }
  } // insertAlternMaGr


  /**
   * Ändert eine vorhandene alternative Maschinengruppe.
   *
   * @param id ID des Arbeitsgangs
   * @param rang_alt bisherige Rangfolgenummer
   * @param xmlData Daten als XML
   * @throws P2Exception bei einem Fehler
   */
  public static void updateAlternMaGr(int id,
                                      short rang_alt,
                                      String xmlData)
    throws P2Exception
  {
    ObjectManager manager;
    APlanPosObject aplanposObj;

    manager = new ObjectManager();

    try {
      aplanposObj = APlanPosFactory.search(manager, id, OPTIMISTIC_LOCK, true);
      aplanposObj.updateAlternMaGr(rang_alt, xmlData);
      aplanposObj.update();
    } finally {
      manager.release();
    }
  } // updateAlternMaGr


  /**
   * Löscht eine alternative Maschinengruppe.
   *
   * @param id ID des Arbeitsgangs
   * @param rang Rangfolgenummer der zu löschenden alternative Maschinengruppe
   * @exception P2Exception bei einem Fehler
   */
  public static void deleteAlternMaGr(int id,
                                      short rang)
    throws P2Exception
  {
    ObjectManager manager;
    APlanPosObject aplanposObj;

    manager = new ObjectManager();

    try {
      aplanposObj = APlanPosFactory.search(manager, id, OPTIMISTIC_LOCK, true);
      aplanposObj.deleteAlternMaGr(rang);
      aplanposObj.update();

      return;
    } finally {
      manager.release();
    }
  } // deleteAlternMaGr


  /**
   * Ermittelt Daten einer alternativen Maschinengruppe.
   *
   * @param id ID des Arbeitsgangs
   * @param rang Rang
   * @return Daten als XML
   * @throws P2Exception bei einem Fehler
   */
  public static String getAlternMaGrValues(int id,
                                           short rang)
    throws P2Exception
  {
    ObjectManager manager;
    APlanPosObject aplanposObj;
    String alternMagrXML, xml;

    manager = new ObjectManager();

    try {
      aplanposObj = APlanPosFactory.search(manager, id, READ_LOCK, true);
      alternMagrXML = aplanposObj.getAlternativmagr();
      xml = AlternativeMachineGroup.getAlternMaGrValues(rang, alternMagrXML);

      return xml;
    } finally {
      manager.release();
    }
  } // getAlternMaGrValues


  /**
   * Ermittelt Default-Werte einer alternativen Maschinengruppe.
   *
   * @param id ID des Arbeitsgangs
   * @return Daten als XML
   * @throws P2Exception bei einem Fehler
   */
  public static String getAlternMaGrDefaultValues(int id)
    throws P2Exception
  {
    ObjectManager manager;
    APlanPosObject aplanposObj;
    String xml;

    manager = new ObjectManager();

    try {
      aplanposObj = APlanPosFactory.search(manager, id, READ_LOCK, true);
      xml = AlternativeMachineGroup.getAlternMaGrDefaultValues(aplanposObj);

      return xml;
    } finally {
      manager.release();
    }
  } // getAlternMaGrDefaultValues


  /**
   * Gibt das XML zurück, das die alternativen Maschinengruppen repräsentiert.
   * Das XML wird so transformiert, dass es auf einer Tab-Seite dargestellt
   * werden kann.
   *
   * @param id ID des Arbeitsgangs
   * @return transformiertes XML; null falls keine alternative Maschinengruppen
   *         gefunden werden
   * @exception P2Exception bei einem Fehler
   */
  public static String getAlternMagrXML(int id)
    throws P2Exception
  {
    ObjectManager manager;
    APlanPosObject aplanposObj;
    String alternMagrXML, xml;

    manager = new ObjectManager();

    try {
      aplanposObj = APlanPosFactory.search(manager, id, READ_LOCK, true);
      alternMagrXML = aplanposObj.getAlternativmagr();
      xml = AlternativeMachineGroup.transformXML(alternMagrXML);
      return (xml);
    } finally {
      manager.release();
    }
  } // getAlternMagrXML
  
  
  /** Prüft das Skript auf korrekte Syntax
   *
   * @param script das Skript
   * @throws P2ProblemException Bei einem Fehler
   * @exception P2Exception bei einem Fehler
   * @return falls alles in Ordnung -->"ok"
   */
  public static String isSyntaxOK(String script)
    throws P2ProblemException, P2Exception
  {
    ObjectManager manager;
    WAuftragPosObject wPosObj;
    WAuftragObject wObj;
    BAuftragObject baufObj;
    String skriptStatus = "ok";

    manager = new ObjectManager();

    try {
      
      // Wir brauchen einen Bauftrag, Wauftrag und Wauftragpos. Daher müssem wir eine Wauftragpos anlegen.
      // Hinweis: Es Erfolg keine update(), sodaß dieses Objekte nur im Cache existiert und wieder entsorgt werden kann
      baufObj = BAuftragFactory.create(manager, "bauftrag_test");
      
      wObj = WAuftragFactory.create(manager, baufObj.getBauftrag(),(short)1);
      wPosObj = WAuftragPosFactory.create(manager, wObj.getBauftrag(), (short)1,(short)1, false);
      
      if (wPosObj != null){
      
       wPosObj.runScript(false, script);  // die Berechnungen werden nicht gespeichert
      
      }else{
        throw new P2ProblemException("A_NOTSYNTAXCHECK");
      }
      
      return skriptStatus;
      
    }catch(P2Exception e){
      throw new P2ProblemException(e.toString());
    } finally {
      manager.release();
    }
  } // isSyntaxOK



  /**
   * Ruft die setMethode von Name mit value auf. 
   *
   * @param id Datenbank-id 
   * @param name Name des Attributs
   * @param value neuer Wert des Attributs
   * @throws P2NotFoundException falls Datensatz nicht gefunden wird
   * @throws P2Exception bei einem sonstigen Fehler
   */
  public static void takeMasterData(int id,
                               String name,
                               String value)
    throws P2NotFoundException, P2Exception
  {
    ObjectManager manager;
    APlanPosObject aPlanPosObject;

    manager = new ObjectManager();
    aPlanPosObject = (APlanPosObject) new APlanPosFactory().searchId(manager,id,OPTIMISTIC_LOCK);
    if (aPlanPosObject != null) {
      try {
        aPlanPosObject.takeMasterData(name, value);
      } catch (P2InfoException p2InfoEx) {
        aPlanPosObject.update();
        throw p2InfoEx;
      } finally {
        manager.release(); //#186227
      }
      aPlanPosObject.update();
    } else {
      throw new P2NotFoundException("C_RECORDNOTEXIST");
    }
  } // takeMasterData
  
  
  /**
   *  refresh die Alternative Maschinengruppe einem APlanPos 
   *  durch die Alternative Maschinengruppe einem Hauptmaschinengruppe.
   *  
   * @param id  id der Arbeitsplanpostion
   * @throws P2Exception bei einem Fehler
   */
  public static void alterMagrTake(int id) throws  P2Exception
  {
    ObjectManager manager;
    APlanPosObject aPlanPosObject;
    String magr, kost, altern;

    manager = new ObjectManager();

    try {
      aPlanPosObject = APlanPosFactory.search(manager, id, OPTIMISTIC_LOCK, true);
      magr = aPlanPosObject.getMagr();
      kost = aPlanPosObject.getKost();
      altern = AlternativeMachineGroup.takeAlternMagr(kost, magr);
      aPlanPosObject.setAlternativmagr(altern);
      aPlanPosObject.update();

    } finally {
      manager.release();
    }
  }//alterMagrTake()


} // APlanPosUtil

