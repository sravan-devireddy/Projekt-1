package com.apag.p2plus.p2wp;

/**
 * Package: p2plus.p2wp
 * Class: ScheduleCache.java
 * ---------------------------------------------------------------
 * Copyright by Asseco Germany AG 2000 - 2013
 * ---------------------------------------------------------------
 * State: Design
 * 04.07.2000 HS  generated
 * 17.07.2000 HS  Hashtable für Artikelstamm
 * 08.09.2000 HS  Hashtable für Erfüller-Aufstüli
 * 15.11.2001 HS  implemented interface auskommentiert
 * 21.11.2001 HS  Hashtable für Team
 * 29.01.2002 HS  waUmterm, Konstruktor
 * 30.01.2002 HS  scheduleType
 * 25.02.2002 HS  addToWAList(), getWAList()
 * 24.04.2002 HS  XMLDocument.fromString() entfernt
 * 27.06.2002 HS  waUmterm und waList auf HashSet umgestellt
 * 26.09.2002 HS  AF360101
 * 20.11.2002 HS  SCHEDULE_AVAILABILITY
 * 26.11.2002 HS  ignoredAllocations
 * 24.03.2003 HS  FIX: AF360232
 * 29.03.2006 HS  FIX: F410100, #162506: Tagesbeginn;
 *                Tagesmodell nicht mehr im Cache
 * 28.04.2007 IYA F420124 #171946. Aufstueliautomatik und Vorabbedarfe.
 *                Konstruktor angepasst. Neue Methode isAutomatic().
 * 14.02.2008 HSI FEATURE: #177134 Simulation
 * 28.02.2008 HS  FIX: F430037, #176842: Vorwärtsterminierung mit alternativen
 *                Maschinengruppen
 * 24.07.2008 ISE #180567 team-key toUpperCase()
 * 24.07.2008 ISE #180769 maschinengruppe-key toUpperCase()
 * 18.11.2008 HSI FEATURE: #182607 Überlappung von Werkstattaufträgen
 * 16.03.2009 HSI #185445 Terminierung mit alternativen Maschinengruppen kann
 *                über Sysconf gesteuert werden
 * 13.05.2009 HSI #186277 nicht mehr benötigte Variablen und Methoden entfernt
 * 25.09.2009 HSI #189216 separater Tagesbeginn für Terminierung
 * 08.11.2009 ISE #189994 Neuterminierung aller offenen Aufträge
 * 06.08.2010 HSI #195792 valueOf() statt Konstruktor verwenden
 * 21.06.2011 HSI #201728 Terminierung mit alternativen Maschinengruppen kann
 *                unterbunden werden
 * 18.01.2012 NVA #197872 Kapazitätsplanung werden nur Kapazitätsstellen und
 *                 Maschinengruppen berücksichtigt, bei denen der Kenner „Planen“
 *                 gesetzt ist
 * 06.03.2012 ISE #210046 Standorte in Auftragsstücklistenpositionen
 * 26.08.2013 ISE #198322 XML für Kalkulations-Excel erzeugen
 * 14.11.2013 ISE #224826 Kapazitätsplanung in einem Job durchführen
 * 02.02.2015 HSI #235719 Terminierung mit Offset, minimaler Menge und Engpass-Ressource
 * 13.11.2015 HSI #211121 vereinfachte Vorwärtsterminierung
 * 03.12.2015 HSI #239587 Terminierung mit Pufferzeiten
 * 18.07.2016 HSI #249292 Nutzlose if-Abfrage korrigiert, generics,
 *                StringBuffer -> StringBuilder
 * 27.11.2017 TDD #265671 Hashtable durch ConcurrentHashMap ersetzt
 * 04.02.2019 ISE #276162 Fehler beim Terminiren mit alternativen Maschinengruppe
 * 14.08.2019 ISE #286357, #295812 Unterbrechungen bei Ermittlung der Kapazität für Personalressource
 *                auch in der Vergangenheit berücksichtigen
 * 21.08.2019 HSI #286256 Kenner "Planen" wird nicht mehr abgefragt
 * 31.07.2020 ISE #297120, #300044 Kapazitätsüberlast bei der Vertriebssimulation
 *                generell nicht berechnen
 * ---------------------------------------------------------------
 */

import com.apag.p2plus.p2core.p2exceptions.*;
import com.apag.p2plus.p2core.*;
import com.apag.p2plus.p2wp.scheduling.PosSchedulingJobProgress;
import com.apag.p2plus.p2wp.scheduling.SchedulingJobProgress;
import com.apag.p2plus.p2xml.*;
import com.apag.p2plus.p2system.*;
import com.apag.p2plus.p2masterdata.MagrFactory;
import com.apag.p2plus.p2masterdata.MagrObject;
import com.apag.p2plus.p2masterdata.StandortUtil;
import com.apag.p2plus.p2objects.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Diese Klasse enthält Methoden zum Lesen und Schreiben von
 * terminierungsrelevanten Daten aus dem bzw in den Cache.
 */

public class ScheduleCache
{
  /********************** Konstanten **********************/

  /**
   * Backward.
   */  
  public final static int SCHEDULE_BACKWARD = 1;

  /**
   * Forward.
   */  
  public final static int SCHEDULE_FORWARD = 2;

  /**
   * Central.
   */  
  public final static int SCHEDULE_CENTRAL = 3;

  /**
   * Assembly
   */  
  public final static int SCHEDULE_ASSEMBLY = 4;

  /**
   * Availability.
   */
  public final static int SCHEDULE_AVAILABILITY = 5;

  /********************** ConcurrentHashMaps, HashSets **********************/

  /**
   * Maschinengruppe.
   */
  private ConcurrentHashMap<String, MachineGroup> maschinengruppe = new ConcurrentHashMap<>();

  /**
   * Wiederbeschaffungszeit eines Artikels.
   */
  private ConcurrentHashMap<String, Short> artikel = new ConcurrentHashMap<>();

  /**
   * Pufferzeiten eines Artikels.
   */
  private HashMap<String, Short> pufferzeit = new HashMap<>();

  /**
   * Start oder Ende von Erfüllerstücklistenpositionen.
   */
  private ConcurrentHashMap<String, P2Time> performBOMDate = new ConcurrentHashMap<>();

  /**
   * Team.
   */
  private ConcurrentHashMap<String, Team> team = new ConcurrentHashMap<>();

  /**
   * IDs aller WAufträge, die nicht umterminiert werden sollen.
   */
  private HashSet<String> waUmterm = new HashSet<>();

  /**
   * IDs aller beteiligten WAufträge.
   */
  private HashSet<String> waList = new HashSet<>();

  /**
   * Arbeitsgänge, deren Belegungen ignoriert werden.
   */
  private HashSet<Integer> ignoredAllocations = new HashSet<>();

  /**
   * Alternative Maschinengruppen.
   */
  private HashMap<Integer, AlternativeMachineGroup> alternMagr
                              = new HashMap<>();

  /**
   * SchedulePE-Objekte.
   */
  public HashMap<Integer, SchedulePE> schedulePEMap = new HashMap<>();

  /********************** sonstige Variablen **********************/

  /**
   * Wurzelobjekt der Terminierung.
   */
  private BusinessObject rootObject = null;

  /**
   * Erfüllerstücklisten terminieren?
   * AF360101: termErf = true gesetzt
   */
  private final boolean termErf;

  /**
   * Terminierungsart.
   */
  private final int scheduleType;

  /**
   * Tagesbeginn für Terminierung aus Sysconf.
   */
  private final P2Time tagesBeginn;

  /**
   * Flag, welches zeigt, ob die Terminierung durch die Aufstueliautomtik 
   * ausgeführt wird. #171946
   */
  private final boolean isAutomatic;

  /**
   * Belegungen von Simulationsarbeitsgänge beim Terminieren von
   * nicht-simulativen Arbeitsgängen berücksichtigen?
   * <br>Wird im Konstruktor auf den Sysconf-Wert "IGNORE_SIMAG" (Bereich AV)
   * gesetzt.
   */
  private final boolean ignoreSimAG;

  /**
   * Sysconf-Schalter zur Steuerung der Terminierung mit alternativen
   * Maschinengruppen.
   */
  private final boolean scheduleAlternative;
  
  /**
   * Kenner. Gibt an, ob nach der Terminierung die
   * Überlast berechnet werden soll.
   */
  private boolean ueberlast = true;

  /**
   * Gibt an, ob alternative Maschinengruppen bei der Terminierung ignoriert
   * werden sollen.
   */
  private boolean ignoreAlternMagr = false;

  /**
   * Kenner. Gibt an, ob die Standortverwaltung in der Systemkonfiguration
   * aktiviert ist.
   */
  private final boolean standortverwaltung;
  
  /**
   * JobProgress-Object.
   */
  private JobProgress jobProgress = null;

  /**
   * Gibt an, ob der Terminierungscache zu aktualisieren ist.
   */
  private boolean updateCapaAllocation = true;

  /**
   * Gibt an, ob es sich um eine vereinfachte Vorwärtsterminierung handelt.
   */
  private boolean simplifiedForward = false;

  /**
   * Endtermin für Kapazitätsplanung.
   */
  private P2Time ende = null;

  /**
   * Initialisiert den Terminierungs-Cache.
   *
   * @param schedParams optionale Parameter für die Terminierung als XML-String,
   *                    null oder Leerstring bedeuten Default-Werte. Mögliche
   *                    Attribute: "waUmtermList", "termErfStueli"
   *                <br>Voreinstellungen:
   *                <br>- Alle Werkstattaufträge im Status 'in Arbeit' werden
   *                      umterminiert
   *                <br>- Erfüllerstücklisten werden mitterminiert
   * @param schedType Terminierungsart, siehe Konstanten dieser Klasse
   * @exception P2XMLException bei einem XML-Fehler
   * @exception P2ParameterException bei unzulässigem Parameter 'schedType'
   * @exception P2Exception bei einem sonstigen Fehler
   */
  public ScheduleCache(String schedParams,
                       int schedType)
    throws P2XMLException, P2ParameterException, P2Exception
  {
    XMLDocument scheduleParams;
    XMLTag root;
    String attrib, waID;
    StringTokenizer st;

    if ((schedType < SCHEDULE_BACKWARD) ||
        (schedType > SCHEDULE_AVAILABILITY)) {
      throw new P2ParameterException("A_INVPARAM|scheduleType = " + schedType);
    }

    scheduleType = schedType;
    ignoreSimAG = SysConfUtil.getBoolean("AV", "IGNORE_SIMAG");

    // Tagesbeginn holen
    tagesBeginn = ScheduleUtil.getTagesBeginn();

    scheduleAlternative = SysConfUtil.getBoolean("AV", "TERM_ALTERNATIVMAGR");
    standortverwaltung = StandortUtil.standortVerwaltung();
    
    if ((schedParams == null) || (schedParams.length() == 0)) {
      isAutomatic = false;
      termErf = true;

      return;
    }

    scheduleParams = new XMLDocument(schedParams);
    root = (XMLTag)scheduleParams.getRoot();

    // Attribut "waUmtermList"
    attrib = root.getAttribute("waUmtermList");
    if (attrib != null) {
      st = new StringTokenizer(attrib, Constants.COMMA);

      while (st.hasMoreTokens()) {
        waID = st.nextToken();
        waUmterm.add(waID);
      } // while
    } // if

    // Attribut "termErfStueli"
    attrib = root.getAttribute("termErfStueli");
    if ((attrib != null) && (attrib.equalsIgnoreCase("false"))) {
      termErf = false;
    } else {
      termErf = true;
    }

    // Attribut "astlAutomatik" #171946
    attrib = root.getAttribute("astlAutomatik");
    if ((attrib != null) && (attrib.equalsIgnoreCase("true"))) {
      isAutomatic = true;
    } else {
      isAutomatic = false;
    }

    // Attribut "ignoreAlternMagr" #171946
    attrib = root.getAttribute("ignoreAlternMagr");

    if((attrib != null) && (attrib.equalsIgnoreCase("true"))) {
      ignoreAlternMagr = true;
    }

    return;
  } // ScheduleCache
  
  
  /**
   * Initialisiert den Terminierungs-Cache für die Neuterminierung 
   * aller offenen Aufträge.
   *
   * @param rescheduleObj Rechedule-Object
   *
   * @exception P2ParameterException bei unzulässigem Parameter 'schedType'
   * @exception P2Exception bei einem sonstigen Fehler
   */
  public ScheduleCache(Reschedule rescheduleObj)
  
    throws P2ParameterException, P2Exception
  {
      
    scheduleType = ScheduleCache.SCHEDULE_ASSEMBLY;
    ignoreSimAG = SysConfUtil.getBoolean("AV", "IGNORE_SIMAG");
    // Tagesbeginn holen
    tagesBeginn = ScheduleUtil.getTagesBeginn();

    scheduleAlternative = SysConfUtil.getBoolean("AV", "TERM_ALTERNATIVMAGR");
    // Fehler in die Protokoll-Tabelle schreiben
    isAutomatic = true;
    // Erst wenn alle Auftragsstücklistenpositionen terminiert sind,
    // wird die Überlast berechnet.
    ueberlast = false;
    
    termErf = rescheduleObj.getTermErf();
    ignoredAllocations = rescheduleObj.getIgnoredAllocations();
    waList = rescheduleObj.getWAList();
    
    standortverwaltung = StandortUtil.standortVerwaltung();
    
    return;
  } // ScheduleCache


  /**
   * Holt die Maschinengruppe aus dem Cache.
   * 
   * @param ko Kostenstelle
   * @param ma Maschinengruppe
   * @return Maschinengruppe
   */
  public MachineGroup getKostMagr(String ko,
                                  String ma)
  {
    String key;
    MachineGroup km;

    key = ko.toUpperCase() + "." + ma.toUpperCase();
    km = maschinengruppe.get(key);
    return (km);
  }

  /**
   * Schreibt die Maschinengruppe in den Cache.
   * 
   * @param km KostMagr-Objekt
   */
  public void setKostMagr(MachineGroup km)
  {
    String key;

    key = (km.getKost()).toUpperCase() + "." + (km.getMagr()).toUpperCase();
    maschinengruppe.put(key, km);

    return;
  }
  /**
   * Gibt den Standort einer Maschinengruppe aus dem Cache zurück.
   * 
   * @param ko Kostenstelle
   * @param ma Maschinengruppe
   * @return Standort
   * 
   * @exception P2Exception bei einem Fehler
   */
  public String getMagrLocation(String ko,
                                String ma)
    throws P2Exception
  {
    ObjectManager manager;
    MachineGroup km;
    MagrObject magrObj;
    String location = null;
   
    km = getKostMagr(ko, ma);
    if(km == null) { 
      manager = new ObjectManager();
      try {
      magrObj = MagrFactory.search(manager, ko, ma, 
                                   ObjectConstants.READ_LOCK, 
                                   false);
      if(magrObj != null) {
        km = new MachineGroup(magrObj);
        setKostMagr(km);
      }  
    } finally {
      manager.release();
    }
    }
    return (location);
  } //getMagrLocation

  /**
   * Holt die Wiederbeschaffungszeit aus dem Cache.
   * 
   * @param artnr Artikelnummer
   * @param art "E", "F" oder "M" ((E)inkauf, (F)ertigung oder Fremd(m)ontage)
   * @return Wiederbeschaffungszeit in Tagen oder -1
   */
  public short getWbz(String artnr,
                         String art)
  {
    Short wbz;

    wbz = artikel.get(artnr + "." + art);

    if (wbz != null) {
      return (wbz.shortValue());
    } else {
      return (-1);
    }
  } // getWbz


  /**
   * Schreibt die wbz des Artikels in den Cache.
   * 
   * @param artnr Artikelnummer
   * @param art "E", "F" oder "M" ((E)inkauf, (F)ertigung oder Fremd(m)ontage)
   * @param wbz Wiederbeschaffungszeit
   */
  public void setWbz(String artnr,
                        String art,
                        short wbz)
  {
    artikel.put(artnr + "." + art, Short.valueOf(wbz));
  } // setWbz

  /**
   * Holt die Pufferzeit aus dem Cache.
   * 
   * @param artnr Artikelnummer
   * @param art "E", "F" oder "M" ((E)inkauf, (F)ertigung oder Fremd(m)ontage)
   * @return Pufferzeit in Tagen oder -1
   */
  public short getFloattime(String artnr,
                            String art)
  {
    Short floattime;

    floattime = pufferzeit.get(artnr + "." + art);

    if(floattime != null) {
      return(floattime.shortValue());
    } else {
      return -1;
    }
  } // getFloattime


  /**
   * Schreibt die Pufferzeit des Artikels in den Cache.
   * 
   * @param artnr Artikelnummer
   * @param art "E", "F" oder "M" ((E)inkauf, (F)ertigung oder Fremd(m)ontage)
   * @param floattime Pufferzeit
   */
  public void setFloattime(String artnr,
                           String art,
                           short floattime)
  {
     pufferzeit.put(artnr + "." + art, Short.valueOf(floattime));
  } // setFloattime

  /**
   * Holt den Startzeitpunkt des Erfüllers aus dem Cache.
   * 
   * @param aufstueli Nummer der Auftragsstückliste
   * @param position Positions-Nummer
   * @return Startzeitpunkt des Erfüllers oder null
   */
  protected P2Time getErfuellerStart(String aufstueli,
                                     short position)
  {
    String key;
    P2Time start = null;

    key = aufstueli + "." + position;
    if (performBOMDate.containsKey(key)) {
      start = new P2Time(performBOMDate.get(key));
    }

    return (start);
  }

  /**
   * Schreibt den Startzeitpunkt des Erfüllers in den Cache.
   * 
   * @param aufstueli Nummer der Auftragsstückliste
   * @param position Positions-Nummer
   * @param start Startzeitpunkt
   */
  protected void setErfuellerStart(String aufstueli,
                                   short position,
                                   P2Time start)
  {
    String key;

    key = aufstueli + "." + position;
    performBOMDate.put(key, start);

    return;
  }

  /**
   * Holt den Endezeitpunkt des Erfüllers aus dem Cache.
   * 
   * @param aufstueli Nummer der Auftragsstückliste
   * @param position Positions-Nummer
   * @return Endezeitpunkt des Erfüllers oder null
   */
  protected P2Time getErfuellerEnde(String aufstueli,
                                    short position)
  {
    String key;
    P2Time ende = null;

    key = aufstueli + "." + position;
    if (performBOMDate.containsKey(key)) {
      ende = new P2Time(performBOMDate.get(key));
    }

    return (ende);
  } // getErfuellerEnde

  /**
   * Schreibt den Endezeitpunkt des Erfüllers in den Cache.
   * 
   * @param aufstueli Nummer der Auftragsstückliste
   * @param position Positions-Nummer
   * @param ende Endezeitpunkt
   */
  public void setErfuellerEnde(String aufstueli,
                                  short position,
                                  P2Time ende)
  {
    String key;

    key = aufstueli + "." + position;
    performBOMDate.put(key, ende);

    return;
  } // setErfuellerEnde

  /**
   * Gibt an, ob die Erfüller-Stückliste schon terminiert wurde.
   * Als Teil-Schlüssel wird der nie erreichte Positionswert -1 verwendet.
   * 
   * @param aufstueli Nummer der Auftragsstückliste
   * @return true, falls Erfüller-Stückliste terminiert wurde, false sonst
   */
  public boolean getPerformanceBOMScheduled(String aufstueli)
  {
    String key;
    boolean ret;

    key = aufstueli + "." + (short)-1;
    ret = performBOMDate.containsKey(key);

    return (ret);
  }

  /**
   * Schreibt die Nummer der terminierten Erfüller-Stückliste in den Cache.
   * Als Teil-Schlüssel wird der nie erreichte Positionswert -1 verwendet.
   * 
   * @param aufstueli Nummer der Auftragsstückliste
   */
  protected void setPerformanceBOMScheduled(String aufstueli)
  {
    String key;

    key = aufstueli + "." + (short)-1;
    performBOMDate.put(key, new P2Time()); // Zeitpunkt an dieser Stelle irrelevant

    return;
  }

  /**
   * Löscht den Cache für die Maschinengruppen.
   */
  protected void flushMaschinengruppe()
  {
    maschinengruppe.clear();
    return;
  }

  /**
   * Löscht den Cache für die Artikel.
   */
  protected void flushArtikel()
  {
    artikel.clear();
    return;
  }

  /**
   * Löscht den Cache für die Erfüller-Stücklisten.
   */
  protected void flushErf_stueli()
  {
    performBOMDate.clear();
    return;
  }

  /**
   * Holt das Team aus dem Cache.
   * 
   * @param gruppe Team
   * @return Team
   */
  protected Team getTeam(String gruppe)
  {
    Team t;

    t = team.get(gruppe.toUpperCase());

    return (t);
  } // getTeam

  /**
   * Schreibt das Team in den Cache.
   * 
   * @param t Team-Objekt
   */
  protected void setTeam(Team t)
  {
    String key;

    key = (t.getGruppe()).toUpperCase();
    team.put(key, t);

    return;
  } // setTeam

  /**
   * Löscht den Cache für die Teams.
   */
  protected void flushTeam()
  {
    team.clear();
    return;
  } // flushTeam


  /**
   * Holt die IDs der Werkstattaufträge aus dem Cache, die nicht
   * umterminiert werden sollen.
   *
   * @return HashSet mit IDs
   */
  public HashSet<String> getWAUmterm()
  {
    return (waUmterm);
  } // getWAUmterm


  /**
   * Gibt an, ob Erfüllerstücklisten mitterminiert werden sollen.
   *
   * @return true/false
   */
  public boolean getTermErf()
  {
    return (termErf);
  } // getTermErf


  /**
   * Gibt die Terminierungsart zurück.
   *
   * @return Terminierungsart
   */
  public int getScheduleType()
  {
    return (scheduleType);
  } // getScheduleType


  /**
   * Nimmt die ID eines Werkstattauftrags in die Liste der beteiligten
   * Werkstattaufträge auf.
   *
   * @param id ID des Werkstattauftrags.
   */
  public void addToWAList(int id)
  {
    waList.add(String.valueOf(id));
    return;
  } // addToWAList


  /**
   * Holt die IDs der beteiligten Werkstattaufträge aus dem Cache.
   *
   * @return HashSet mit IDs
   */
  protected HashSet<String> getWAList()
  {
    return (waList);
  } // getWAList


  /**
   * Holt die IDs der beteiligten Werkstattaufträge aus dem Cache.
   *
   * @return String mit IDs durch "," getrennt
   */
  protected String getWAListAsIdList()
  {
    StringBuilder where = null;

    for(String waID : waList) {
      if (where == null) {
        where = new StringBuilder(waID);
      } else {
        where.append(Constants.COMMA).append(waID);
      }
    }

    if (where == null) {
      return (null);
    } else {
      return (where.toString());
    }
  } // getWAListAsIdList


  /**
   * Nimmt einen Arbeitsgang in die Liste der Arbeitsgänge auf, deren
   * Belegungen nicht berücksichtigt werden sollen.
   *
   * @param id Datenbank-ID des Arbeitsgangs
   * @exception P2ParameterException falls id = 0
   */
  protected void ignoreAllocation(int id)
    throws P2ParameterException
  {
    Integer key;

    if (id == 0) {
      throw new P2ParameterException("C_MANDATORYFIELD2|id");
    }

    key = Integer.valueOf(id);
    this.ignoredAllocations.add(key);

    return;
  } // ignoreAllocation


  /**
   * Holt die IDs der Arbeitsgänge aus dem Cache, deren Belegungen zu
   * ignorieren sind.
   *
   * @return HashSet mit Arbeitsgängen
   */
  protected HashSet<Integer> getIgnoredAllocations()
  {
    return (this.ignoredAllocations);
  } // getIgnoredAllocations


  /**
   * Gibt an, ob die Belegungen eines Arbeitsgangs zu ignorieren sind.
   *
   * @param id Datenbank-ID des Arbeitsgangs
   * @return true, falls Belegungen des Arbeitsgangs zu ignorieren sind
   */
  protected boolean isIgnoredAllocation(int id)
  {
    Integer key;

    if (id == 0) {
      return (false);
    }

    key = Integer.valueOf(id);

    return (this.ignoredAllocations.contains(key));
  } // isIgnoredAllocation


  /**
   * Entfernt einen Eintrag aus der Liste der Arbeitsgänge, deren
   * Belegungen nicht berücksichtigt werden sollen.
   *
   * @param id Datensatz-ID des Arbeitsgangs
   */
  protected void removeIgnoredAllocation(int id)
  {
    Integer key;

    if (id == 0) {
      return;
    }

    key = Integer.valueOf(id);
    this.ignoredAllocations.remove(key);

    return;
  } // removeIgnoredAllocation


  /**
   * Gibt den Tagesbeginn zurück.
   *
   * @return Tagesbeginn
   */
  public P2Time getStartOfDay()
  {
    return (this.tagesBeginn);
  } // getStartOfDay
  
  /**
   * #171946
   * Ermittelt, ob die Terminierung durch Aufstueliautomatik ausgeführt wird.
   * @return true, falls die Terminierung aus der Aufstueliautomatik ausgeführt
   *         wird, sonst false;
   */
  public boolean isAutomatic() {
    return isAutomatic;
  }


  /**
   * Belegungen von Simulationsarbeitsgänge beim Terminieren von
   * nicht-simulativen Arbeitsgängen ignorieren?
   *
   * @return <tt>true</tt>, falls Belegungen von Simulationsarbeitsgänge beim
   * Terminieren von nicht-simulativen Arbeitsgängen ignoriert werden sollen
   */
  protected boolean ignoreSimAG()
  {
    return ignoreSimAG;
  } // ignoreSimAG


  /**
   * Setzt eine alternative Maschinengruppe für einen Arbeitsgang.
   *
   * @param id ID des Arbeitsgangs
   * @param alternMagr alternative Maschinengruppe
   */
  public void setAlternativeMachineGroup(int id,
                                         AlternativeMachineGroup alternMagr)
  {
    this.alternMagr.put(Integer.valueOf(id), alternMagr);
  } // setAlternativeMachineGroup


  /**
   * Ermittelt die alternative Maschinengruppe für einen Arbeitsgang, die bei
   * der Vorwärtsterminierung verwendet wurde.
   *
   * @param id ID des Arbeitsgangs
   * @return alternMagr alternative Maschinengruppe oder <code>null</code>
   */
  public AlternativeMachineGroup getAlternativeMachineGroup(int id)
  {
    return(alternMagr.get(Integer.valueOf(id)));
  } // getAlternativeMachineGroup


  /**
   * Entfernt die alternative Maschinengruppe für einen Arbeitsgang.
   * 
   * @param id ID des Arbeitsgangs
   */
  public void removeAlternativeMachineGroup(int id)
  {
    alternMagr.remove(Integer.valueOf(id));
  } // removeAlternativeMachineGroup


  /**
   * Setzt das Wurzelobjekt der Terminierung.
   *
   * @param rootObject Wurzelobjekt der Terminierung
   */
  public void setRootObject(BusinessObject rootObject)
  {
    this.rootObject = rootObject;
  } // setRootObject

 
  /**
   * Gibt das Wurzelobjekt der Terminierung zurück.
   *
   * @return Wurzelobjekt der Terminierung
   */
  public BusinessObject getRootObject()
  {
    return rootObject;
  } // getRootObject


  /**
   * Fügt ein SchedulePE-Objekt hinzu, sofern es nicht bereits zuvor hinzugefügt
   * wurde.
   *
   * @param schedulePE SchedulePE-Objekt
   */
  protected void addSchedulePE(SchedulePE schedulePE)
  {
    Integer key;

    key = Integer.valueOf(schedulePE.getId());

    if(!schedulePEMap.containsKey(key)) {
      schedulePEMap.put(key, schedulePE);
    }
  } // addSchedulePE


  /**
   * Gibt das SchedulePE-Objekt mit einer bestimmten ID zurück.
   *
   * @param id ID desSchedulePE-Objekts
   * @return SchedulePE-Objekt oder <code>null</code>
   */
  protected SchedulePE getSchedulePE(int id)
  {
    Integer key;

    key = Integer.valueOf(id);

    return(schedulePEMap.get(key));
  } // getSchedulePE

  /**
   * Gibt an, ob die Standortverwaltung in der Systemkonfiguration aktiviert
   * ist.
   *
   * @return <tt>true</tt>, falls die Standortverwaltung in der 
   *         Systemkonfiguration aktiviert ist
   */
  public boolean standortVerwaltung()
  {
    return standortverwaltung;
  } // standortVerwaltung

   
  /**
   * Gibt an, ob die Terminierung mit alternativen Maschinengruppen immer
   * erfolgen soll oder nur bei Überlast.
   *
   * @return <tt>true</tt>, falls Terminierung mit alternativen Maschinengruppen
   *         immer erfolgen soll
   */
  protected boolean scheduleAlternative()
  {
    return scheduleAlternative;
  } // scheduleAlternative
  
  /**
   * Gibt an, ob die Überlast berechnet werden soll.
   *
   * @return <tt>true</tt>, falls die Überlast berechnet werden soll.
   */
  public boolean getUeberlast()
  {
    return ueberlast;
  } // getUeberlast
  
  /**
   * Setzt den Kenner "Ueberlast".
   *
   * @param ueberlast Überlast.
   */
  public void setUeberlast(boolean ueberlast)
  {
    this.ueberlast = ueberlast;
  } // setUeberlast


  /**
   * Setzt den Kenner <code>ignoreAlternMagr</code>.
   *
   * @param ignoreAlternMagr <tt>true</tt>, falls alternative Maschinengruppen
   *        bei der Terminierung ignoriert werden sollen   
   */
  protected void setIgnoreAlternMagr(boolean ignoreAlternMagr)
  {
    this.ignoreAlternMagr = ignoreAlternMagr;
  } // setIgnoreAlternMagr


  /**
   * Gibt an, ob alternative Maschinengruppen bei der Terminierung ignoriert
   * werden sollen.
   *
   * @return <tt>true</tt>, falls alternative Maschinengruppen bei der
   *         Terminierung ignoriert werden sollen
   */
  protected boolean ignoreAlternMagr()
  {
    return ignoreAlternMagr;
  } // ignoreAlternMagr
  
 /**
  * Generiert das Object für die Fortschrittsanzeige.
  *  
  * @param jobID Job-ID
  * @param aufstueli Auftragsstückliste
  * 
  * @throws P2Exception bei einem Fehler
  */
  public void setJobprogress(String jobID, String aufstueli)
    throws P2Exception
  {
    if(jobID != null && jobID.length() > 0) {
      this.jobProgress = new SchedulingJobProgress(jobID,
                                                   aufstueli,
                                                   this);
      this.jobProgress.setInfo();
    }
  } // setJobprogress


  /**
   * Generiert das Object für die Fortschrittsanzeige.
   *  
   * @param jobID Job-ID
   * @param aufstueli Auftragsstückliste
   * @param pos Position
   * 
   * @throws P2Exception bei einem Fehler
   */
  public void setJobprogress(String jobID, String aufstueli, short pos)
    throws P2Exception
  {
    if(jobID != null && jobID.length() > 0) {
      this.jobProgress = new PosSchedulingJobProgress(jobID,
                                                      aufstueli,
                                                      pos, this);
      this.jobProgress.setInfo();
    }
  } // setJobprogress


  /**
   * Setzt das Object für die Fortschrittsanzeige.
   *
   * @param jobProgress Fortschrittsanzeige-Object
   */
   public void setJobprogress(JobProgress jobProgress)
   {
     this.jobProgress = jobProgress;
   } // setJobprogress


   /**
    * Gibt das Object für die Fortschrittsanzeige zurück.
    *
    * @return JobProgress-Objekt
    */
    public JobProgress getJobprogress()
    {
      return this.jobProgress;
    } //getJobprogress


  /**
   * Startet Fortschrittsanzeige mit dem Text für die Rückwärtsterminierung
   * neu bei anschließenden Rückwärtsterminierung nach Vorwärtsterminierung
   * oder Mittelpunktterminierung.
   * 
   * @throws P2Exception bei einem Fehler
   */
  public void resetJobprogress() throws P2Exception {
    if(jobProgress != null) {
      jobProgress.reset();
    }
  } //resetJobprogress


  /**
   * Gibt jobID zurück.
   *
   * @return jobID
   */
  public String getJobid()
  {
    String jobID;

    if(jobProgress != null) {
      jobID = jobProgress.getJobid();
    } else {
      jobID = null;
    }
    return jobID;
  } // getJobid


  /**
   * Zeigt den Fortschritt.
   *
   * @throws P2Exception bei einem Fehler
   */
  public void jobProgress() throws P2Exception
  {
    if(jobProgress != null) {
      jobProgress.progress();
    } 
  } // getJobid


  /**
   * Setzt den Kenner "updateCapaAllocation", welcher angibt, ob der
   * Terminierungscache zu aktualisieren ist.
   *
   * @param value zu setzender Wert
   */
  public void setUpdateCapaAllocation(boolean value)
  {
    updateCapaAllocation = value;
  } // setUpdateCapaAllocation


  /**
   * Gibt an, ob der Terminierungscache zu aktualisieren ist.
   *
   * @return <tt>true</tt>, falls der Terminierungscache zu aktualisieren ist
   */
  public boolean getUpdateCapaAllocation()
  {
    return updateCapaAllocation;
  } // getUpdateCapaAllocation


  /**
   * Setzt den Kenner <code>simplifiedForward</code>, welcher angibt, ob es
   * sich um eine vereinfachte Vorwärtsterminierung handelt.
   *
   * @param simplifiedForward <tt>true</tt>, falls es sich um eine vereinfachte
   *        Vorwärtsterminierung handelt
   */
  public void setSimplifiedForward(boolean simplifiedForward)
  {
    this.simplifiedForward = simplifiedForward;
  } // setSimplifiedForward


  /**
   * Gibt an, ob es sich um eine vereinfachte Vorwärtsterminierung handelt.
   *
   * @return <tt>true</tt>, falls es sich um eine vereinfachte
   *         Vorwärtsterminierung handelt
   */
  public boolean isSimplifiedForward()
  {
    return simplifiedForward;
  } // isSimplifiedForward


  /**
   * Gibt den Endtermin für die Kapazitätsplanung zurück.
   *
   * @return Endtermin für die Kapazitätsplanung
   */
  public P2Time getEnde()
  {
    return ende;
  } //getEnde


  /**
   * Setzt den Endtermin für die Kapazitätsplanung.
   *
   * @param ende Endtermin für die Kapazitätsplanung
   */
  public void setEnde(P2Time ende)
  {
    this.ende = ende;
  } //setEnde


  /**
   * Gibt an, ob die Überlast berechnet werden soll.
   *
   * @return <code>true</code>, falls die Überlast
   *         werden soll, sonst <code>false</code>
   * @throws P2Exception bei einem Fehler
   */
  public boolean allowOverloadCalculation() throws P2Exception
  {
    Boolean threadValue;
    boolean allow;

    allow = getUeberlast() && SysConfUtil.getBoolean("av", "ueberlast");

    if(allow) {
      threadValue = (Boolean)ThreadLocalHashtable.get(
                                   ThreadLocalHashtable.SCOPE_SCHEDULE_SIMULATION,
                                   "ueberlast");
      if(threadValue != null) {
        allow = threadValue.booleanValue();
      }
    }

    return allow;
  } // allowOverloadCalculation
} //ScheduleCache
