﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace p2plus.Fischbach_av_gant {

  public class BdeStatus {

    public JArray jsonBdeStatusObjects { get; set; }

    public Dictionary<string, int> magrStatus { get; set; } 
    public string requestUrl { get; set; }
    public string prodSrv { get; set; }
    public string devSrv { get; set; }

    //Get status from BDE via HTTP
    public Boolean getStatus () {
      
      //Production or development
      string url = devSrv + "/machinestatus";
      if (requestUrl.ToLower().Contains("/applusprod")) {
        url = prodSrv + "/machinestatus";
      }

      string jsonBdeStatusTxt = string.Empty;

      try { 
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
        request.AutomaticDecompression = DecompressionMethods.GZip;

        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
        using (Stream stream = response.GetResponseStream())
      
        using (StreamReader reader = new StreamReader(stream)) {
          reader.BaseStream.ReadTimeout = 300;
          jsonBdeStatusTxt = reader.ReadToEnd();
        }
      } catch (System.Net.WebException) {
        //In case anything goes wrong here, just return false
        return false; ;
      }

      jsonBdeStatusObjects = JArray.Parse(jsonBdeStatusTxt);

      //Add magr and cycles to name value list
      magrStatus = new Dictionary<string, int>();

      foreach (JObject jsonBdeStatusItem in jsonBdeStatusObjects) {
        string magr = (string)jsonBdeStatusItem.Property("magr");
        string cycleDiffTxt = (string)jsonBdeStatusItem.Property("cycleDiff");
        int cycleDiff = 0;
        int ignoreMe = 0;
        bool successfullyParsed = int.TryParse(cycleDiffTxt, out ignoreMe);
        if (successfullyParsed) {
          cycleDiff = int.Parse(cycleDiffTxt);
        } 

        magrStatus.Add(magr, cycleDiff);
      }

      return true;
    }

  }
}