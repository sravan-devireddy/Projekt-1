﻿using Newtonsoft.Json.Linq;
using p2plus.p2core;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Collections.Generic;

namespace p2plus.Fischbach_av_gant {

  public class MagrConfList {
    public string[] magrIDList { get; set; }
    public string[] magrNameList { get; set; }

    public int[] magrSortList { get; set; }
    public string groupStock { get; set; }
    public string connectString { get; set; }
    public string mandant { get; set; }
    private DataTable magrTable = null;
    //Used to cycle through the cartrige task list
    public int counter = 0;

    public List<AvGantTreeParent> treeGroupList { get; set; }

    public MagrConfList() {
      treeGroupList = new List<AvGantTreeParent>();
    }   

    public void getMagrListSysconfConfig(string configItem) {
      string magrConf;

      magrConf = Sysconf.getString("CUSTOM", configItem);
      if (magrConf != null) {
        string[] magrList = magrConf.Split(',');

        magrIDList = new string[magrList.Length];
        magrNameList = new string[magrList.Length];
        magrSortList = new int[magrList.Length];

        for (int ii = 0; ii < magrList.Length; ii++) {
          string magrValues = magrList[ii];
          string[] magrValueList = magrValues.Split('|');
          if (magrValueList.Length == 2) {
            magrIDList[ii] = magrValueList[0];
            magrNameList[ii] = magrValueList[1];
            magrSortList[ii] = 0;
          }
        }
      }
    }

    /// <summary>
    /// Reads the magr config for injection mold machines from sysconfig
    /// </summary>
    /// <param name="configItem"></param>
    /// <param name="groupName"></param>
    public void getMagrListSysconfConfigGroup(string configItem, string groupName) {

      string magrConf;
      groupStock = "";
      magrConf = Sysconf.getString("CUSTOM", configItem);

      if (magrConf == null) {
        return;
      }
      JArray magrObjects = JArray.Parse(magrConf);

      //Loop over main groups e.g. Kartuschen / Duesen ...
      foreach (JObject magrObject in magrObjects) {

        string group = (string)magrObject.Property("group");

        if (!group.Equals(groupName)) {
          continue;
        }

        JArray magrList = (JArray)magrObject["magrs"];

        JArray subMagrList = new JArray();
        //check if there are subgroups
        JArray subGroupList = (JArray)magrObject["subgroups"];
        if (subGroupList != null) {
          //Loop subgroups
          foreach (JObject subGroup in subGroupList) {

            string subGroupName = (string)subGroup["subgroupname"];
            AvGantTreeParent treeGroupItem = new AvGantTreeParent();
            treeGroupItem.name = subGroupName;

            subMagrList = (JArray)subGroup["magrs"];

            //Add magrs in subgroups to main magr list
            if (subMagrList != null) {
              foreach (JObject subMagr in subMagrList) {
                magrList.Add(subMagr);
                string magrName = (string)subMagr["magr"];
                treeGroupItem.children.Add(magrName);
              }  
            }

            treeGroupList.Add(treeGroupItem);
          }
        }
                
        JArray magrListSorted = new JArray(magrList.OrderBy(obj => (string)obj["magr"]));

        groupStock = (string)magrObject.Property("stock");

        magrIDList = new string[magrListSorted.Count];
        magrNameList = new string[magrListSorted.Count];
        magrSortList = new int[magrListSorted.Count];
        int incrementor = 0;

        foreach (JObject magr in magrListSorted) {
          JValue magrVal = (JValue)magr["magr"];
          string magrID = magrVal.ToString();
          JValue nameVal = (JValue)magr["name"];
          string magrName = nameVal.ToString();
          JValue sortVal = (JValue)magr["sort"];
          int magrSort = sortVal.ToObject<int>();

          string dbMagrName = getMagrName(magrID);
          if (!dbMagrName.Equals("")) {
            magrName = dbMagrName;
          }

          magrIDList[incrementor] = magrID;
          magrNameList[incrementor] = magrName;
          magrSortList[incrementor] = magrSort;
          incrementor++;
        }

        break;
      }
    }

    private string getMagrName(string magrID) {
      DataRow currentRow;

      string sql = @"SELECT magr, name FROM magr WHERE KOST = '01000' AND mandant = @FiMandant";

      //Fill table if not yet done
      if (magrTable == null) {
        SqlConnection conn;
        magrTable = new DataTable();
        CultureInfo provider = CultureInfo.InvariantCulture;

        using (conn = new SqlConnection(connectString))
        using (SqlDataAdapter dataAdapter = new SqlDataAdapter()) {
          var cmd = new SqlCommand(sql, conn);
          cmd.Parameters.Add("@FiMandant", SqlDbType.VarChar).Value = mandant;
          dataAdapter.SelectCommand = cmd;
          dataAdapter.Fill(magrTable);
        }
      }

      for (int i = counter; i < magrTable.Rows.Count; i++) {
        currentRow = magrTable.Rows[i];
        string currentMagr = currentRow["MAGR"].ToString();

        if (currentMagr.ToUpper().Equals(magrID.ToUpper())) {
          return currentRow["NAME"].ToString();
        }
      }

      return "";
    }
  }
}