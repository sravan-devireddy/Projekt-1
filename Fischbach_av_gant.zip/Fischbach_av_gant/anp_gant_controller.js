﻿'use strict';

var app = angular.module('GanttStable',
['gantt', 'mgcrea.ngStrap', 'ngAnimate', 'ngSanitize',
        'gantt.sortable',
        'gantt.movable',
        'gantt.tooltips',
        'gantt.bounds',
        'gantt.progress',
        'gantt.table',
        'gantt.tree',
        'gantt.groups',
        'gantt.resizeSensor',
        'gantt.overlap',
        'gantt.dependencies',
        'smart-table',
        'angular.filter',
        'blockUI'
]);

app.config(function ($modalProvider) {
  angular.extend($modalProvider.defaults, {
    html: true
  });
})

//Switching on html5Mode causes completely not working this thing in IE
app.config(['$locationProvider', function ($locationProvider) {
  $locationProvider.html5Mode({
    enabled: false,
    requireBase: false
  });
}]);

app.config(function (blockUIConfig) {
  // Change the default overlay message
  blockUIConfig.message = 'Laden ...';

  // Change the default delay to 100ms before the blocking is visible
  blockUIConfig.delay = 10;
});

app.controller('Ctrl',
  ['$scope', '$rootScope', '$interval', '$http',
    '$templateCache', '$timeout', '$alert', '$modal',
    '$confirmComment', '$print', '$userdata', '$notedata', '$avdata',
    '$filter', '$location', 'blockUI',
    function ($scope, $rootScope, $interval, $http,
      $templateCache, $timeout, $alert, $modal,
      $confirmComment, $print, $userdata, $notedata, $avdata,
      $filter, $location, blockUI) {

  //$scope.registerApi = function (api) {
  //api.core.on.ready($scope, function () {

  //$scope.loadAsync(true);

  //api.tasks.on.rowChange($scope, function(task, oldRow) {
  //  console.log("task:" + task.row.model.name + "  oldRow" + oldRow.model.name);
  //});
  //});
  //};

  $scope.getAllUrlParams = function (url) {
    // get query string from url (optional) or window
    var queryString = url ? url.split('?')[1] : window.location.search.slice(1);

    // we'll store the parameters here
    var obj = {};

    // if query string exists
    if (queryString) {

      // stuff after # is not part of query string, so get rid of it
      queryString = queryString.split('#')[0];

      // split our query string into its component parts
      var arr = queryString.split('&');

      for (var i = 0; i < arr.length; i++) {
        // separate the keys and the values
        var a = arr[i].split('=');

        // set parameter name and value (use 'true' if empty)
        var paramName = a[0];
        var paramValue = typeof (a[1]) === 'undefined' ? true : a[1];

        // (optional) keep case consistent
        paramName = paramName.toLowerCase();
        if (typeof paramValue === 'string') paramValue = paramValue.toLowerCase();

        // if the paramName ends with square brackets, e.g. colors[] or colors[2]
        if (paramName.match(/\[(\d+)?\]$/)) {

          // create key if it doesn't exist
          var key = paramName.replace(/\[(\d+)?\]/, '');
          if (!obj[key]) obj[key] = [];

          // if it's an indexed array e.g. colors[2]
          if (paramName.match(/\[\d+\]$/)) {
            // get the index value and add the entry at the appropriate position
            var index = /\[(\d+)\]/.exec(paramName)[1];
            obj[key][index] = paramValue;
          } else {
            // otherwise add the value to the end of the array
            obj[key].push(paramValue);
          }
        } else {
          // we're dealing with a string
          if (!obj[paramName]) {
            // if it doesn't exist, create property
            obj[paramName] = paramValue;
          } else if (obj[paramName] && typeof obj[paramName] === 'string') {
            // if property does exist and it's a string, convert it to an array
            obj[paramName] = [obj[paramName]];
            obj[paramName].push(paramValue);
          } else {
            // otherwise add the property
            obj[paramName].push(paramValue);
          }
        }
      }
    }

    return obj;
  }

  function updateData() {

    //Reload complete application periodically 
    if ($scope.autoReload) {
      if ($scope.lastLoad < moment().subtract({ minutes: 120 })) {
        location.reload();
        return;
      } else {
        $avdata.loadAsync(false, $userdata.getMandant(), $scope.magrGroupSelected, $scope);
      }
    }  
  }
  $scope.intervalInstance = $interval(updateData, 60000 * 5);

  //$scope.getToday = new Date();
  $scope.autoReload = false;
  $scope.reloadOff = false; //disables reloading after assignment
  $scope.autoMove = true;
  $scope.dropEnd = true;
  $scope.statusText = "";

  $scope.noteTxt;
  $scope.NoteTimeout;

  $scope.lastLoad = moment();
  $scope.responseStart = moment();
  $scope.user = "";
  $scope.login = "";
  $scope.environment = "";
  $scope.inProgress = false;

  $scope.downTimeDynItem = '02050';
  $scope.downTimeFixItem = '02000';
  $scope.downTimeDynItemSG = '01050';
  $scope.downTimeFixItemSG = '01000';

  $scope.dateRangeDaysBefore = 4;
  $scope.dateRangeDaysAfter = 6;
  $scope.dateRangeDaysBeforeSG = 10;
  $scope.dateRangeDaysAfterSG = 30;

  $scope.magrList = [];
  $scope.magrGroupSelected;
  $scope.magrGroupStock = '02000'; //Initialize with SD stock magr
  $scope.fillMagrList = function () {
    //get real magrs
    var magrRec;

    //already filled
    if ($scope.magrList.length > 0) {
      return;
    }

    for (var i = 0; i < $scope.data.length; i++) {
      magrRec = $scope.data[i];
      if (typeof (magrRec.magr) == "undefined")
        continue;

      if (!isNumeric(magrRec.magr))
        continue;

      if ($scope.machineType == 'SD' && !magrRec.magr.startsWith("020") && !magrRec.magr.startsWith("01"))
        continue;

      if ($scope.machineType == 'SG' && !magrRec.magr.startsWith("010") && !magrRec.magr.startsWith("02"))
        continue
      
      $scope.magrList.push(magrRec.magr)
    }
  }

  function isNumeric(str) {
    if (typeof str != "string") return false // we only process strings!  
    return !isNaN(str) && // use type coercion to parse the _entirety_ of the string (`parseFloat` alone does not do this)...
      !isNaN(parseFloat(str)) // ...and ensure strings of whitespace fail
  }
 
  $scope.urlParams = $scope.getAllUrlParams();
  if ($scope.urlParams.daysbefore) {
    $scope.dateRangeDaysBefore = $scope.urlParams.daysbefore;
    $scope.dateRangeDaysBeforeSG = $scope.urlParams.daysbefore;
  }
  if ($scope.urlParams.daysafter) {
    $scope.dateRangeDaysAfter = $scope.urlParams.daysafter;
    $scope.dateRangeDaysAfterSG = $scope.urlParams.daysafter;
  }

  if ($scope.urlParams.autoreload) {
    $scope.autoReload = true;
  }

  if ($scope.urlParams.machinetype) {
    $scope.machineType = $scope.urlParams.machinetype.toUpperCase();
  } else {
    $scope.machineType = 'SD';
  }

  $scope.taskEvent = function (event, action) {
    console.log('taskevent');
    //$scope.taskBeforeObject = event.task.clone();
  };

  $scope.saveNoteTxt = function (newNote) {
    if ($scope.NoteTimeout) {
      $timeout.cancel($scope.NoteTimeout);
    }
    $scope.NoteTimeout = $timeout(function () {
      console.log(newNote);

      $scope.setMessage("Note set...", false);



      $notedata.setMandant($userdata.getMandant());
      $notedata.setType($scope.machineType);
      $notedata.setNoteData(newNote);
      var noteDataPromise = $notedata.setNoteDataPromise();
      noteDataPromise.then(function (result) {
        $scope.setMessage("Fertig", true);
        $scope.setMessage("Debug: SetNoteData returned", false);
        let textarea = angular.element(document.querySelectorAll("[focusaftersave]"));
        textarea.focus();
      });

    }, 2000);
  }

  $scope.setMessage = function (text, insertBeforeLineBreak) {
    if (text.indexOf("Debug:") != -1) {
      return;
    }
    if ($scope.statusText.length > 1000) {
      $scope.statusText = $scope.statusText.substring(0, 1000);
    }
    
    if (insertBeforeLineBreak) {
      let ms = moment().diff($scope.responseStart);
      var n = $scope.statusText.indexOf("\n");
      $scope.statusText = $scope.statusText.substring(0, n) + text + ' ms:' + ms + $scope.statusText.substring(n);
    } else {
      $scope.responseStart = moment();
      $scope.statusText = new moment().format("HH:mm:ss") + " " + text + "\n" + $scope.statusText;
    }    
  }

  $scope.options = {
    scale: 'hour',
    taskOutOfRange: 'truncate',
    autoExpand: 'none',
    currentDate: 'line',
    columnWidth: 76,
    width: true,
    zoom: 1,
    headers: ['week', 'day', 'hour'],
    columnMagnet: '1 minute',
    taskLimitThreshold: -1,
    columnLimitThreshold: -1,

    tableRowFormatters: {
      'model.workload': function (value, column, row) {
        return value + 'h';
      }
    },

    tableRowHeaders: {
      'model.name': 'Name',
      'model.magr': 'Magr',
      'model.workload': 'Last',
      'model.palets': 'Pal.',
      'model.late': 'Late'
    },

    api: function (api) {
      // API Object is used to control methods and events from angular-gantt.
      $scope.api = api;

      api.core.on.ready($scope, function () {
        //api.tasks.on.rowChange($scope, logTaskEvent('tasks.on.rowChange', task));

        // When gantt is ready, load data.
        // `data` attribute could have been used too.
        /*$userdata.setMandant('EN');
        $scope.loadUserData();
        console.log('mandant:' + $userdata.getMandant());
        $scope.loadAsync(true);*/

        $scope.options.fromDate = moment().subtract({ days: $scope.dateRangeDaysBefore, hours: 0, minutes: 0 });
        $scope.options.toDate = moment().add({ days: $scope.dateRangeDaysAfter, hours: 0, minutes: 0 });
        $scope.options.scale = 'hour';
        if ($scope.machineType == 'SG') {
          $scope.options.fromDate = moment().subtract({ days: $scope.dateRangeDaysBeforeSG, hours: 0, minutes: 0 });
          $scope.options.toDate = moment().add({ days: $scope.dateRangeDaysAfterSG, hours: 0, minutes: 0 });
          $scope.options.scale = '8 hours';
        }

        $scope.setMessage("Benutzerdaten...", false);
        var userDataPromise = $userdata.getUserDataPromise();
        userDataPromise.then(function (result) {
          $scope.setMessage("Fertig", true);
          $scope.setMessage("Debug: GetUserData returned", false);
          //$avdata.loadAsync(true, $userdata.getMandant(), $scope);

          //Notiz
          $scope.setMessage("Note get...", false);
          $notedata.setMandant($userdata.getMandant());
          $notedata.setType($scope.machineType);
          var noteDataPromise = $notedata.getNoteDataPromise();
          noteDataPromise.then(function (result) {
            $scope.setMessage("Fertig", true);
            $scope.setMessage("Debug: GetNoteData returned", false);
            $scope.noteTxt = $notedata.getNoteData();
          });

          //Spritzguss
          if ($scope.machineType.toUpperCase() == 'SG') {

            $scope.setMessage("Magr Konfiguration...", false);
            var magrGroupDataPromise = $avdata.getMagrGroupDataPromise();
            magrGroupDataPromise.then(function (result) {
              $scope.setMessage("Fertig", true);
              $scope.setMessage("Debug: GetMagrGroupData returned", false);

              $scope.magrGroupData = $avdata.getMagrGroupData();
              $scope.magrGroupSelected = $scope.magrGroupData[0];
              $scope.magrGroupStock = $scope.magrGroupSelected.stock;

              $avdata.loadAsync(true, $userdata.getMandant(), $scope.magrGroupSelected, $scope);

              //expand side data
              $timeout(function () {
                $scope.api.side.setWidth(undefined);
              }, 500);
              $timeout(function () {
                $scope.api.side.setWidth(undefined);
              }, 1000);
              $timeout(function () {
                $scope.api.side.setWidth(undefined);
              }, 2000);

            });
          } else {
            //Siebdruck
            $avdata.loadAsync(true, $userdata.getMandant(), "", $scope);
          }
        });

        api.tasks.on.moveEnd($scope, function (task, oldRow) {
          if ($scope.inProgress)
            return;

          var data = task.model.data;
          var from = task.model.from;
          var to = task.model.to;
          if (data.artikel == $scope.downTimeFixItem || data.artikel == $scope.downTimeDynItem ||
              data.artikel == $scope.downTimeFixItemSG || data.artikel == $scope.downTimeDynItemSG) {
            $scope.dropAsync('moveDowntimeInMagr', task.row.model.id, task.row.model.id, from, to, data, '');
          } else {
            $scope.dropAsync('moveTaskInMagr', task.row.model.id, task.row.model.id, from, to, data, '');
          }
        }),

        api.tasks.on.resizeEnd($scope, function (task) {
          var data = task.model.data;
          if (data.artikel == $scope.downTimeFixItem || data.artikel == $scope.downTimeDynItem ||
              data.artikel == $scope.downTimeFixItemSG || data.artikel == $scope.downTimeDynItemSG) {
            var from = task.model.from;
            var to = task.model.to;
            $scope.dropAsync('resizeDowntimeInMagr', task.row.model.id, task.row.model.id, from, to, data, '');
          }
        }),

        api.tasks.on.rowChange($scope, function (task, oldRow) {
          $scope.inProgress = true;

          var data = task.model.data;

          //Machine downtime
          if (data.artikel == $scope.downTimeFixItem || data.artikel == $scope.downTimeDynItem ||
              data.artikel == $scope.downTimeFixItemSG || data.artikel == $scope.downTimeDynItemSG) {
            //console.log('downtime');
            //var date = api.core.getDateByPosition(task.left);
            if (task.row.model.magr == 'stock') {
              var from = task.model.from;
              var to = task.model.to;
              $scope.dropAsync('changeRowDowntimeToStock', oldRow.model.id, $scope.magrGroupStock, from, to, data, '');
            } else {
              $scope.dropDownTime(task, oldRow);
            }
          }
          //Always attach to end
          else if ($scope.dropEnd) {
            if (task.row.model.magr == 'stock') {
              $scope.dropAsync('changeRowTaskToStock', oldRow.model.id, $scope.magrGroupStock, "", "", data, '');
            } else {
              $scope.checkProductAlreadyPlanned(task.row.model.id, data.artikel);
              $scope.dropAsync('changeRowTaskToMagrEnd', oldRow.model.id, task.row.model.id, "", "", data, '');
            }
          //Insert before following task
          } else {
            if (task.row.model.magr == 'stock') {
              $scope.dropAsync('changeRowTaskToStock', oldRow.model.id, $scope.magrGroupStock, "", "", data, '');
            } else {
              //drop in between
              $scope.dropTaskInBetween(task, oldRow);
            }
          }
        });
      });
      api.core.on.rendered($scope, function () {
      });
    }
  };

  //Called, when the magr group is changed
  $scope.magrGroupChanged = function () {
    $scope.magrList = [];
    $scope.magrGroupStock = $scope.magrGroupSelected.stock;
    $avdata.loadAsync(true, $userdata.getMandant(), $scope.magrGroupSelected, $scope)
  }

  //Called by the GUI buttons "-" and "+" for the zoom
  $scope.setZoom = function (crement) {
    let localZoom = Math.round(($scope.options.zoom + crement) * 10) / 10;
    if (localZoom >= 0.1 && localZoom <= 5) {
      $scope.options.zoom = localZoom;
    }
  }

  $scope.canAutoWidth = function (scale) {
    if (scale.match(/.*?hour.*?/) || scale.match(/.*?minute.*?/)) {
      return false
    }
    return true
  }

  $scope.getColumnWidth = function (widthEnabled, scale, zoom) {
    if (!widthEnabled && $scope.canAutoWidth(scale)) {
      return undefined
    }

    if (scale.match(/.*?week.*?/)) {
      return 150 * zoom
    }

    if (scale.match(/.*?month.*?/)) {
      return 300 * zoom
    }

    if (scale.match(/.*?quarter.*?/)) {
      return 500 * zoom
    }

    if (scale.match(/.*?year.*?/)) {
      return 800 * zoom
    }

    return 40 * zoom
  }

  $scope.dropTaskInBetween = function (task, oldRow) {
    var row = task.row.tasks;
    var movedTaskFound = false;
    var nextTaskEndDate, nextTaskId = -1;
    var newEndDate = '';
    
    //find following task
    for (var i = 0; i < row.length; i++) {
      var taskInRow = row[i];
      //store following task data
      if (movedTaskFound) {
        nextTaskEndDate = taskInRow.model.to;
        nextTaskId = taskInRow.model.id;
        break;
      }
      //Moved task found
      if (taskInRow.model.id == task.model.id) {
        movedTaskFound = true;
      }
    }

    //Move new end date minus 5 minutes from next task start date
    if (nextTaskId != -1) {
      newEndDate = moment(nextTaskEndDate).add(-5, 'minutes');
    }
    $scope.dropAsync('changeRowTaskToMagrBetween', oldRow.model.id, task.row.model.id, "", newEndDate, task.model.data, '');
  }

  $scope.dropDownTime = function (task, oldRow) {
    $rootScope.downTimeType = 'dyn';
    $rootScope.machineType = $scope.machineType;

    var data = task.model.data;
    if (data.artikel == $scope.downTimeFixItem || data.artikel == $scope.downTimeFixItemSG) {
      $rootScope.downTimeType = 'fix';
    }

    if (!oldRow.model.id.startsWith("02000") && !task.row.model.id.startsWith("02000") && !oldRow.model.id.startsWith("0199") && !task.row.model.id.startsWith("0199")) {
      var message = 'Verschieben von Aufallzeiten zwischen Maschinen ist nicht erlaubt!';
      $scope.alertBase(message);
      $avdata.loadAsync(true, $userdata.getMandant(), $scope.magrGroupSelected, $scope)
    } else {
      $confirmComment.show().then(
          function (res) {
            if (res.res === 'save') {
              $scope.dropAsync('changeRowDowntimeToMagr', oldRow.model.id, task.row.model.id, task.model.from, task.model.to, data, res.comment);
            } else {
              $avdata.loadAsync(true, $userdata.getMandant(), $scope.magrGroupSelected, $scope)
            }
          })
    }
  }

  $scope.cartridgeStats = [];
  $scope.displayCartridgeStats = [];
  $scope.magrGroupData = [];
  $scope.cartridgeGroupBy = 'cartridge';

  $scope.loadCartridgeStats = function () {

    $scope.cartridgeStats = [];

    for (var ii = 0; ii < $scope.data.length; ii++) {
      var magrRec = $scope.data[ii];
      
      if (typeof (magrRec.tasks) != "undefined") {
        var tasks = magrRec.tasks;
        for (var jj = 0; jj < tasks.length; jj++) {
          var taskItem = tasks[jj].data;
          $scope.addCartridgeStat(taskItem.cartridgeName, taskItem.baseColour, taskItem.mengeInt, taskItem.artikel);
        }
      }
    }

    $scope.cartridgeStats.sort(compareCartridges);
    //Clone array
    $scope.displayCartridgeStats = Array.from($scope.cartridgeStats);

  }; 

  $scope.addCartridgeStat = function (name, baseColour, amountInt, item) {
    var found = 0;

    if (name == '')
      return;

    for (var ii = 0; ii < $scope.cartridgeStats.length; ii++) {
      var statItem = $scope.cartridgeStats[ii];
      var customer = item.substring(0, 2);
      if (statItem.cartridge == name && statItem.baseColour == baseColour && statItem.customer == customer) {

        var currentSumInt = statItem.sumInt;
        currentSumInt += amountInt;
        statItem.sumInt = currentSumInt;

        statItem.sum = currentSumInt.toLocaleString();

        statItem.items += ' ' + item;

        found = 1;
      }
    }
    
    if (found == 0) {
      var statItem = {
        cartridge: name,
        baseColour: baseColour,
        sum: amountInt.toLocaleString(),
        sumInt: amountInt,
        items: item,
        customer: item.substring(0,2)
      }
      $scope.cartridgeStats.push(statItem);
    }
  };

  function compareCartridges(a, b) {
    if (a.cartridge < b.cartridge) {
      return -1;
    }
    if (a.cartridge > b.cartridge) {
      return 1;
    }
    if (a.cartridge == b.cartridge) {
      if (a.baseColour < b.baseColour) {
        return -1;
      }
      if (a.baseColour > b.baseColour) {
        return 1;
      }
      if (a.baseColour == b.baseColour) {
        if (a.customer < b.customer) {
          return -1;
        }
        if (a.customer > b.customer) {
          return 1;
        }
        return 0;
      }
    }
  }

  var shift1start = moment();
  shift1start.set({ hour: 6, minute: 0, second: 0, millisecond: 0 });
  var shift1ende = shift1start.clone();
  shift1ende.add(8, 'hours');
  var shift2start = shift1ende.clone();
  shift2start.add(8, 'hours');
  var shift2ende = shift2start.clone();
  shift2ende.add(8, 'hours');
  var shift3start = shift2ende.clone();
  shift3start.add(8, 'hours');
  var shift3ende = shift3start.clone();
  shift3ende.add(8, 'hours');

  $scope.timespans = [{
    id: "1",
    name: "Schicht1",
    from: shift1start,
    to: shift1ende,
    color: '#dbfffd'
  }, {
    id: "3",
    name: "Schicht3",
    from: shift2start,
    to: shift2ende,
    color: '#dbfffd'
  }, {
    id: "2",
    name: "Schicht2",
    from: shift3start,
    to: shift3ende,
    color: '#dbfffd'
  }];

  //Called by the GUI button "Jetzt"
  $scope.move = function () {
    var ganttPosition = $scope.api.gantt.currentDateManager.position;
    $scope.api.scroll.to(ganttPosition - 100);
  }

  //Called by the GUI button "Laden"
      $scope.loadAsync = function (force) {
        $avdata.loadAsync(force, $userdata.getMandant(), $scope.magrGroupSelected, $scope)
  }

  //Called by the GUI button "Neu planen"
  $scope.reconcat = function () {
    if ($scope.data != null) {
      $scope.fillMagrList();
    }

    if ($scope.magrList.length > 0) {
      blockUI.start("Neu planen ...");
      $scope.reconcatAsync($scope.magrList, 0);
    }
  }

  $scope.reconcatAsync = function (magrArray, magrIndex) {

    //End recursion ...
    if (magrIndex >= magrArray.length) { 
      $avdata.loadAsync(true, $userdata.getMandant(), $scope.magrGroupSelected, $scope)
      return;
    }

    $scope.setMessage("Verbinden " + magrArray[magrIndex] + "...", false);
    $http({
      url: "anp_gant_json.asmx/reconcatMagr",
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      data: '{magr: ' + magrArray[magrIndex] + '}'
    }).then(function onSuccess(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      //$scope.data = JSON.parse(data.d);

    }).catch(function onError(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      console.log(data.Message);
      alert(data.Message)
    }).finally(function () {
      //recursively call next magr re-concatenate
      $scope.setMessage("Fertig", true);
      magrIndex++;
      $scope.reconcatAsync(magrArray, magrIndex);     
    });
  }

  $scope.checkProductAlreadyPlanned = function (targetMagr, artikel) {

    for (var ii = 0; ii < $scope.data.length; ii++) {
      var magrRec = $scope.data[ii];
      var thisMagrId = parseInt(magrRec.id, 10);
      var targetMagrId = parseInt(targetMagr, 10);
      
      if (typeof (magrRec.tasks) != "undefined" && thisMagrId != targetMagrId && thisMagrId >= 2001 && thisMagrId <= 2009) {
        
        var tasks = magrRec.tasks;
        
        for (var jj = 0; jj < tasks.length; jj++) {
          var taskItem = tasks[jj].data;
          if (taskItem.artikel == artikel) {
            $scope.alertProductAlreadyPlanned(artikel, magrRec.id);
          }
        }
      }
    }
  };

  $scope.alertProductAlreadyPlanned = function (product, magr) {
    var message = 'Produkt:' + product + ' ist auch schon auf Magr ' + magr + ' eingeplant!';
    
    $scope.alertBase(message);
  }

  $scope.alertBase = function (message) {
    $scope.setMessage(message, false);

    var myAlert = $alert({
      title: 'Hinweis',
      content: message,
      placement: 'top',
      type: 'info',
      animation: 'am-fade-and-slide-top',
      duration: 15,
      keyboard: true,
      show: true
    });
  }

  $scope.dropAsync = function (actionType, fromMagrIn, toMagrIn, toFromDateIn, toEndDateIn, dataArray, comment) {
    blockUI.start("Wird eingeplant ...");

    //save autoreload state and disable
    var reloadState = $scope.autoReload;
    if ($scope.autoReload == true) {
      $scope.autoReload = false;
    }

    fromMagrIn = fromMagrIn.substring(0, 5);
    toMagrIn = toMagrIn.substring(0, 5);

    if (isNaN(fromMagrIn) || isNaN(toMagrIn)) {
      $scope.setMessage("Nicht erlaubt", true);
      //restore autoreload
      $scope.inProgress = false;
      $scope.autoReload = reloadState;
      blockUI.stop();
      $avdata.loadAsync(true, $userdata.getMandant(), $scope.magrGroupSelected, $scope)

      return;
    }

    var url = "anp_gant_json.asmx/assignWAuftragToMagr"

    if (actionType == 'changeRowDowntimeToMagr' || actionType == 'moveDowntimeInMagr' || actionType == 'resizeDowntimeInMagr') {
      var url = "anp_gant_json.asmx/assignDowntimeToMagr"
    }

    if (actionType == "changeRowTaskToStock" || actionType == 'changeRowDowntimeToStock') {
      var url = "anp_gant_json.asmx/unassignWAuftrag"
    }
    
    var postData = {
      actionType: actionType,
      fromMagr : fromMagrIn,
      toMagr: toMagrIn,
      toFromDate: toFromDateIn,
      toEndDate: toEndDateIn,
      waId: dataArray.waid,
      waPosId: dataArray.waposid,
      cartridgeName: dataArray.cartridgeName,
      baseColour: dataArray.baseColour,
      particularity: dataArray.particularity,
      print: dataArray.print,
      combiCode: dataArray.combiCode,
      comment: comment
    };

    $scope.setMessage("Ablegen...", false);
    $http({
      url: url,
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      data: postData
    }).then(function onSuccess(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      //$scope.data = JSON.parse(data.d);

    }).catch(function onError(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      console.log(data.Message);      
      var P2ProblemException = data.Message.split('\n')[0].replace("com.apag.p2plus.p2core.p2exceptions.P2ProblemException:", "");
      $scope.setMessage(P2ProblemException, false);
      console.log(data.Message);
      //alert(P2ProblemException)
      var myAlert = $alert({
        title: 'Hinweis',
        content: P2ProblemException,
        placement: 'top',
        type: 'danger',
        animation: 'am-fade-and-slide-top',
        duration: 15,
        keyboard: true,
        show: true
      });

    }).finally(function () {
      $scope.setMessage("Fertig", true);
      //restore autoreload
      $scope.inProgress = false;
      $scope.autoReload = reloadState;
      if ($scope.reloadOff) {
        blockUI.stop();
      } else {
        $avdata.loadAsync(true, $userdata.getMandant(), $scope.magrGroupSelected, $scope)
      }
    });
  }

  $scope.printPreview = function (docFormat) {
    $scope.fillMagrList();
    var magrList = $scope.magrList.join("|");
    $print.preview($userdata.getUser(), $userdata.getLogin(), $userdata.getEnvironmen(), $userdata.getMandant(), docFormat, $scope.options.fromDate, $scope.options.toDate, magrList);
  }

  $scope.printNotReleased = function (docFormat) {
    $print.notReleased($userdata.getUser(), $userdata.getLogin(), $userdata.getEnvironmen(), $userdata.getMandant(), $scope.options.fromDate, $scope.options.toDate);
  }
  //CUSTOM:BEGIN:FI/AKH:29.04.2022 FIM0000129: SD Plantafel: Neuer Excel Report
  $scope.extendOrders = function (docFormat) {
    $print.extendOrdersReport($userdata.getUser(), $userdata.getLogin(), $userdata.getEnvironmen(), $userdata.getMandant(), $scope.options.fromDate, $scope.options.toDate);
  }
  //CUSTOM:END:FI/AKH:29.04.2022 FIM0000129
  $scope.loadUserData = function () {
    $scope.setMessage("Benutzerdaten...", false);
    $userdata.subscribe($scope, function somethingChanged() {
      $scope.setMessage("Fertig", true);
    });
    $userdata.getUserDataAsync();
  }

  $scope.collapseAll = function () {
    $scope.api.tree.collapseAll()
    $scope.api.side.setWidth(undefined);
  }
  $scope.expandAll = function () {
    $scope.api.tree.expandAll()
    $scope.api.side.setWidth(undefined);
  }

  $scope.removeAll = function () {
    $scope.data = [
                    { "name": "Arbeitsvorrat", "tasks": [] },
                    { "name": "Maschine1", "tasks": [] },
                    { "name": "Maschine2", "tasks": [] },
                    { "name": "Maschine3", "tasks": [] },
                    { "name": "Maschine4", "tasks": [] },
                    { "name": "Maschine5", "tasks": [] },
                    { "name": "Maschine6", "tasks": [] },
                    { "name": "Maschine7", "tasks": [] },
                    { "name": "Maschine8", "tasks": [] },
                    { "name": "Maschine9", "tasks": [] }
    ];
  }
}
]
)

if (!Array.from) {
  Array.from = (function () {
    var toStr = Object.prototype.toString;
    var isCallable = function (fn) {
      return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
    };
    var toInteger = function (value) {
      var number = Number(value);
      if (isNaN(number)) { return 0; }
      if (number === 0 || !isFinite(number)) { return number; }
      return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
    };
    var maxSafeInteger = Math.pow(2, 53) - 1;
    var toLength = function (value) {
      var len = toInteger(value);
      return Math.min(Math.max(len, 0), maxSafeInteger);
    };

    return function from(arrayLike) {
      var C = this;

      var items = Object(arrayLike);

      if (arrayLike == null) {
        throw new TypeError("Array.from requires an array-like object - not null or undefined");
      }

      var mapFn = arguments.length > 1 ? arguments[1] : void undefined;
      var T;
      if (typeof mapFn !== 'undefined') {

        if (!isCallable(mapFn)) {
          throw new TypeError('Array.from: when provided, the second argument must be a function');
        }

        if (arguments.length > 2) {
          T = arguments[2];
        }
      }

      var len = toLength(items.length);
      var A = isCallable(C) ? Object(new C(len)) : new Array(len);

      var k = 0;
      var kValue;
      while (k < len) {
        kValue = items[k];
        if (mapFn) {
          A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
        } else {
          A[k] = kValue;
        }
        k += 1;
      }
      A.length = len;
      return A;
    };
  }());
}

if (!String.prototype.startsWith) {
  String.prototype.startsWith = function (searchString, position) {
    position = position || 0;
    return this.substr(position, searchString.length) === searchString;
  };
}
