﻿
using System;
using System.Linq;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace p2plus.Fischbach_av_gant {
  public class MachineCartridgeData : CartridgeData {

    private DataTable taskTable;
    public string connectString { get; set; }

    public string machineType { get; set; }

    //Used to cycle through the cartrige task list
    public int counter = 0;

    public static string sql_magr { get; } = @"
        SELECT 
          BOARD.WAID,
          BOARD.WAPOSID,
          BOARD.BAUFTRAG,
          BOARD.ARTIKEL,
          BOARD.WAPOS,
          BOARD.WAPOSMAGR,
          BOARD.WAPOSMENGEREST,
          BOARD.WAPOSMENGE,
          BOARD.WAMENGEIST,
          BOARD.WAMENGE,
          BOARD.WAMANDANT,
          BOARD.WAPOSMANDANT,
          BOARD.ARTNAME,
          BOARD.ARTIKELSTATUS,
          BOARD.KARTKARTUSCHENNAME,
          BOARD.KARTGRUNDFARBE,
          BOARD.KARTBESONDERHEIT,
          BOARD.KARTDRUCK,
          '' + (SELECT CASE WHEN BOARD.WAPOSSTATUS = 3 OR (BOARD.WASTATUS = 6 AND BOARD.AZEORGZEIT IS NOT NULL ) THEN 'RUN' END) AS RUNNING,
          isnull(nullif(convert(varchar(2),convert(smallint,right(BOARD.ARTPREISGRUPPE,2))),0),'') + isnull(IND.indexalpha, '') AS INDINDEXALPHA,
          '' + (SELECT CASE WHEN BOARD.WAENDEDATE >= BOARD.WALATESTENDDATE OR (BOARD.WALATESTENDDATE IS NULL AND BOARD.WAENDEDATE < GETDATE()) THEN '|TOOLATE|' END) as ENDESTRING,
          WASTARTDATE,
          WAENDEDATE,
          COALESCE(BOARD.WALATESTENDDATE,WAENDEDATE) AS WALATESTENDDATE,
          WAPOSTSOLL,
          ISNULL((SELECT DISTINCT 'COMBI' 
            WHERE EXISTS (
            SELECT WAPOSID
            FROM [dbo].[BOARD_AUFTRAGSPLANUNG_BASE] COMBI
             WHERE NOT(COMBI.BAUFTRAG = BOARD.BAUFTRAG AND COMBI.WAPOS = BOARD.WAPOS)
             AND COMBI.ARTCOMBICODE = BOARD.ARTCOMBICODE
             AND COMBI.WAENDEDATE >= @FiFromDate
             AND COMBI.WAENDEDATE <= @FiToDate )), '')
          AS COMBIEXISTS,
          BOARD.ARTCOMBICODE,
          BOARD.ARTAENDERUNGSINDEX,
          kart_av.FARBEAV AS COLOR,
          AZ.MAGR AS AZMAGR,
          AZ.ORGZEIT AS AZORGZEIT,
          WAPOS.STATUS AS WAPOSSTATUS5,
          BOARD.PRODUKTIONSSTART_ORIGINAL
        FROM [dbo].[BOARD_AUFTRAGSPLANUNG_BASE] BOARD 
          JOIN WAUFTRAGPOS WAPOS ON WAPOS.[POSITION] = BOARD.WAPOS AND WAPOS.BAUFTRAG = BOARD.BAUFTRAG AND WAPOS.AG = __FI_ARBEITSGANG__
          LEFT JOIN dbo.SINDEX IND ON ARTIKEL = IND.STUELI AND ARTAENDERUNGSINDEX = IND.SINDEX 
          LEFT JOIN dbo.AZEBELEG AZ ON AZ.BAUFTRAG = BOARD.BAUFTRAG AND AZ.POSITION = BOARD.WAPOS 
          LEFT JOIN dbo.ANP_KARTUSCHEN_AV kart_av ON kart_av.NAME = BOARD.KARTKARTUSCHENNAME AND kart_av.GRUNDFARBE = 
          COALESCE (
           (SELECT TOP 1 kart1.GRUNDFARBE FROM dbo.ANP_KARTUSCHEN as kart1 WHERE kart1.KARTUSCHENNAME = KARTKARTUSCHENNAME AND kart1.GRUNDFARBE = KARTGRUNDFARBE)
           , '*')
           WHERE WAENDEDATE >= @FiFromDate
           AND WAENDEDATE <= @FiToDate 
           AND __FI_POSMAGR__
           AND BOARD.WAMANDANT = @FiMandant
           AND BOARD.WAMANDANT = BOARD.WAPOSMANDANT AND BOARD.WAPOSMANDANT = WAPOS.MANDANT
       ";

    public static string sql_magr_sg { get; } = @"
        SELECT 
          BOARD.WAID,
          BOARD.WAPOSID,
          BOARD.BAUFTRAG,
          BOARD.ARTIKEL,
          BOARD.ARTPREISGRUPPE,
          BOARD.WAPOS,
          BOARD.WAPOSMAGR,
          BOARD.WAPOSMENGEREST,
          BOARD.WAPOSMENGE,
          BOARD.WAMENGEIST,
          BOARD.WAMENGE,
          BOARD.WAMANDANT,
          BOARD.WAPOSMANDANT,
          BOARD.ARTNAME,
          BOARD.ARTIKELSTATUS,
          BOARD.KARTKARTUSCHENNAME,
          BOARD.KARTGRUNDFARBE,
          BOARD.KARTBESONDERHEIT,
          BOARD.KARTDRUCK,
          '' + (SELECT CASE WHEN BOARD.WAPOSSTATUS = 3 OR (BOARD.WASTATUS = 6 AND BOARD.AZEORGZEIT IS NOT NULL ) THEN 'RUN' END) AS RUNNING,
          '' AS INDINDEXALPHA,
          '' + (SELECT CASE WHEN BOARD.WAENDEDATE >= BOARD.WALATESTENDDATE OR (BOARD.WALATESTENDDATE IS NULL AND BOARD.WAENDEDATE < GETDATE()) THEN '|TOOLATE|' END) as ENDESTRING,
          WASTARTDATE,
          WAENDEDATE,
          COALESCE(BOARD.WALATESTENDDATE,WAENDEDATE) AS WALATESTENDDATE,
          WAPOSTSOLL,
          '' AS COMBIEXISTS,
          '' AS ARTCOMBICODE,
          '' AS ARTAENDERUNGSINDEX,
          kart_av.FARBEAV AS COLOR,
          COLORPREISGRUPPE = (SELECT TOP 1 kart_av_sub.FARBEAV FROM dbo.ANP_KARTUSCHEN_AV kart_av_sub WHERE BOARD.ARTPREISGRUPPE LIKE kart_av_sub.PREISGRUPPE + '%'),
          AZ.MAGR AS AZMAGR,
          AZ.ORGZEIT AS AZORGZEIT,
          0 AS WAPOSSTATUS5,
          BOARD.WALAUFKART,
          APPOS.ALTERNATIVMAGR
        FROM [dbo].[BOARD_AUFTRAGSPLANUNG_SG_BASE] BOARD 
          JOIN WAUFTRAGPOS WAPOS ON WAPOS.[POSITION] = BOARD.WAPOS AND WAPOS.BAUFTRAG = BOARD.BAUFTRAG AND WAPOS.AG = 10
          LEFT JOIN dbo.AZEBELEG AZ ON AZ.BAUFTRAG = BOARD.BAUFTRAG AND AZ.POSITION = BOARD.WAPOS 
          LEFT JOIN dbo.APLANPOS APPOS ON APPOS.APLAN = BOARD.ARTIKEL AND APPOS.[POSITION] = 10 
          LEFT JOIN dbo.ANP_KARTUSCHEN_AV kart_av ON kart_av.NAME = BOARD.KARTKARTUSCHENNAME AND kart_av.GRUNDFARBE = 
          COALESCE (
           (SELECT TOP 1 kart1.GRUNDFARBE FROM dbo.ANP_KARTUSCHEN as kart1 WHERE kart1.KARTUSCHENNAME = KARTKARTUSCHENNAME AND kart1.GRUNDFARBE = KARTGRUNDFARBE)
           , '*')
           WHERE WAENDEDATE >= @FiFromDate
           AND WASTARTDATE <= @FiToDate 
           AND BOARD.ARTIKEL NOT IN ('01000','01050')
           AND BOARD.WAMANDANT = @FiMandant
           AND BOARD.WAPOSMAGR IN (__FI_MAGRLIST__)
           AND BOARD.WAMANDANT = BOARD.WAPOSMANDANT AND BOARD.WAPOSMANDANT = WAPOS.MANDANT
       ";

    public static string sql_ausfall { get; } = @"
        SELECT 
          wa.ID AS WAID,
          wapos.ID AS WAPOSID,
          wa.BAUFTRAG AS BAUFTRAG,
          wa.APLAN AS ARTIKEL,
          wa.[POSITION] AS WAPOS,
          wapos.MAGR AS WAPOSMAGR,
          0 AS WAPOSMENGEREST,
          0 AS WAPOSMENGE,
          0 AS WAMENGEIST,
          0 AS WAMENGE,
          wa.mandant AS WAMANDANT,
          wapos.mandant AS WAPOSMANDANT,
          (SELECT CASE WHEN wa.APLAN = '02000' 
            THEN 'Maschinenausfall' 
            ELSE wa.BEMERKUNG 
            END) AS ARTNAME,
          '' AS ARTIKELSTATUS,
          '' AS KARTKARTUSCHENNAME, 
          '' AS KARTGRUNDFARBE,
          '' AS KARTBESONDERHEIT,
          '' AS KARTDRUCK,
          '' AS RUNNING,
          '' AS INDINDEXALPHA,
           FORMAT(wa.ENDE,'dd.MM.yy HH:mm','de-de') as ENDESTRING,
           wa.START AS WASTARTDATE,
           wa.ENDE AS WAENDEDATE,
           COALESCE (wa.LATESTENDDATE, getdate()) AS WALATESTENDDATE,
           wapos.T_SOLL AS WAPOSTSOLL,
           '' AS COMBIEXISTS,
           '' AS ARTCOMBICODE,
           '' AS ARTAENDERUNGSINDEX,
           '255, 63, 63' AS COLOR,
           '' AS AZMAGR,
           getdate() AS AZORGZEIT,
           0 AS WAPOSSTATUS5,
           getdate() AS PRODUKTIONSSTART_ORIGINAL
         FROM dbo.WAUFTRAG AS wa, 
           dbo.WAUFTRAGPOS as wapos 
         WHERE wa.BAUFTRAG = wapos.BAUFTRAG 
           AND wa.[POSITION] = wapos.[POSITION] 
           AND wapos.MAGR IN ('02001','02002','02003','02004','02005','02006','02007','02008','02009','02011','02012','02013') 
           AND (wapos.STATUS = 2 OR wapos.STATUS = 3) 
           AND wa.MANDANT = @FiMandant AND wa.MANDANT = wapos.MANDANT 
           AND wa.MANDANT = wapos.MANDANT 
           AND wapos.AG = 10
           AND wa.APLAN IN ('02000','02050')
          AND wa.ENDE > getdate()
          AND wa.ENDE <= @FiToDate";

    public static string sql_ausfallSG { get; } = @"
        SELECT 
          wa.ID AS WAID,
          wapos.ID AS WAPOSID,
          wa.BAUFTRAG AS BAUFTRAG,
          wa.APLAN AS ARTIKEL,
          '' AS ARTPREISGRUPPE,
          wa.[POSITION] AS WAPOS,
          wapos.MAGR AS WAPOSMAGR,
          0 AS WAPOSMENGEREST,
          0 AS WAPOSMENGE,
          0 AS WAMENGEIST,
          0 AS WAMENGE,
          wa.mandant AS WAMANDANT,
          wapos.mandant AS WAPOSMANDANT,
          (SELECT CASE WHEN wa.APLAN = '01000' 
            THEN 'Maschinenausfall' 
            ELSE wa.BEMERKUNG 
            END) AS ARTNAME,
          '' AS ARTIKELSTATUS,
          '' AS KARTKARTUSCHENNAME, 
          '' AS KARTGRUNDFARBE,
          '' AS KARTBESONDERHEIT,
          '' AS KARTDRUCK,
          '' AS RUNNING,
          '' AS INDINDEXALPHA,
           FORMAT(wa.ENDE,'dd.MM.yy HH:mm','de-de') as ENDESTRING,
           wa.START AS WASTARTDATE,
           wa.ENDE AS WAENDEDATE,
           COALESCE (wa.LATESTENDDATE, getdate()) AS WALATESTENDDATE,
           wapos.T_SOLL AS WAPOSTSOLL,
           '' AS COMBIEXISTS,
           '' AS ARTCOMBICODE,
           '' AS ARTAENDERUNGSINDEX,
           '255, 63, 63' AS COLOR,
           '' AS COLORPREISGRUPPE,
           '' AS AZMAGR,
           getdate() AS AZORGZEIT,
           0 AS WAPOSSTATUS5,
           '' AS WALAUFKART,
           '' AS ALTERNATIVMAGR
         FROM dbo.WAUFTRAG AS wa, 
           dbo.WAUFTRAGPOS as wapos 
         WHERE wa.BAUFTRAG = wapos.BAUFTRAG 
           AND wa.[POSITION] = wapos.[POSITION] 
           AND wapos.MAGR NOT IN('01990','01991','01992','01993') AND wapos.MAGR LIKE '010%'
           AND (wapos.STATUS = 2 OR wapos.STATUS = 3) 
           AND wa.MANDANT = @FiMandant AND wa.MANDANT = wapos.MANDANT 
           AND wa.MANDANT = wapos.MANDANT 
           AND wapos.AG = 10
           AND wa.APLAN IN ('01000','01050')
          AND wa.ENDE > getdate()
          AND wa.ENDE <= @FiToDate";

    public void readDbMachineData (string fromDate, string toDate, string machineType) {
      string sql;
      string localsql_magr;

      localsql_magr = sql_magr;
      sql = "";

      if (machineType.Equals("") || machineType.ToUpper().Equals("SD")) {
        localsql_magr = sql_magr;
        localsql_magr = localsql_magr.Replace("__FI_POSMAGR__", " WAPOSMAGR != '02000' ");
        localsql_magr = localsql_magr.Replace("__FI_ARBEITSGANG__", "5");

        sql = "SELECT TOP 2000 t.* FROM( " +
            localsql_magr +
            " UNION ALL " +
            sql_ausfall +
            ") AS t ORDER BY t.WAPOSMAGR, t.WAENDEDATE";

      } else if(machineType.ToUpper().Equals("SG")) {
        localsql_magr = sql_magr_sg;

        string magrStr = "'" + string.Join("','", magrConfList.magrIDList) + "'";
        localsql_magr = localsql_magr.Replace("__FI_MAGRLIST__", magrStr);

        sql = "SELECT TOP 2000 t.* FROM( " +
            localsql_magr +
            " UNION ALL " +
            sql_ausfallSG +
            ") AS t ORDER BY t.WAPOSMAGR, t.WAENDEDATE";
      }
      
      SqlConnection conn;
      taskTable = new DataTable();
      CultureInfo provider = CultureInfo.InvariantCulture;

      using (conn = new SqlConnection(connectString))
      using (SqlDataAdapter dataAdapter = new SqlDataAdapter()) {
        var cmd = new SqlCommand(sql, conn);
        //cmd.CommandType = System.Data.CommandType..StoredProcedure;
        cmd.Parameters.Add("@FiMandant", SqlDbType.VarChar).Value = mandant;
        DateTime sqlFromDate = DateTime.ParseExact(fromDate,"dd/MM/yyyy", provider);
        DateTime sqlToDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", provider);
        cmd.Parameters.Add("@FiFromDate", SqlDbType.DateTime).Value = sqlFromDate;
        cmd.Parameters.Add("@FiToDate", SqlDbType.DateTime).Value = sqlToDate;
        dataAdapter.SelectCommand = cmd;
        dataAdapter.Fill(taskTable);
      }
    }

    /// <summary>
    /// Loop over maschine groups and add orders
    /// </summary>
    /// <returns></returns>
    public List<AvGantMagr> getMagrOrderList (MagrConfList magrConfList) {
      List<AvGantMagr> magrList = new List<AvGantMagr>();
      List<AvGantMagr> magrListSorted = new List<AvGantMagr>();

      for (int ii = 0; ii < magrConfList.magrIDList.Length; ii++) {
        magrList.Add(this.getMagrOrders(taskTable, magrConfList.magrIDList[ii], magrConfList.magrNameList[ii], magrConfList.magrSortList[ii]));
      }

      if ("SG".Equals(machineType)) {
        magrListSorted = magrList.OrderBy(avmagr => avmagr.sort).ToList();
      } else {
        magrListSorted = magrList;
      }

      return magrListSorted;
    }

    /// <summary>
    /// Converts the DB task data for a specific magr to UI format
    /// </summary>
    /// <param name="dTable">data table from DB selection</param>
    /// <param name="targetMagr">the magr id e.g. 2006</param>
    /// <param name="name">the magr name</param>
    /// <returns>a list of objects send to the UI</returns>
    public AvGantMagr getMagrOrders(DataTable dTable, String targetMagr, string name, int sort) {
      DataRow currentRow;
      String currentMagr;
      int currentMagrInt, targetMagrInt;
      float workload=0;
      int mengeSum = 0;
      int late = 0;

      AvGantMagr avmagr = new AvGantMagr();

      for(int i = counter; i < dTable.Rows.Count; i++) {
        currentRow = dTable.Rows[i];
        currentMagr = currentRow["WAPOSMAGR"].ToString();
        currentMagrInt = Int32.Parse(currentMagr);
        targetMagrInt = Int32.Parse(targetMagr);
        
        //The current magr is already higher than the target magr --> leave
        if (currentMagrInt > targetMagrInt) {
          counter = i;
          break;
        }

        if (currentMagrInt < targetMagrInt) {
          continue;
        }

        AVTask task = getTask (currentRow, machineType, false);
        avmagr.tasks.Add(task);

        workload += task.data.workload;

        if (task.late != 0) {
          late = task.late;
        }

        string mengeStr = currentRow["WAMENGE"].ToString();
        mengeSum += Int32.Parse(mengeStr);
      }

      //CONVERT(VARCHAR(30),CONVERT(DECIMAL(10,1),(SUM(WAPOSTSOLL)) / 3600.0)) + ' h'
      workload = (float)(Math.Round((double)workload / 3600, 1));
      avmagr.workload = workload;
      avmagr.palets = mengeSum / 3360;
      avmagr.late = late;
      if ("SG".Equals(machineType)) {
        avmagr.name = name;
      } else if ("SD".Equals(machineType)) {
        avmagr.name = targetMagr + " " + name;
      }
      avmagr.id = targetMagr;
      avmagr.magr = targetMagr;
      avmagr.sort = sort;

      if (late > 0) {
        avmagr.classes = "lateplus";
      } 
      if (late < 0) {
        avmagr.classes = "lateminus";
      }

      return avmagr;
    }

  }
}