﻿using p2plus.p2core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace p2plus.Fischbach_av_gant {
  public class StockCartridgeList : CartridgeData {
    public string connectString { get; set; }
    public string groupStock { get; set; }
    public string machineType { get; set; }

    internal List<stockCartridgeData> confList = new List<stockCartridgeData>();
    internal List<stockCartridgeData> confListSort = new List<stockCartridgeData>();
    stockCartridgeData otherTypes = new stockCartridgeData();

    //Reads the stock layout from sysconf
    public void getStockLayoutSysconfConfig(string confName) {
      string stockConf;

      stockConf = Sysconf.getString("CUSTOM", confName);
      if (stockConf == null) return;

      string[] stockList = stockConf.Split(',');

      for (int ii = 0; ii < stockList.Length; ii++) {
        string stockValues = stockList[ii];
        string[] stockValueList = stockValues.Split('|');

        //Case SD
        if (stockValueList.Length == 4) {
          string listName = stockValueList[0];
          string filterName = stockValueList[1];
          string baseColour = stockValueList[2];

          int numberOfRows = 1;
          Int32.TryParse(stockValueList[3], out numberOfRows);

          if (filterName == "*") {
            this.otherTypes = new stockCartridgeData(listName, filterName, baseColour, numberOfRows);
          } else {
            stockCartridgeData cartridge = new stockCartridgeData(listName, filterName, baseColour, numberOfRows);
            confList.Add(cartridge);
          }
        }

        //Case SG
        if (stockValueList.Length == 3) {
          string listName = stockValueList[0];
          string filterName = stockValueList[1];

          int numberOfRows = 1;
          Int32.TryParse(stockValueList[2], out numberOfRows);

          if (filterName == "*") {
            this.otherTypes = new stockCartridgeData(listName, filterName, "", numberOfRows);
          } else {
            stockCartridgeData cartridge = new stockCartridgeData(listName, filterName, "", numberOfRows);
            confList.Add(cartridge);
          }
        }
      }

      //Order list to have shorter filter names Last
      //Clone list with references staying the same
      confListSort = new List<stockCartridgeData>(confList);
      //confListSort.Sort((x, y) => (string.Compare(x.filterName, y.filterName) * -1));
      confListSort.Sort((x, y) => {
        if (string.Compare(x.filterName, y.filterName) == 0) {
          return string.Compare(x.baseColour, y.baseColour) * -1;
        }
        return string.Compare(x.filterName, y.filterName) * -1;
      }
      );
    }

    public void readDbStockData(string fromDate, string toDate, string machineType) {

      string sqlStock = "";
      string localsql_magr = "";

      if (machineType.Equals("") || machineType.ToUpper().Equals("SD")) {
        localsql_magr = MachineCartridgeData.sql_magr;
        localsql_magr = localsql_magr.Replace("__FI_POSMAGR__", " WAPOSMAGR = '02000' ");
        localsql_magr = localsql_magr.Replace("__FI_ARBEITSGANG__", "5");

        sqlStock = "SELECT TOP 2000 t.* FROM( " +
        localsql_magr +
        ") AS t ORDER BY substring(t.KARTKARTUSCHENNAME, 1, 2), t.WAENDEDATE, t.ARTIKEL";

      } else if (machineType.ToUpper().Equals("SG")) {
        localsql_magr = MachineCartridgeData.sql_magr_sg;
        localsql_magr = localsql_magr.Replace("__FI_MAGRLIST__", "'" + groupStock + "'");

        sqlStock = "SELECT TOP 2000 t.* FROM( " +
            localsql_magr +
            ") AS t ORDER BY substring(t.KARTKARTUSCHENNAME, 1, 2), t.WAENDEDATE, t.ARTIKEL";
      }

      DataTable taskTableStock;

      SqlConnection conn;
      taskTableStock = new DataTable();
      CultureInfo provider = CultureInfo.InvariantCulture;

      using (conn = new SqlConnection(connectString))
      using (SqlDataAdapter dataAdapter = new SqlDataAdapter()) {
        var cmd = new SqlCommand(sqlStock, conn);
        cmd.Parameters.Add("@FiMandant", SqlDbType.VarChar).Value = mandant;
        DateTime sqlFromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", provider);
        DateTime sqlToDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", provider);
        cmd.Parameters.Add("@FiFromDate", SqlDbType.DateTime).Value = sqlFromDate;
        cmd.Parameters.Add("@FiToDate", SqlDbType.DateTime).Value = sqlToDate;
        dataAdapter.SelectCommand = cmd;
        dataAdapter.Fill(taskTableStock);
      }

      addCartridgeTable(taskTableStock, machineType);
    }

    public void addCartridgeTable(DataTable taskTableStock, string machineType) {
      for (int i = 0; i < taskTableStock.Rows.Count; i += 1) {
        DataRow currentRow = taskTableStock.Rows[i];
        string kartuschenName = currentRow["KARTKARTUSCHENNAME"].ToString();
        string grundFarbe = currentRow["KARTGRUNDFARBE"].ToString();
        this.AddCartridge(kartuschenName, grundFarbe, currentRow, machineType);
      }
    }

    // Adds a cardrige to a dedicates cartridge list if filter name matches
    // If no match is found, it is added to the default list
    public void AddCartridge(string cartridgeName, string baseColour, DataRow dataRow, string machineType) {
      bool found = false;
      if (machineType.Equals("SD")) {
        foreach (var cartridgeConf in confListSort) {
          if (cartridgeName.StartsWith(cartridgeConf.filterName) || cartridgeConf.filterName.ToUpper().Equals("ALL")) {
            if (baseColour.ToUpper() == cartridgeConf.baseColour.ToUpper() || cartridgeConf.baseColour == "*") {
              cartridgeConf.cartridgeList.Add(dataRow);
              found = true;
              break;
            }
          }
        }
      }

      if (machineType.Equals("SG")) {
        string preisgruppe = dataRow["ARTPREISGRUPPE"].ToString();
        int preisgruppeInt = Int32.Parse(preisgruppe);

        foreach (var cartridgeConf in confListSort) {
          string[] preisgruppeRange = cartridgeConf.filterName.Split('-');
          int lowerPreisgruppe = Int32.Parse(preisgruppeRange[0]);
          int upperPreisgruppe = Int32.Parse(preisgruppeRange[1]);

          if (preisgruppeInt >= lowerPreisgruppe && preisgruppeInt <= upperPreisgruppe) {
            cartridgeConf.cartridgeList.Add(dataRow);
            found = true;
            break;
          }
        }
      }

      if (!found) {
        otherTypes.cartridgeList.Add(dataRow);
      }
    }

    /// Returns the complete list of stock catridge orders
    /// Used inside the GUI for the stock view
    public List<object> getStockOrderList() {
      List<Object> stockList = new List<Object>();

      foreach (stockCartridgeData stockConfig in confList) {
        for (int stockRow = 0; stockRow < stockConfig.numberOfRows; stockRow++) {
          List<DataRow> cartridgeList;
          cartridgeList = stockConfig.getCartridgeList();

          //Only add the row in case there are items inside
          if (cartridgeList.Count > 0) {
            AvGantMagr stockItem = this.getStockOrders(stockConfig.getCartridgeList(), stockConfig.listName, stockConfig.baseColour, stockConfig.filterName, "", stockRow, stockConfig.numberOfRows);
            stockList.Add(stockItem);
          }
        }
      }
      if (this.otherTypes != null) {
        AvGantMagr stockItem = this.getStockOrders(otherTypes.getCartridgeList(), otherTypes.listName, otherTypes.baseColour, otherTypes.filterName, "*", 0, otherTypes.numberOfRows);
        stockList.Add(stockItem);
      }

      return stockList;
    }


    /// Retrieves a list of tasks in stock with the option to separate the tasks to one or more rows
    public AvGantMagr getStockOrders(List<DataRow> cartridgeList, string name, string baseColour, string filterName, string cartridgeType, int startWith, int stepWidth) {
      AvGantMagr avmagr = new AvGantMagr();
      DataRow currentRow;
      float workload = 0;
      int mengeSum = 0;

      lastStockTaskDate = DateTime.Now;

      //Add downtime task to stock
      if (cartridgeType.Equals("*")) {
        avmagr.tasks.Add(getOutageTask("fix"));
        avmagr.tasks.Add(getOutageTask("dyn"));
      }

      if (cartridgeList != null) {
        for (int i = startWith; i < cartridgeList.Count; i += stepWidth) {
          currentRow = (DataRow)cartridgeList[i];
          avmagr.tasks.Add(getTask(currentRow, machineType, true));

          string workloadStr = currentRow["WAPOSTSOLL"].ToString();
          int workloadNum = Int32.Parse(workloadStr);
          workload += workloadNum;

          string mengeStr = currentRow["WAMENGE"].ToString();
          mengeSum += Int32.Parse(mengeStr);
        }
      }

      //avmagr.id = "02000-" + name + "_" + baseColour +"-" + startWith;
      avmagr.id = groupStock + "-" + name + "_" + baseColour + "-" + startWith + "-" + filterName;
      avmagr.classes = "stock";
      avmagr.magr = "stock";

      workload = (float)(Math.Round((double)workload / 3600, 1));
      avmagr.workload = workload;

      //Todo: get amount per palett/stillage from item packaging rule
      avmagr.palets = mengeSum / 3360;

      avmagr.name = name + " " + (baseColour == "*" ? "" : baseColour);

      return avmagr;
    }

    // Returns a stock outage task like "machine outage" or "buffer time"
    private AVTask getOutageTask(string type) {
      DateTime newStart;
      TimeSpan duration;
      DateTime newEnd;
      int hours = 8;

      String dynOutage = "";
      String fixOutage = "";

      if (machineType.ToUpper().Equals("SD")) {
        dynOutage = "02050";
        fixOutage = "02000";
        if (type.Equals("dyn")) {
          hours = 2;
        }
      } else if (machineType.ToUpper().Equals("SG")) {
        dynOutage = "01050";
        fixOutage = "01000";
        hours = 16;
        if (type.Equals("dyn")) {
          hours = 8;
        }
      }

      TaskData outageData = new TaskData();
      outageData.artikel = "Maschinenausfall";

      AVTask avtask = new AVTask();
      avtask.id = "0";
      avtask.name = "";
      avtask.name2 = "Maschinenausfall";
      avtask.priority = 10;
      avtask.color = avTools.rgbToHex("255, 63, 63");

      lastStockTaskDate.AddMinutes(1);
      newStart = lastStockTaskDate;
      duration = new TimeSpan(0, hours, 0, 0, 0);
      newEnd = newStart.Add(duration);
      lastStockTaskDate = newEnd;
      avtask.from = newStart.ToString("o");
      avtask.to = newEnd.ToString("o");

      avtask.progress.percent = 0;
      avtask.classes = "";
      avtask.tooltips.setContent(outageData, mandant, null, null);

      avtask.data.waid = "0";
      avtask.data.waposid = "0";
      avtask.data.waposmagr = "0";
      avtask.data.cartridgeName = "";
      avtask.data.baseColour = "";
      avtask.data.particularity = "";
      avtask.data.print = "";
      avtask.data.combiCode = "";
      avtask.data.bauftrag = "0";
      avtask.data.wapos = "0";
      avtask.data.menge = "";
      avtask.data.artikel = fixOutage;

      if (type.Equals("dyn")) {
        avtask.id = "1";
        avtask.data.waid = "1";
        avtask.data.waposid = "1";

        avtask.name2 = "Puffer Auftrag";
        outageData.artikel = "Puffer Auftrag";
        avtask.data.artikel = dynOutage;
      }

      return avtask;
    }

  }
}