﻿--SELECT * FROM [dbo].[BOARD_AUFTRAGSPLANUNG_SG_BASE]

DROP VIEW [dbo].[BOARD_AUFTRAGSPLANUNG_SG_BASE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Base view used to reduce number of records found for more complex
--stuff in the view on top
CREATE VIEW [dbo].[BOARD_AUFTRAGSPLANUNG_SG_BASE] WITH SCHEMABINDING 
AS
SELECT 
    wa.ID AS WAID,
    wapos.ID AS WAPOSID,
    wa.BAUFTRAG AS BAUFTRAG,
    wa.APLAN AS ARTIKEL,
    wapos.STATUS AS WAPOSSTATUS,
    wa.STATUS AS WASTATUS,
    wa.[POSITION] AS WAPOS,
    wapos.MAGR AS WAPOSMAGR,
    wa.mandant AS WAMANDANT,
    wapos.mandant AS WAPOSMANDANT,
    art.NAME AS ARTNAME,
    art.PREISGRUPPE AS ARTPREISGRUPPE,
    art.ARTIKELSTATUS AS ARTIKELSTATUS,
    kart.KARTUSCHENNAME AS KARTKARTUSCHENNAME, 
    kart.GRUNDFARBE AS KARTGRUNDFARBE,
    kart.BESONDERHEIT AS KARTBESONDERHEIT,
    kart.DRUCK AS KARTDRUCK,
    wa.START AS WASTARTDATE,
    wa.ENDE AS WAENDEDATE,
    wa.LATESTENDDATE AS WALATESTENDDATE,
    wapos.T_SOLL AS WAPOSTSOLL,
    LEFT(wapos.MENGE_REST, CHARINDEX('.', wapos.MENGE_REST) - 1) AS WAPOSMENGEREST,
    LEFT(wapos.MENGE, CHARINDEX('.', wapos.MENGE) - 1) AS WAPOSMENGE,
    LEFT(wa.MENGE_IST, CHARINDEX('.', wa.MENGE_IST) - 1) AS WAMENGEIST,
    LEFT(wa.MENGE, CHARINDEX('.', wa.MENGE) - 1) AS WAMENGE,
    AZE.ORGZEIT AS AZEORGZEIT
FROM dbo.WAUFTRAG AS wa
    join dbo.ARTIKEL_A as art ON wa.APLAN = art.ARTIKEL
    left join dbo.ANP_KARTUSCHEN as kart ON art.PREISGRUPPE = kart.PREISGRUPPE 
    --dbo.AUFSTUELIPOS as aufpos,
    join dbo.WAUFTRAGPOS as wapos ON wa.BAUFTRAG = wapos.BAUFTRAG AND wa.[POSITION] = wapos.[POSITION]
    left join dbo.azebeleg as aze ON aze.BAUFTRAG = wapos.bauftrag AND aze.position = wapos.position
WHERE --wapos.MAGR IN ('01001','01002','01003','01004','01005','01006','01007','01008','01009','01010') 
    --AND aufpos.AUFSTUELI = wa.AUFSTUELI AND aufpos.POSITION = wa.AUFSTUELIPOS AND aufpos.mandant = wapos.mandant
    --Show wauftrag in status "eingeplant, working and terminated if not complete"
    --Still show, if amount is not reached, but not if wauftrag is finished
    (wapos.STATUS IN (2, 3) 
        OR (wapos.STATUS = 4 AND (
            wa.STATUS = 3 OR 
            wa.MENGE - COALESCE(wa.MENGE_IST,0) > 0 
            OR (wa.STATUS = 6 AND aze.bauftrag IS NOT NULL )
            )
        )
    ) 
    AND (WA.STATUS < 6 
         OR
        (wa.STATUS = 6 AND aze.bauftrag IS NOT NULL))
    --AND wa.MANDANT = 'EN'
    --AND wapos.MANDANT = 'EN'
    AND wapos.AG = 10
    AND wa.mandant = wapos.mandant
GO