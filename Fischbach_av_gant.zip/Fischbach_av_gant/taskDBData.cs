﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Xml;

namespace p2plus.Fischbach_av_gant {
  /// <summary>
  /// Contains the classes and functionality to hold the data from DB
  /// </summary>
  public class TaskData {
    public string waposid { get; set; }
    public string artname { get; set; }
    public string color { get; set; }
    public string bauftrag { get; set; }
    public string kartuschenname { get; set; }
    public string grundfarbe { get; set; }
    public string besonderheit { get; set; }
    public string druck { get; set; }
    public string artikel { get; set; }
    public string combiCode { get; set; }
    public string waid { get; set; }
    public string magr { get; set; }
    public string azmagr { get; set; }
    public string running { get; set; }
    public string indexalpha { get; set; }
    public string wapos { get; set; }
    public int prozentFertig { get; set; }
    public int menge { get; set; }
    public int mengeIst { get; set; }
    public int workload { get; set; }

    public DateTime start { get; set; }
    public DateTime end { get; set; }
    public DateTime latestEnd { get; set; }
    public DateTime azOrgZeit { get; set; }
    public DateTime prodStartOrg { get; set; }

    public string endeString { get; set; }
    public string combiExists { get; set; }
    public string itemStatusStr { get; set; }
    public int waPosStatus5  { get; set; }
    public int waLaufkart { get; set; }
    public IList<string> alternativMagr { get; set;}
  
    public TaskData (DataRow currentRow) {
      azmagr = "";
      setFromRow (currentRow);
    }

    public TaskData () {
      initializeFields();
    }

    private void initializeFields () {
      waposid = "";
      artname = "";
      color = "";
      bauftrag = "";
      kartuschenname = "";
      grundfarbe = "";
      besonderheit = "";
      druck = "";
      artikel = "";
      combiCode = "";
      waid = "";
      magr = "";
      azmagr = "";
      running = "";
      indexalpha = "";
      wapos = "";
      prozentFertig = 0;
      menge = 0;
      mengeIst = 0;
      workload = 0;

      start = new DateTime ();
      end = new DateTime ();
      latestEnd = new DateTime ();
      prodStartOrg = new DateTime();

      endeString = "";
      combiExists = "";
      itemStatusStr = "";

      waPosStatus5 = 0;
      waLaufkart = 0;
      alternativMagr = null;
    }

    public Boolean setFromRow (DataRow currentRow) {

      string wastartdate;
      string waenddate;
      string walatestenddate;
      string azOrgZeitStr;
      string prodStartOrgStr;

      string mengeStr;
      string mengeIstStr;
      string workloadStr;
      object waPosStatus5Obj;
      object waLaufkartObj;
      object alternativMagrObj;

      waid = currentRow["WAID"].ToString();
      magr = currentRow["WAPOSMAGR"].ToString();
      wapos = currentRow["WAPOS"].ToString();
      waposid = currentRow["WAPOSID"].ToString();
      artname = currentRow["ARTNAME"].ToString();
      artikel = currentRow["ARTIKEL"].ToString();
      kartuschenname = currentRow["KARTKARTUSCHENNAME"].ToString();
      grundfarbe = currentRow["KARTGRUNDFARBE"].ToString();
      besonderheit = currentRow["KARTBESONDERHEIT"].ToString();
      druck = currentRow["KARTDRUCK"].ToString();
      indexalpha = currentRow["INDINDEXALPHA"].ToString();

      wastartdate = currentRow["WASTARTDATE"].ToString();
      waenddate = currentRow["WAENDEDATE"].ToString();
      walatestenddate = currentRow["WALATESTENDDATE"].ToString();
      azOrgZeitStr = currentRow["AZORGZEIT"].ToString();
      start= DateTime.Parse(wastartdate);
      end = DateTime.Parse(waenddate);
      latestEnd = DateTime.Parse(walatestenddate);
      if (azOrgZeitStr != null && !azOrgZeitStr.Equals("")) {
        azOrgZeit = DateTime.Parse(azOrgZeitStr);
      }

      //view for planner for mould injection does not contain this field
      if (currentRow.Table.Columns.Contains("PRODUKTIONSSTART_ORIGINAL")) { 
        prodStartOrgStr = currentRow["PRODUKTIONSSTART_ORIGINAL"].ToString();
        if (prodStartOrgStr != null && !prodStartOrgStr.Equals("")) {
          prodStartOrg = DateTime.Parse(prodStartOrgStr);
        }
      }

      mengeStr = currentRow["WAMENGE"].ToString();
      mengeIstStr = currentRow["WAMENGEIST"].ToString();
      if (mengeIstStr == null || mengeIstStr.Equals("")) {
        mengeIstStr = "0";
      }
      menge = Int32.Parse(mengeStr);
      mengeIst = Int32.Parse(mengeIstStr);

      if (mengeIst > 0) {
        prozentFertig = mengeIst/(menge/100);
      } else {
        prozentFertig = 0;
      }

      //Handle workload for downtime and normal tasks
      if (artikel.Equals("02000") || artikel.Equals("02050") || artikel.Equals("01000") || artikel.Equals("01050")) {
        workload = (int)(end - start).TotalSeconds;
      } else {
        workloadStr = currentRow["WAPOSTSOLL"].ToString();
        int ignoreMe;
        bool successfullyParsed = int.TryParse(workloadStr, out ignoreMe);
        workload = 0;
        if (successfullyParsed) {
          workload = Int32.Parse(workloadStr);
        }
      }

      endeString = currentRow["ENDESTRING"].ToString();
      combiExists = currentRow["COMBIEXISTS"].ToString();
      combiCode = currentRow["ARTCOMBICODE"].ToString();

      running = currentRow["RUNNING"].ToString();
      azmagr = currentRow["AZMAGR"].ToString();
      itemStatusStr = currentRow["ARTIKELSTATUS"].ToString();

      string rawColor = currentRow["COLOR"].ToString();
      if (rawColor == null || rawColor == "") {
        try {
          rawColor = currentRow["COLORPREISGRUPPE"].ToString();
        } catch (System.ArgumentException) {
          rawColor = "";
        }
      } 
      color =  avTools.rgbToHex(rawColor);

      bauftrag = currentRow["BAUFTRAG"].ToString();

      waPosStatus5 = 0;
      waPosStatus5Obj = currentRow["WAPOSSTATUS5"];
      if (waPosStatus5Obj != null && !waPosStatus5Obj.ToString().Equals("")) {
        waPosStatus5 = Int32.Parse(waPosStatus5Obj.ToString());
      }
      
      waLaufkart = 0;
      try {
        waLaufkartObj = currentRow["WALAUFKART"];
      } catch (Exception e) {
        waLaufkartObj = null;
      }
      if (waLaufkartObj != null && !waLaufkartObj.ToString().Equals("")) {
        waLaufkart = Int32.Parse(waLaufkartObj.ToString());
      }

      alternativMagr = null;
      try {
        alternativMagrObj = currentRow["ALTERNATIVMAGR"];
      } catch (Exception e) {
        alternativMagrObj = null;
      }
      if (alternativMagrObj != null && !alternativMagrObj.ToString().Equals("")) {
        IList<string> magrList = new List<string>();

        string magrTxt = alternativMagrObj.ToString();
        XmlDocument magrXml = new XmlDocument();
        magrXml.LoadXml(magrTxt);

        XmlNode rootNode = magrXml.DocumentElement.SelectSingleNode("/root");
        foreach (XmlNode magrNode in rootNode.ChildNodes) {
          string magrRang = magrNode.Attributes["value"]?.InnerText;
          XmlNode magrNameNode = magrNode.SelectSingleNode("amagr");
          string magrName = magrNameNode.InnerText;
          magrList.Add(magrName);
        }

        alternativMagr = magrList;
      }

      return true;
    }

    public string getSpecializationClass () {
      return besonderheit.Contains("benetzt")?"COAT":"";
    }

    public string getTooLateClass () {
      //don't singal "late" is stock
      if (magr.Equals("02000"))
        return "";

      return endeString.Contains("TOOLATE")?"LATE":"";
    }

    public string getCombiCodeClass () {
      return combiExists.Contains("COMBI")?"CC":"";
    }

    public string getRunningClass () {
      string runningClass = "";

      //Set running animation
      if (running.Contains("RUN")) {
        runningClass = "RUN";

        //Check for running on wrong magr
        if (azmagr != null && !azmagr.Equals(magr)) {
          runningClass = "runningWrongMagr";
        }
      } else {
        //Check for not released item (should never be in running mode)  
        if (itemStatusStr != null && !itemStatusStr.Equals("3")) {
          runningClass = "LOCK";
        }
      }

      return runningClass;
    }

    public string getScreenReadyClass () {
      if (waPosStatus5 == 4) {
        return "SR";
      }
      return "";
    }
    public string getLaufkartClass() {
      if (waLaufkart == 1) {
        return "LK";
      }
      return "";
    }
  }
}