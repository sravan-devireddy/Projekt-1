﻿'use strict';

var app = angular.module("GanttStable");

app.service('$notedata', function ($http, $rootScope) {

  var noteData = "";
  var mandant = "";
  var type = "";

  this.setType = function (mandant_in) {
    this.type = mandant_in;
  }

  this.getType = function () {
    return this.type;
  }

  this.setMandant = function (inMandant) {
    this.mandant = inMandant;
  }

  this.getMandant = function (inMandant) {
    return this.mandant;
  }

  this.getNoteData = function () {
    return noteData;
  }

  this.setNoteData = function (noteData_in) {
    this.noteData = noteData_in;
  }

  this.getNoteDataAsync = function () {

    var noteDataPromise = this.getNoteDataPromise();
    noteDataPromise.then(function (result) {
      console.log("GetNoteData returned");
    });
  }

  this.getNoteDataPromise = function () {

    var params = {
      "type": JSON.stringify(this.getType()),
      "mandant": JSON.stringify(this.getMandant())
    }

    return $http({
      url: "anp_gant_read_json.asmx/getNoteData",
      method: "GET",
      params: params,
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      data: {}
    }).then(function onSuccess(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      noteData = data.d;
    }).catch(function onError(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      console.log(data);
      alert(data)
    }).finally(function () {
    });
  }

  this.setNoteDataAsync = function () {

    var noteDataPromise = this.setNoteDataPromise();
    noteDataPromise.then(function (result) {
      console.log("SetNoteData returned");
    });
  }

  this.setNoteDataPromise = function () {

    var params = {
      "type": JSON.stringify(this.getType()),
      "mandant": JSON.stringify(this.mandant),
      "note": JSON.stringify(this.noteData)
    }

    return $http({
      url: "anp_gant_read_json.asmx/setNoteData",
      method: "GET",
      params: params,
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      data: {}
    }).then(function onSuccess(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
    }).catch(function onError(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      console.log(data);
      alert(data)
    }).finally(function () {
    });
  }

});
