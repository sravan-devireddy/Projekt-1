﻿'use strict';

var app = angular.module("GanttStable");

app.service('$userdata', function ($http, $rootScope) {

  var userData;
  var user = '';
  var login = '';
  var environment = '';
  var mandant = '';

  this.getLogin = function () {
    return login;
  }

  this.getUser = function () {
    return user;
  }

  this.getEnvironmen = function () {
    return environment;
  }

  this.getMandant = function () {
    return mandant;
  }

  this.setMandant = function (mandant_in) {
    mandant = mandant_in;
  }

  this.getUserDataAsync = function () {

    var userDataPromise = this.getUserDataPromise();
    userDataPromise.then(function (result) {
      console.log("GetUserData returned");
    });
  }

  this.getUserDataPromise = function () {

    return $http({
      url: "anp_gant_read_json.asmx/getUserData",
      method: "GET",
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      data: '{}'
    }).then(function onSuccess(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      userData = JSON.parse(data.d);
      user = userData.user;
      login = userData.login;
      environment = userData.env;
      mandant = userData.mandant;
    }).catch(function onError(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      console.log(data);
      alert(data)
    }).finally(function () {
    });
  }
});
