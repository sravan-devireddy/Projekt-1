﻿'use strict';

var app = angular.module("GanttStable");

app.service('$print', function ($window) {

  this.preview = function (user, login, environment, mandant, docFormat, fromDate, toDate, magrs) {

    var localFromDate = moment(fromDate);
    var localToDate = moment(toDate);
    var docRptPath = '/reports/Fischbach/documents/Anp_ProduktionsReihenfolge'

    if (docFormat == 'XLS')
      docRptPath = '/reports/Fischbach/documents/Anp_ProduktionsReihenfolgeVS'

    var url = "../WebObjects/p2plusJS.aspx" +
      "?dummy=0" +
      "&docRptPath=" + docRptPath +
      "&docName=Produktionsreihenfolge" +
      "&docFormat=" + docFormat +
      "&isPreview=true" +
      "&FROMDATE=" + localFromDate.format('DD%2FMM%2FYYYY') +
      "&TODATE=" + localToDate.format('DD%2FMM%2FYYYY') +
      "&docTable=board_auftragsplanung" +
      "&docId=0" +
      "&id=0" +
      "&docLang=undefined" +
      "&p2user=" + user +
      "&loginName=" + login +
      "&env=" + environment +
      "&MANDANT=" + mandant +
      "&MAGRS=" + magrs;
    window.open(url, '_blank');
  }

  this.notReleased = function (user, login, environment, mandant, fromDate, toDate) {

    var localFromDate = moment(fromDate);
    var localToDate = moment(toDate).add({ days: 1, hours: 0, minutes: 0 });

    var docRptPath = '/reports/Fischbach/documents/Anp_NichtFreigegebeneArtikelAV'

    var url = "../WebObjects/p2plusJS.aspx" +
      "?dummy=0" +
      "&docRptPath=" + docRptPath +
      "&docName=NichtFreigegebeneArtikelAVXLS" +
      "&docFormat=XLS" +
      "&isPreview=true" +
      "&FROMDATE=" + localFromDate.format('DD%2FMM%2FYYYY') +
      "&TODATE=" + localToDate.format('DD%2FMM%2FYYYY') +
      "&docTable=board_auftragsplanung" +
      "&docId=0" +
      "&id=0" +
      "&docLang=undefined" +
      "&p2user=" + user +
      "&loginName=" + login +
      "&env=" + environment +
      "&MANDANT=" + mandant;
    window.open(url, '_blank');
  }
  //CUSTOM:BEGIN:FI/AKH:29.04.2022 FIM0000129: SD Plantafel: Neuer Excel Report
  this.extendOrdersReport = function (user, login, environment, mandant, fromDate, toDate) {

    var localFromDate = moment(fromDate);
    var localToDate = moment(toDate).add({ days: 1, hours: 0, minutes: 0 });

    var docRptPath = '/reports/Fischbach/documents/Anp_Auftraegeerweiterung'

    var url = "../WebObjects/p2plusJS.aspx" +
      "?dummy=0" +
      "&docRptPath=" + docRptPath +
      "&docName=AuftraegeerweiterungXLS" +
      "&docFormat=XLS" +
      "&isPreview=true" +
      "&FROMDATE=" + localFromDate.format('DD%2FMM%2FYYYY') +
      "&TODATE=" + localToDate.format('DD%2FMM%2FYYYY') +
      "&docTable=board_auftragsplanung" +
      "&docId=0" +
      "&id=0" +
      "&docLang=undefined" +
      "&p2user=" + user +
      "&loginName=" + login +
      "&env=" + environment +
      "&MANDANT=" + mandant;
    window.open(url, '_blank');
  }//CUSTOM:END:FI/AKH:29.04.2022 FIM0000129
});
