﻿'use strict';

var app = angular.module("GanttStable");

app.service('$confirmComment', function ($modal, $rootScope, $q) {
  var scope = $rootScope.$new();
  var deferred;
  scope.title = 'Maschinenausfall';
  scope.selectedDowntimeReason = '0 geplant - Personalmangel';

  scope.reasons = [
    { value: '0 geplant - Personalmangel', label: 'geplant - Personalmangel', type: 'fix' },
    { value: '1 geplant - Kapazität / Auslastung', label: 'geplant - Kapazität / Auslastung', type: 'fix' },
    { value: '2 geplant - Wartung', label: 'geplant - Wartung', type: 'fix' },
    { value: '3 ungeplant - Personalmangel', label: 'ungeplant - Personalmangel', type: 'fix' },
    { value: '4 ungeplant - Störung', label: 'ungeplant - Störung', type: 'fix' },
    { value: '5 Puffer - Auftrag mehr als 6 Farben', label: 'Puffer - Auftrag mehr als 6 Farben', type: 'dyn' },
    { value: '6 Puffer - Nachdruck Farbhaftung', label: 'Puffer - Nachdruck Farbhaftung', type: 'dyn' },
    { value: '7 Puffer - Nachdruck Qualität', label: 'Puffer - Nachdruck Qualität', type: 'dyn' },
    { value: '8 Puffer - Dornwechsel', label: 'Puffer - Dornwechsel', type: 'dyn' },
    { value: '9 Puffer - Musterauftrag', label: 'Puffer - Musterauftrag', type: 'dyn' },
    { value: '10 Puffer - Farbpumpenwechsel', label: 'Puffer - Farbpumpenwechsel', type: 'dyn' },
    { value: '11 Puffer SG - Muster', label: 'Puffer - Muster', type: 'dyn' },
    { value: '12 Puffer SG - Individuell', label: 'Puffer - Individuell', type: 'dyn' },
    //FI/SD: 0000357: Plantafel SD Neuen Maschinenausfall-Typ für GR
    { value: '13 ungeplant - Kartuschenmangel', label: 'ungeplant - Kartuschenmangel', type: 'fix' }
  ];

  scope.filterExpression = function (reasons) {
    if (reasons.type === $rootScope.downTimeType) {
      console.log('machineType:' + $rootScope.machineType)
      if ($rootScope.downTimeType == 'fix') {
        //fixed list is the same for SD and SG
        return true;
      }
      if ($rootScope.downTimeType == 'dyn') {
        //console.log('machineType:' + $rootScope.machineType)
        //Dyn list return only items for SD where there value doesn't contain SG
        if ($rootScope.machineType == 'SD') {
          //console.log('SD dyn:' + reasons.value)
          if (!reasons.value.includes(' SG ')) {
            return true;
          }
        }
        //Dyn list return only items for SG where there value contains SG
        if ($rootScope.machineType == 'SG') {
          //console.log('SG dyn:' + reasons.value)
          if (reasons.value.includes(' SG ')) {
            return true;
          }
        }
      }
    }

    return false;
  };

  scope.getDefault = function () {
    if ($rootScope.downTimeType == 'dyn')
      if ($rootScope.machineType == 'SD')
        return '5 Puffer - Auftrag mehr als 6 Farben';
      else
        return '11 Puffer SG - Muster';
    else
      return '0 geplant - Personalmangel';
  };

  scope.answer = function (res, comment) {
    var result = { res: res, comment: comment };
    deferred.resolve(result);
    confirm.hide();
  }

  var confirm = $modal({ templateUrl: './tpl/modal.comment.tpl.html?_nobrowsercheck=1', scope: scope, show: false });
  var parentShow = confirm.show;
  confirm.show = function () {
    deferred = $q.defer();
    parentShow();
    return deferred.promise;
  }

  return confirm;
});
