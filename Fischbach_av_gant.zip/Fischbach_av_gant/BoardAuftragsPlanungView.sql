﻿
----------------------------------------------------------
DELETE FROM dbo.TABELLEN 
	WHERE TABELLE = 'BOARD_AUFTRAGSPLANUNG';

INSERT INTO TABELLEN
(TABELLE, [PARTITION], SERVERTIMESTAMP, MANDANTAKTIV, MANDANTNEUTRALERLAUBT, SCHEMANAME)
VALUES('BOARD_AUFTRAGSPLANUNG', 'APplus', NULL, 0, NULL, NULL);

----------------------------------------------------------
DROP INDEX [avboard_wauftragpos_1]
ON [dbo].[WAUFTRAGPOS]
GO
CREATE NONCLUSTERED INDEX [avboard_wauftragpos_1]
ON [dbo].[WAUFTRAGPOS] ([AG],[MAGR],[ENDE],[STATUS])
INCLUDE ([id],[BAUFTRAG],[T_SOLL],[MENGE_REST],[POSITION])
GO

DROP INDEX [avboard_wauftragpos_2]
ON [dbo].[ARTIKEL_A]
GO
CREATE NONCLUSTERED INDEX [avboard_wauftragpos_2]
ON [dbo].[ARTIKEL_A] ([ANP_COMBICODE])
INCLUDE ([ARTIKEL],[PREISGRUPPE])
GO

DROP INDEX [avboard_wauftragpos_3]
ON [dbo].[WAUFTRAGPOS]
GO
CREATE NONCLUSTERED INDEX [avboard_wauftragpos_3]
ON [dbo].[WAUFTRAGPOS] ([AG],[MANDANT],[MAGR],[STATUS])
INCLUDE ([id],[BAUFTRAG],[T_SOLL],[MENGE_REST],[POSITION])
GO

DROP INDEX [ANP_BOARDAUFTRAGSPLANUNG_WAUFTRAG]
ON [dbo].[WAUFTRAG]
GO
CREATE NONCLUSTERED INDEX [ANP_BOARDAUFTRAGSPLANUNG_WAUFTRAG]
ON [dbo].[WAUFTRAG] ([ENDE],[STATUS])
INCLUDE ([id],[BAUFTRAG],[APLAN],[MENGE],[START],[MENGE_IST],[POSITION],[MANDANT],[LATESTENDDATE])
GO

DROP VIEW [dbo].[BOARD_AUFTRAGSPLANUNG_BASE]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--Base view used to reduce number of records found for more complex
--stuff in the view on top
CREATE VIEW [dbo].[BOARD_AUFTRAGSPLANUNG_BASE] WITH SCHEMABINDING 
AS
SELECT 
    wa.ID AS WAID,
    wapos.ID AS WAPOSID,
    wa.BAUFTRAG AS BAUFTRAG,
    wa.APLAN AS ARTIKEL,
    wapos.STATUS AS WAPOSSTATUS,
    wa.STATUS AS WASTATUS,
    wa.[POSITION] AS WAPOS,
    wapos.MAGR AS WAPOSMAGR,
    wa.mandant AS WAMANDANT,
    wapos.mandant AS WAPOSMANDANT,
    art.NAME AS ARTNAME,
    art.PREISGRUPPE AS ARTPREISGRUPPE,
    art.ARTIKELSTATUS AS ARTIKELSTATUS,
    kart.KARTUSCHENNAME AS KARTKARTUSCHENNAME, 
    kart.GRUNDFARBE AS KARTGRUNDFARBE,
    kart.BESONDERHEIT AS KARTBESONDERHEIT,
    kart.DRUCK AS KARTDRUCK,
    wa.START AS WASTARTDATE,
    wa.ENDE AS WAENDEDATE,
    wa.LATESTENDDATE AS WALATESTENDDATE,
    wapos.T_SOLL AS WAPOSTSOLL,
    LEFT(wapos.MENGE_REST, CHARINDEX('.', wapos.MENGE_REST) - 1) AS WAPOSMENGEREST,
    LEFT(wapos.MENGE, CHARINDEX('.', wapos.MENGE) - 1) AS WAPOSMENGE,
    LEFT(wa.MENGE_IST, CHARINDEX('.', wa.MENGE_IST) - 1) AS WAMENGEIST,
    LEFT(wa.MENGE, CHARINDEX('.', wa.MENGE) - 1) AS WAMENGE,
    art.ANP_COMBICODE AS ARTCOMBICODE,
    aufpos.AENDERUNGSINDEX AS ARTAENDERUNGSINDEX,
    AZE.ORGZEIT AS AZEORGZEIT,
    asi.PRODUKTIONSSTART_ORIGINAL AS PRODUKTIONSSTART_ORIGINAL
FROM dbo.WAUFTRAG AS wa
     join dbo.ARTIKEL_A as art ON wa.APLAN = art.ARTIKEL
     join dbo.ANP_KARTUSCHEN as kart ON art.PREISGRUPPE = kart.PREISGRUPPE
     join dbo.WAUFTRAGPOS as wapos ON wa.BAUFTRAG = wapos.BAUFTRAG  AND wa.[POSITION] = wapos.[POSITION] AND wa.mandant = wapos.mandant
     left join dbo.azebeleg as aze ON aze.BAUFTRAG = wapos.bauftrag AND aze.position = wapos.position
     join dbo.AUFSTUELIPOS as aufpos ON aufpos.AUFSTUELI = wa.AUFSTUELI AND aufpos.POSITION = wa.AUFSTUELIPOS AND aufpos.mandant = wapos.mandant
     left join dbo.ANP_SCM_IMPORT as asi ON asi.AUFSTUELI  = aufpos.AUFSTUELI 
       AND asi.AUFSTUELIPOS = aufpos.[POSITION] 
       AND asi.ABRUF = (SELECT TOP 1 asi_sub.ABRUF 
                         FROM dbo.ANP_SCM_IMPORT as asi_sub 
                         WHERE asi_sub.AUFSTUELI  = aufpos.AUFSTUELI 
                         AND asi_sub.AUFSTUELIPOS = aufpos.[POSITION] 
                         AND asi_sub.PRODUKTIONSSTART_ORIGINAL IS NOT NULL
                         ORDER BY asi_sub.PRODUKTIONSSTART_ORIGINAL ASC)
WHERE wapos.MAGR IN ('02000','02001','02002','02003','02004','02005','02006','02007','02008','02009','02011','02012','02013') 
    --Show wauftrag in status "eingeplant, working and terminated if not complete"
    --Still show, if amount is not reached, but not if wauftrag is finished
    AND (wapos.STATUS IN (2, 3) 
        OR (wapos.STATUS = 4 AND (
            wa.STATUS = 3 OR 
            wa.MENGE - COALESCE(wa.MENGE_IST,0) > 0 
            OR (wa.STATUS = 6 AND aze.bauftrag IS NOT NULL )
            )
        )
    ) 
    AND (WA.STATUS < 6 
         OR
        (wa.STATUS = 6 AND aze.bauftrag IS NOT NULL))
    --AND wa.MANDANT = 'EN'
    --AND wapos.MANDANT = 'EN'
    AND wapos.AG = 10
GO
--Create an index on the view.  
--CREATE UNIQUE CLUSTERED INDEX AVBOARD_IDX_V1   
--    ON BOARD_AUFTRAGSPLANUNG_BASE (BAUFTRAG, WAPOS);  
--GO  