﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;

namespace p2plus.Fischbach_av_gant {
  public class MachineToolData {

    private DataTable toolTable;
    public string mandant { get; set; }
    public string connectString { get; set; }

    public static string sql_toolSG { get; } = @"
      SELECT art.ARTIKEL, art.NAME, art.VBME, art.LAGER as ARTLAGER, art.PLATZ as ARTLAGERPLATZ,
      bmk.STATUS as BMKSTATUS, bmk.ANP_FACHZAHL,
      lag.LAGERTYP as LAGERTYP,
      lbl.LAGER as CURRLAGER, lbl.PLATZ as CURRLAGERPLATZ, lbl.MENGE, lbl.CHARGE, lbl.DATUM, lbl.EINDATUM, lbl.SERIENNR, lbl.BESITZER, lbl.LAGERATTRIB,
      AP.[POSITION] AS AUFSTPOSPOSITION, AP.BMK 
      FROM ARTIKEL art 
      INNER JOIN LAGERBELEGUNG lbl ON art.artikel = lbl.artikel AND art.mandant= lbl.mandant
      INNER JOIN BMK bmk ON bmk.BMK=lbl.SERIENNR 
      INNER JOIN LAGER lag ON lbl.LAGER=lag.LAGER AND lbl.mandant= lag.mandant
      INNER JOIN AUFSTUELIPOS AP ON art.artikel = AP.ARTIKEL 
	      AND AP.AUFSTUELI = @FiBauf
	      AND ISNULL(AP.ISBM,0) <> 0 
	      AND AP.STRUKTUR = (SELECT TOP 1 POSITION
	            FROM AUFSTUELIPOS AP2
	            WHERE AP2.ERF_AUFTRAG = AP.AUFSTUELI
	            AND AP2.BAUFPOS = @FiBaufPos)
      --SELECT from locked stock where BMK is in use
      AND (ISNULL(lag.lagertyp,0) = 6 AND bmk.STATUS = 2 AND lbl.SERIENNR = AP.BMK)
      AND art.mandant = @FiMandant
    ";

    public string readToolData(string bauf, string baufpos, string mandant) {
      string sql;
      String currentTool = "";

      sql = sql_toolSG;

      SqlConnection conn;
      toolTable = new DataTable();
      CultureInfo provider = CultureInfo.InvariantCulture;

      using (conn = new SqlConnection(connectString))
      using (SqlDataAdapter dataAdapter = new SqlDataAdapter()) {
        var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add("@FiMandant", SqlDbType.VarChar).Value = mandant;
        cmd.Parameters.Add("@FiBauf", SqlDbType.VarChar).Value = bauf;

        short baufposShort;
        if (!short.TryParse(baufpos, out baufposShort)) {
          baufposShort = 0;
        }

        cmd.Parameters.Add("@FiBaufPos", SqlDbType.SmallInt).Value = baufposShort;
        dataAdapter.SelectCommand = cmd;
        dataAdapter.Fill(toolTable);

        for (int i = 0; i < toolTable.Rows.Count; i++) {
          DataRow currentRow;
          currentRow = toolTable.Rows[i];

          currentTool = currentRow["SERIENNR"].ToString() + " / " + currentRow["ARTIKEL"].ToString();
          return currentTool;
        }

        return currentTool;
      }
    }
  }
}