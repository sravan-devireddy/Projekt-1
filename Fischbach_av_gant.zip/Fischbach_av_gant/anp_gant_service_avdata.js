﻿'use strict';

var app = angular.module("GanttStable");

app.service('$avdata', function ($http, $rootScope, blockUI) {

  this.loadAsync = function (force, mandant, magrGroup, $scope) {

    $scope.setMessage("Debug: LoadAsyncStart...", false);
    if ($scope.options.fromDate == undefined) {
      $scope.options.fromDate = moment().subtract({ days: 2, hours: 0, minutes: 0 });
      $scope.options.toDate = moment().add({ days: 6, hours: 0, minutes: 0 });
    }

    //Siebdruck
    let url = "anp_gant_read_json.asmx/get";
    var params = {
      fromDate: JSON.stringify(moment($scope.options.fromDate).format('DD/MM/YYYY')),
      toDate: JSON.stringify(moment($scope.options.toDate).add({ days: 1, hours: 0, minutes: 0 }).format('DD/MM/YYYY')),
      mandant: JSON.stringify(mandant)
    }

    //Spritzguss
    if ($scope.machineType.toUpperCase() == 'SG') {
      url = "anp_gant_read_json.asmx/get_sg";

      params = {
        fromDate: JSON.stringify(moment($scope.options.fromDate).format('DD/MM/YYYY')),
        toDate: JSON.stringify(moment($scope.options.toDate).add({ days: 1, hours: 0, minutes: 0 }).format('DD/MM/YYYY')),
        magrGroup: JSON.stringify(magrGroup.group),
        mandant: JSON.stringify(mandant)
      }
    }

    if ($scope.autoReload || force) {
      $scope.setMessage("Laden...", false);
      $http({
        url: url,
        params: params,
        data: {},
        method: "GET",
        headers: {
          "Content-Type": "application/json; charset=utf-8"
        }
      }).then(function onSuccess(response) {
        var data = response.data;
        var status = response.status;
        var statusText = response.statusText;
        var headers = response.headers;
        var config = response.config;
        $scope.data = JSON.parse(data.d);
        console.log("AVData received")
      }).catch(function onError(response) {
        var data = response.data;
        var status = response.status;
        var statusText = response.statusText;
        var headers = response.headers;
        var config = response.config;
        console.log(data);
        alert(data)
      }).finally(function () {
        $scope.setMessage("Fertig", true);
        $scope.loadCartridgeStats();
        blockUI.stop();
      });

      $scope.getToday = moment();
      $scope.options.currentDateValue = moment();

      if ($scope.autoMove) {
        $scope.move();
      }
    }
  }

  var magrGroupData;

  this.getMagrGroupData = function () {
    return magrGroupData;
  }

  this.getMagrGroupDataAsync = function () {

    var magrGroupDataPromise = this.getMagrGroupDataPromise();
    magrGroupDataPromise.then(function (result) {
      console.log("GetMagrGroupData returned");
    });
  }

  this.getMagrGroupDataPromise = function () {

    return $http({
      url: "anp_gant_read_json.asmx/getMagrGroupData",
      method: "GET",
      headers: {
        "Content-Type": "application/json; charset=utf-8"
      },
      data: '{}'
    }).then(function onSuccess(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      //magrGroupData = JSON.parse(data);
      magrGroupData = data;
    }).catch(function onError(response) {
      var data = response.data;
      var status = response.status;
      var statusText = response.statusText;
      var headers = response.headers;
      var config = response.config;
      console.log(data);
      alert(data)
    }).finally(function () {
    });
  }

});
