﻿using p2plus.p2core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace p2plus.Fischbach_av_gant
{
  //Contains and handles the stock layout settings
  public class stockCartridgeData {
    public int numberOfRows {get;set;}
    public bool otherTypes {get;set;}
    public string listName {get;set;}
    public string filterName {get;set;}
    public string baseColour {get;set;}

    public stockCartridgeData () {
      numberOfRows = 1;
      otherTypes = false;
      listName = "not_set";
      filterName = "not_set";
      baseColour = "not_set";
    }

    internal List<DataRow> cartridgeList = new List<DataRow>();

    public List<DataRow> getCartridgeList () {
      return cartridgeList;
    }

    /// <summary>
    /// Adds a new stock configuration item
    /// </summary>
    /// <param name="listName">Cartridge name of the list appearing inside the web UI</param>
    /// <param name="filterName">Cartridge filter name used to compare and dispatch</param>
    /// <param name="numberOfRows">The number of rows the cartridges should be distributed to in the GUI</param>
    public stockCartridgeData (string listName, string filterName, string baseColour, int numberOfRows) {
      this.numberOfRows = numberOfRows;
      this.listName = listName;
      this.filterName = filterName;
      this.baseColour = baseColour;
    }    
  }
}