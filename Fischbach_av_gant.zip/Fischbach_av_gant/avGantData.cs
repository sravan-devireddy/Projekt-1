﻿using Newtonsoft.Json;
using p2plus.WebObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

/// <summary>
/// Contains the classes used to transmit the task/order/cartridge date to the UI via JSON
/// </summary>
namespace p2plus.Fischbach_av_gant { 
  public class AvGantMagrBase {
    public string name { get; set; }
    public string id { get; set; }
    public float workload { get; set; }
    public int palets { get; set; }
    public int late { get; set; }
    public string classes { get; set; }
  }

  public class AvGantMagrGroupParent : AvGantMagrBase {
    public AvGantMagrGroupParent () {
      name = null;
    }
  }

  public class AvGantTreeParent {

    public string name { get; set; }
    public List<String> children { get; set; }    

    public AvGantTreeParent() {
      name = null;
      children = new List<String>();
    }
  }

  public class AvGantMagr  : AvGantMagrBase{
    public string height { get; set; }
    public string magr { get; set; }
    public int sort { get; set; }

    public string color { get; set; }
    public List<AVTask> tasks  { get; set; }

    public AvGantMagr () {
      tasks = new List<AVTask>();
      height = "3.8em";
    }

    public int getCartridgeSum () {

      int cardridgeSum = 0;
      foreach (AVTask task in tasks) {
        cardridgeSum += task.data.mengeInt;
      }

      return cardridgeSum;
    }

    public int getWorkloadSum () {

      int workloadSum = 0;
      foreach (AVTask task in tasks) {
        workloadSum += task.data.workload;
      }

      return workloadSum;
    }

    public int getLate () {
      foreach (AVTask task in tasks) {
        if (late != 0) { 
          return late;
        }
      }

      return 0;
    }
  }

  public class AVTask {
    public string id { get; set; }
    public string name { get; set; }
    public string name2  { get; set; }
    public int priority { get; set; }
    public string color { get; set; }
    public string from { get; set; }
    public string to { get; set; }

    [JsonIgnore]
    public int late { get; set; }

    public string classes { get; set; }
    public Tooltips tooltips;
    public AVData data;
    public AVProgress progress;
    public AVmovable movable;

    public AVTask () {
      priority = 10;
      tooltips = new Tooltips();
      data = new AVData();
      progress = new AVProgress();
      movable = new AVmovable();
      late = 0;
    }
  }

  public class AVData {
    public string waid { get; set; }
    public string waposid { get; set; }
    public string waposmagr { get; set; }
    public string cartridgeName { get; set; }
    public string baseColour { get; set; }
    public string particularity { get; set; }
    public string print { get; set; }
    public string combiCode { get; set; }
    public string bauftrag { get; set; }
    public string wapos { get; set; }
    public string menge { get; set; }
    public int mengeInt { get; set; }
    public string artikel { get; set; }
    public int workload  { get; set; }
  }

  public class AVProgress {
    public int percent { get; set; }
    public string color { get; set; }

    public AVProgress () {
      color = "#246b01";
      percent = 0;
    }
  }

  public class AVmovable {
    public Boolean enabled { get; set; }
    public Boolean allowMoving { get; set; }
    public Boolean allowResizing { get; set; }
    public Boolean allowRowSwitching { get; set; }

    public AVmovable () {
      enabled = true;
      allowMoving = true;
      allowResizing = false;
      allowRowSwitching = true;
    }
  }

  public class Tooltips {
    public string content {get; set;}

    public void setContent (TaskData data, string mandant, MagrConfList magrConfList, MachineToolData machineToolData) {
      StringBuilder json = new StringBuilder();
      json.Append ("<table id='tooltiptable'>");
      addTableLine (json, "Artikel", data.artikel +  "  " + data.indexalpha);
      addTableLine (json,"Name", data.artname);
      addTableLine (json,"Bauftrag", data.bauftrag + " / " + data.wapos);
      if (!data.azmagr.Equals("") && !data.azOrgZeit.Equals(new DateTime())) {
        addTableLine (json,"Startzeit -- MAGR", data.azOrgZeit.ToString("dd.MM.yy HH:mm") + " -- " + data.azmagr);
      }
      addTableLine (json,"Start -- Ende", data.start.ToString("dd.MM.yy HH:mm") + " -- " + data.end.ToString("dd.MM.yy HH:mm"));
      TimeSpan duration = data.end - data.start;
      addTableLine (json,"Dauer", duration.Hours.ToString("00") + ":" + duration.Minutes.ToString("00"));
      addTableLine (json,"spät. Ende", data.latestEnd.ToString("dd.MM.yy HH:mm"));
      if (!data.prodStartOrg.ToString("dd.MM.yy").Equals("01.01.01")) { 
        addTableLine (json,"Prodstart org.", data.prodStartOrg.ToString("dd.MM.yy HH:mm"));
      }

      float percentileReady = 0;
      if (data.menge > 100) { 
        percentileReady = data.mengeIst / (data.menge / 100);
      }
      addTableLine (json,"Menge -- Rest", data.menge.ToString() + " -- " + (data.menge - data.mengeIst).ToString() + " " + percentileReady.ToString("0") + "%");

      if (!data.kartuschenname.Equals("")) {
        addTableLine(json, "Art", data.kartuschenname + "  " + data.grundfarbe + "  " + data.besonderheit + "  " + data.druck);
      }
      if (!data.combiCode.Equals("")) {
        addTableLine (json,"Combicode", data.combiCode);
      }

      //Only  for SG - tools used for running bauftrag
      if (machineToolData != null && data.running.Contains("RUN")) {
        string toolInfo = machineToolData.readToolData(data.bauftrag, data.wapos, mandant);
        if (toolInfo != "") {
          addTableLine(json, "Werkzeug", toolInfo);
        }
      }

      //Only for SG - alternative machines
      if (data.alternativMagr != null) {
        string magrListStr = "";
        List<string> magrList = new List<string>();

        //loop alternative magrs and attach machine name
        foreach (string aMagr in data.alternativMagr) {
          var index = Array.FindIndex(magrConfList.magrIDList, row => row == aMagr);
          if (index >= 0) {
            //Magr is configured, add it to the tooltip
            string magrName = magrConfList.magrNameList[index];
            magrList.Add(aMagr + " " + magrName);
          } else {
            //Magr is not configured
            magrList.Add(aMagr);
          }
        }

        if (magrList.Count > 0) {
          magrListStr = string.Join(", <br>", magrList);
          addTableLine(json, "magrs", magrListStr);
        }

        //CUSTOM:BEGIN:FI/SD:24.10.2023 0000275: Plantafel SG, Tooltip inkl. Materialinformationen (Stückliste)
        if (data.bauftrag != "") {
          string sqlText = "select BEMERKUNG, NAME from AUFSTUELIPOS  ";
          sqlText += "where AUFSTUELI = '" + data.bauftrag + "' AND (BEMERKUNG IS NOT NULL OR VBME ='g')";

          DataTable rows = WebUtils.getDataTable("AUFSTUELIPOS", sqlText, false);
          int rowCount = rows.Rows.Count;

          List<string> combinedDataList = new List<string>();

          if (rowCount > 0) {
            for (int i = 0; i < rowCount; i++) {
              DataRow material = rows.Rows[i];
              string combinedData = material["BEMERKUNG"].ToString() + " " + material["NAME"].ToString();
              combinedDataList.Add(combinedData);
            }

            string combinedTableData = string.Join("<br>", combinedDataList);
            addTableLine(json, "Material", combinedTableData);
          }
        }
       //CUSTOM:END:FI/SD:24.10.2023 0000275: Plantafel SG, Tooltip inkl. Materialinformationen (Stückliste)
      }
      json.Append ("</table>");

      MasterData.artikel artikelObj = new MasterData.artikel();
      string imagePath = artikelObj.getPicture(data.artikel + ".png");
      if (imagePath != null && imagePath.Length > 0 && !imagePath.Contains("empty")) {
        json.Append("<img src=\"" + imagePath + "\" >");
      }
      content = json.ToString();
    }

    public void setContentBuffer (TaskData data) {
      StringBuilder json = new StringBuilder();
      json.Append ("<table id='tooltiptable'>");
      addTableLine (json, "Artikel", data.artname.Substring(1,data.artname.Length-1));
      if (!data.azmagr.Equals("") && !data.azOrgZeit.Equals(new DateTime())) {
        addTableLine (json,"Startzeit -- MAGR", data.azOrgZeit.ToString("dd.MM.yy HH:mm") + " -- " + data.azmagr);
      }
      addTableLine (json,"Start -- Ende", data.start.ToString("dd.MM.yy HH:mm") + " -- " + data.end.ToString("dd.MM.yy HH:mm"));
      TimeSpan duration = data.end - data.start;
      addTableLine (json,"Dauer", duration.Hours.ToString("00") + ":" + duration.Minutes.ToString("00"));
      if (!data.prodStartOrg.ToString("dd.MM.yy").Equals("01.01.01")) {
        addTableLine(json, "Prodstart org.", data.prodStartOrg.ToString("dd.MM.yy HH:mm"));
      }
      content = json.ToString();
      json.Append ("</table>");
    }

    public void setContentOutage (TaskData data) {
      StringBuilder json = new StringBuilder();
      json.Append ("<table id='tooltiptable'>");
      addTableLine (json, "Artikel", data.artname);
      if (!data.azmagr.Equals("") && !data.azOrgZeit.Equals(new DateTime())) {
        addTableLine (json,"Startzeit -- MAGR", data.azOrgZeit.ToString("dd.MM.yy HH:mm") + " -- " + data.azmagr);
      }
      addTableLine (json,"Start -- Ende", data.start.ToString("dd.MM.yy HH:mm") + " -- " + data.end.ToString("dd.MM.yy HH:mm"));
      TimeSpan duration = data.end - data.start;
      addTableLine (json,"Dauer", duration.Hours.ToString("00") + ":" + duration.Minutes.ToString("00"));
      content = json.ToString();
      json.Append ("</table>");
    }

    private void addTableLine (StringBuilder json, string name, string value) {
      json.Append("<tr><td>").Append(name).Append(":</td><td>").Append(value).Append("</td></tr>");
    }

    public string getContent() {
      return content;
    }
  }

  public class avTools {
                           /// <summary>
    /// Transforms a rgb color value to the according hex color value
    /// </summary>
    /// <param name="rgb">comma separated rgb value string</param>
    /// <returns></returns>
    public static string rgbToHex (string rgb) {
      if (rgb == null || rgb.Equals("")) {
        return "#616161";
      }

      string progressColor = rgb.Replace("rgb(","").Replace(")","");
      string[] colors = progressColor.Split(',');
      int rChannel = Int32.Parse(colors[0]);
      int gChannel = Int32.Parse(colors[1]);
      int bChannel = Int32.Parse(colors[2]);

      string hexStr = string.Format("#{0:X2}{1:X2}{2:X2}", rChannel, gChannel, bChannel);
      return hexStr;
    }

    public static string darkenHex (string hexColor, double factor) {
      System.Drawing.Color current = System.Drawing.ColorTranslator.FromHtml(hexColor);
      System.Drawing.Color c2 = System.Drawing.Color.FromArgb(current.A,(int)(current.R * factor), (int)(current.G * factor), (int)(current.B * factor));
      return System.Drawing.ColorTranslator.ToHtml(c2);
    }
  }
}