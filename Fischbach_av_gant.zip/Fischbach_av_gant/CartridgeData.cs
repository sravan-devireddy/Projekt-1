﻿using System;
using System.Data;
using System.Globalization;

namespace p2plus.Fischbach_av_gant {
  public abstract class CartridgeData {

    public string mandant { get; set; }

    //Used to set the concatenation of stock cartridge tasks in the UI
    internal DateTime lastStockTaskDate;

    public MagrConfList magrConfList { get; set; }

    public MachineToolData machineToolData { get; set; }

    protected CartridgeData() {
      machineToolData = null;
      magrConfList = null;
    }

    /// <summary>
    /// Uses one row from the selection result set to prepare an avgant task object that is sent in JSON format to the UI
    /// </summary>
    /// <param name="currentRow">data from DB</param>
    /// <param name="concat"></param>
    /// <returns></returns>
    internal AVTask getTask(DataRow currentRow, string machineType, Boolean concat) {

      TaskData data = new TaskData(currentRow);

      AVTask avtask = new AVTask();
      avtask.id = data.waposid;
      avtask.priority = 10;
      avtask.color = data.color;

      //Handle normal data display without downtime
      if (!data.artikel.Equals("02000") && !data.artikel.Equals("02050") &&
          !data.artikel.Equals("01000") && !data.artikel.Equals("01050")) {
        avtask.name = data.artikel + "." + data.indexalpha;
        //Change: Display latest end date in task box
        //avtask.name2 = end.ToString("dd.MM HH:mm");
        avtask.name2 = data.latestEnd.ToString("dd.MM HH:mm");
        avtask.progress.percent = data.prozentFertig;

        //Shadow color for progress
        avtask.progress.color = avTools.darkenHex(data.color, 0.6);

        avtask.classes = data.getTooLateClass() + " " +
                         data.getRunningClass() + " ";

        if ("SG".Equals(machineType)) {
          avtask.classes += data.getLaufkartClass();
        } else if ("SD".Equals(machineType)) {
          avtask.classes += data.getCombiCodeClass() + " " +
          data.getSpecializationClass() + " " +
          data.getScreenReadyClass();
        }

        avtask.tooltips.setContent(data, mandant, magrConfList, machineToolData);

        //calculate late minutes only for running wauftrag
        if (data.running.Contains("RUN")) {
          TimeSpan late = data.azOrgZeit - data.start;
          avtask.late = (int)late.TotalMinutes;
        }
      }

      //handle stock tasks
      if (concat) {
        lastStockTaskDate.AddMinutes(1);
        DateTime newStart = lastStockTaskDate;
        TimeSpan duration = new TimeSpan(0, 0, data.menge / 110 + 15, 0, 0);
        //Minimum duration 60 minutes for stock tasks
        if (duration < new TimeSpan(0, 1, 0, 0, 0)) {
          duration = new TimeSpan(0, 1, 0, 0, 0);
        }

        if ("SG".Equals(machineType)) {
          //Maximum duration 16 hours for stock tasks
          if (duration > new TimeSpan(0, 16, 0, 0, 0)) {
            duration = new TimeSpan(0, 16, 0, 0, 0);
          }
        }

        DateTime newEnd = newStart.Add(duration);
        lastStockTaskDate = newEnd;
        avtask.from = newStart.ToString("o");
        avtask.to = newEnd.ToString("o");
      } else {
        avtask.from = data.start.ToString("o");
        avtask.to = data.end.ToString("o");
      }

      avtask.data.waid = data.waid;
      avtask.data.waposid = data.waposid;
      avtask.data.waposmagr = data.magr;
      avtask.data.cartridgeName = data.kartuschenname;
      avtask.data.baseColour = data.grundfarbe;
      avtask.data.particularity = data.besonderheit;
      avtask.data.print = data.druck;
      avtask.data.combiCode = data.combiCode;
      avtask.data.bauftrag = data.bauftrag;
      avtask.data.wapos = data.wapos;
      avtask.data.menge = data.menge.ToString("N0", new CultureInfo("de-DE"));
      avtask.data.mengeInt = data.menge;
      avtask.data.workload = data.workload;
      avtask.data.artikel = data.artikel;

      if (data.artikel.Equals("02050") || data.artikel.Equals("01050")) {
        //Cut leading indexnumber with one or two digits
        if (data.artname != null && data.artname.Length > 2) {
          int spaceIndex = data.artname.IndexOf(' ');
          if (spaceIndex == 1 || spaceIndex == 2) {
            avtask.name = data.artname.Substring(spaceIndex + 1, data.artname.Length - (spaceIndex + 1) > 40 ? 40 : data.artname.Length - spaceIndex - 1);
          }
        } else {
          avtask.name = "Puffer";
        }
        avtask.name2 = data.end.ToString("dd.MM HH:mm");
        avtask.movable.allowResizing = true;
        avtask.tooltips.setContentBuffer(data);
        avtask.data.menge = "";
      }
      if (data.artikel.Equals("02000") || data.artikel.Equals("01000")) {
        avtask.name = data.artname;
        avtask.name2 = data.end.ToString("dd.MM HH:mm");
        avtask.movable.allowResizing = true;
        avtask.tooltips.setContentOutage(data);
        avtask.data.menge = "";
      }

      return avtask;
    }
  }
}